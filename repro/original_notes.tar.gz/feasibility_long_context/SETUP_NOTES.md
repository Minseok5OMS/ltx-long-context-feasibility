# LTX local-only 및 참조 진단 설정

2026-09-06. 아래는 로컬 코드·체크포인트를 직접 확인하고 정한 첫 실행 설계다. 실행 결과는 별도 로그와 보고서에 기록한다.

## 환경과 모델

- LTX commit: `a95ab856bf29407b6b066ede0abe1846050db56c`.
- Python: 부모 저장소 `.venv/bin/python`; PyTorch `2.13.0+cu132`, CUDA runtime `13.2`.
- 사용자가 GPU 0–2번을 허용했다. 첫 실행은 물리 GPU 0 하나만 노출한다. 확인 당시 각 GPU의 여유 VRAM은 약 95 GiB다.
- Transformer: `../models/ltx-2.5/diffusion_models/ltx-2.5-22b-distilled-transformer-bf16.safetensors`.
- Video VAE: `../models/ltx-2.5/vae/ltx-2.5-video-vae-bf16.safetensors`.
- Text encoder: `../models/ltx-2.5/text_encoders/gemma4-12b-with-proj-ltx-2.5-bf16.safetensors`. Tokenizer/config가 파일에 포함되어 있어 추가 모델 다운로드가 필요 없다.
- Split checkpoint 경로는 현재 `ModelPaths.from_split` API를 사용한다.

## 재사용할 코드 경로

`ltx_pipelines.utils.blocks.PromptEncoder`, `ImageConditioner`, `DiffusionStage`, `VideoDecoder`를 조합한다. Upstream 코드와 transformer 구조를 수정하지 않는다. `ImageConditioner`는 이름과 달리 callback 안에서 video encoder를 직접 호출할 수 있다.

`VideoConditionByLatentIndex(latent, strength=1.0, latent_idx=0)`가 prefix의 clean latent를 넣고 denoise mask를 0으로 만든다. Sampler는 denoising step마다 이 clean 값을 다시 적용한다. 실제 실행에서도 매 step과 최종 출력의 prefix latent가 유지되는지 검사한다.

기존 `DistilledPipeline`의 첫 단계에 맞춰 8-step sigma schedule, `SimpleDenoiser`, Euler ancestral (`eta=1`, `s_noise=1`, noise seed offset 10000)을 사용한다. Audio latent는 공식 첫 단계처럼 함께 생성하지만 오디오를 조건으로 넣거나 디코딩·평가하지 않는다. 첫 진단은 512×288에서 한 단계로 디코딩하며 spatial upsample/refinement는 실행하지 않는다. 공식 두 단계의 최종 품질을 재현하는 설정은 아니다.

VAE encoder는 causal convolution encoder지만 해당 파일의 **decoder는 `NADiffusionDecoder`**다. 구형 convolution decoder로 가정하지 않고 현재 `VideoDecoder`의 diffusion VAE 경로를 사용한다. Decoder noise도 별도 seed로 고정한다. Latent 조건 고정이 decoded RGB의 완전 일치를 뜻하지는 않는다.

## 프레임과 시간 경계

- VAE encoder 시간축은 `8k+1`, 공간축은 32배 압축이다. 유효하지 않은 프레임 수를 넣으면 마지막 프레임을 잘라내므로 그대로 48프레임을 넣지 않는다.
- 현재 one-stage 공간 크기 제약은 가로·세로 32의 배수다. 512×288을 사용하며 center crop + resize를 기록한다.
- 2초 local은 24 FPS에서 48프레임이다. **처음 프레임을 앞에 한 번 복제**하여 49프레임으로 만들고 VAE로 7개 latent frame에 인코딩한다. 원래 local의 마지막 프레임까지 보존하고 GT를 padding에 사용하지 않는다.
- 모델 시퀀스는 prefix 49 + target 72 = 121프레임, latent 16프레임이다. 처음 7개 latent frame을 고정하고 나머지 9개를 생성한다.
- 앞의 복제 프레임은 모델 내 정렬용이다. 원본 시간축에서는 local 시작보다 `1/24`초 앞에 배치한 가상 프레임이다. 평가 target은 decoded index `[49,121)`의 72프레임으로 정확히 3초다.
- Local/target GT를 합쳐 VAE에 인코딩하지 않는다. 생성 스크립트는 local 파일만 읽고, GT 영상은 생성 완료 후 비교 보고서 단계에서 읽는다.
- 출력 전체 길이와 FPS는 현재 API가 받으며, 코드의 모델 시간 위치 설정은 최대 20초를 명시한다. 이것을 엄격한 지원 길이 보장으로 해석하지 않는다. 이번 121프레임의 짧은 진단만 실제로 검증한다.

## 참조 비교에서 추가한 설정

`run_reference_comparison.py`는 공식 `VideoConditionByKeyframeIndex`로 독립 인코딩한 과거 영상 또는 대표 이미지를 추가한다. `VideoConditionByReferenceLatent`는 IC-LoRA용이므로 사용하지 않았다. `past`는 과거 시간 좌표의 1,440 token, `target_guide`는 생성 시작 시점 좌표의 144 token이다. 공통 base video/audio 위치는 모든 조건에서 동일하게 이동시킨다. [프로토콜](REFERENCE_PROTOCOL.md)에 정확한 좌표와 제약을 기록했다.

`reference_controls.py`에서 공통 base grid의 초기/step noise를 CPU에서 만들고 추가 clean 참조는 zero padding해 조건 간 RNG 소비를 맞춘다. 실제 저장 noise hash를 평가 때 비교한다. 원본에서의 66/115초 간격과 모델 입력의 1초 참조-local 빈 간격은 별개다. GT 영상은 생성 시 열지 않는다. Decoder seed도 동일하게 고정한다.

한 프로세스에서 두 번째 diffusion VAE를 실행할 때 CUDA illegal-memory-access가 관찰됐다. `--all-modes`가 각 조건을 새 프로세스로 실행하도록 바꾼 뒤 세 조건을 완료했다. 원인 전체가 규명된 것은 아니다. 중단 로그와 수정 전 소스는 outputs에 보존했다. 총 9회의 완료된 참조 비교와 해석은 [REFERENCE_RESULT.md](REFERENCE_RESULT.md)에 있다.
