# FineVideo 기반 LTX 참조 활용 진단

첫 단계는 FineVideo에서 소량의 후보 영상을 확보하고, 실제 영상에서 local/target/oracle/random 구간을 고르는 것이다. 후보 다운로드와 oracle 검증은 별개의 작업이다.

## 현재 상태

**현재 단계:** 사용자와의 후속 논의에 따라 feasibility를 마무리하고 **메모리 구축 Stage 2의 초기 설계**로 전환했다. [첫 메모리 설계·VRAM 해석](MEMORY_STAGE2_PLAN.md). 아직 메모리 구현·학습은 실행하지 않았으며 아래 120회는 완료한 Stage 1 기록이다.

**최신 완료 · 2026-09-08:** 연속 과거 32초와 선택 chunk의 **5사례 × 5조건, 신규 25회**를 완료했다. 정식 누적 **120회**다. Oracle은 직원·로봇·차량의 외관을 더 잘 드러냈고 로봇은 새 display 구도와 결합했다. 학생은 공동 실패, 보존 작업자는 얼굴 일부만 노출됐으며 직원·차량에는 참조 구도 재현이 남는다. Denoising은 Native 대비 median **4.66×**, Full-reference 대비 **4.70×** 빠르고 전체 peak allocated VRAM은 약 **7%**, 상주 baseline 대비 증가분은 약 **76%** 감소했다. 25조건 입력/좌표/noise/고정 latent 및 출력 7,825프레임 감사가 통과했다. 정성 평가는 assistant의 전체 프레임 sheet 검토이며 독립 사람 평가는 아니다.

[최신 실제 입력·25개 영상](reports/long_input/index.html) · [결과·측정 범위·한계](LONG_INPUT_RESULT.md) · [다음 단계](NEXT_STAGE.md)

**앞선 prompt 비교 · 2026-09-08:** 원본 전체 Past 참조를 유지한 P1/P2/P3 × Local/Image-Past/Video-Past 신규 45회를 모두 첫 시도에 완료했고, 기존 P0 15개와 60개를 비교했다. 정식 누적은 95회다. 로봇·보존 작업자는 과거 외관과 새 구도의 결합이 관찰됐고, 차량 Video/Past는 P2/P3에서 외부 장면으로 전환됐지만 실제 주행 성공은 불확실하다. 학생은 계속 전환에 실패했고 관리자 Video/Past는 P0 성공에서 새 prompt의 노트북 유지로 악화됐다. Prompt 추가의 효과는 사례·형식에 따라 다르며 P3가 P2보다 일관되게 낫지는 않다.

[실제 입력·P0–P3의 60개 영상](reports/five_case_prompt/seed42/index.html) · [prompt 결과·검증](PROMPT_CONTROL_RESULT.md) · [다음 판단](NEXT_STAGE.md)

**앞선 2×2 완료:** 서로 다른 FineVideo 원본 5개에서 **이미지/영상 × Past/Target 시간 위치 2×2**를 완료했다. 기존 Image/Past 5개와 Local 기준 5개를 재사용하고 신규 15개를 생성했다. 로봇·학생·차량은 두 Target 조건에서 필요한 외관이 드러났다. 관리자·보존 작업자는 Video/Past에서도 외관이 전달됐다. 참조 구도·동작·컷/자막 재현이 남아 있어, 외관 전달과 새로운 장면 제어를 구분한다.

[5개 실제 입력·2×2 비교](reports/five_case_grid/seed42/index.html) · [결과·검증·한계](FIVE_CASE_GRID_RESULT.md) · [사전 설계](FIVE_CASE_GRID_PROTOCOL.md) · [Stage 1 현황](FEASIBILITY_STATUS.md) · [후속 제안](NEXT_STAGE.md)

**합의한 범위:** 같은 과거 구간의 이미지 한 장/영상, seed 42, 신규 Random·20개 확대 없음. 2×2 완료 당시 누적은 50회였고, 이후 prompt 비교 당시 누적은 95회다. 같은 형식의 Past/Target 쌍에서는 참조 내용·token 수를 유지하고 시간 좌표만 이동했다. Prompt·Local·실제 noise·모델 설정을 유지했으며 입력·출력 감사가 통과했다. 그 2×2에서는 prompt를 유지했다. 이후 별도 prompt 비교 45회는 완료했고 attention 측정·메모리 학습은 미실행이다.

**앞선 5개 Local/Oracle 비교:** Image/Past만 사용한 10회에서 두 인물의 외관 기여가 보였지만 로봇·학생·차량의 시점 전환은 막혔다. 당시 디코더 오류는 별도 프로세스로 복구했고 이번 15회는 같은 분리 디코더로 첫 시도에 모두 성공했다. [이전 결과](FIVE_CASE_RESULT.md) · [이전 비교 영상](reports/five_cases/seed42/index.html)

**앞선 반복수 진단:** seed 42에서 같은 이미지의 반복수 2·4를 신규 생성했다. 기존 1·10회와 비교하자 1·2·4회는 인터뷰 외형을 전달했고 10회는 공사 장면을 지속했다. 4회는 초반 전환이 더 오래 겹쳤지만 1초 이후 DINO는 1·2회와 비슷한 약 0.92였다. [반복수 결과·검증·해석](REFERENCE_REPETITION_RESULT.md) · [실제 입력과 동기화 영상](reports/reference_repetition/seed42/index.html)

**앞선 A–E 진단:** seed 42로 B·C·D 3회를 추가했다. 기존 A·E를 포함한 5조건 중 이미지 1장 A만 인터뷰로 전환했고, 같은 latent를 같은 시간에 10회 복제한 B부터 공사 장면이 지속됐다. [A–E 결과 해석](REFERENCE_FORMAT_RESULT.md) · [실제 입력과 동기화 영상](reports/reference_format/seed42/index.html)

**앞선 결과:** 이미지/영상 × 과거/생성 시간 위치의 2×2 비교를 seed 42·43·44에서 완료했다. 기존 2회 재사용 + 신규 10회다. 영상 참조는 생성 위치로 이동했을 때 세 seed 모두 인터뷰 외형이 재현됐다. 이미지 한 장은 과거 위치에서도 전달됐으나 전환이 더 느렸다. [결과 해석](TEMPORAL_POSITION_RESULT.md) · [실제 입력과 동기화 영상](reports/temporal_position/index.html) · [조건별 수치](reports/temporal_position/results.csv)

2026-09-06: 후보 5개와 초기 입력 3개를 준비했다. 요리 local-only 1회에 이어, 두 인터뷰의 Local/Random/Oracle 비교 6회와 첫 인터뷰의 생성 시점 이미지 진단 3회를 완료했다. 모두 512×288, 24 FPS, 8-step으로 target 3초를 생성했다. 과거 영상은 의상 일부만 전달했지만 생성 시점의 과거 이미지는 인터뷰 외형을 재현했다. 장거리 기억의 성공을 검증한 결과는 아니다.

- [데이터 검토 결과와 한계](DATA_REVIEW.md)
- [후보 5개 미리보기](reports/candidates/index_overview.html)
- [선정 구간과 클립 검토 페이지](reports/pilot/index.html)
- [접근 검사 결과](reports/finevideo_access.json)
- [첫 생성 결과와 재현 명령](LOCAL_SMOKE_RESULT.md)
- [GT/생성 비교 영상 페이지](reports/local_smoke/index.html)
- [참조 활용 결과·실행 명령·한계](REFERENCE_RESULT.md)
- [Local/Random/Oracle 비교 영상](report.html)
- [실제 참조 이미지·원본 구간·LTX 주입 방식](REFERENCE_PROTOCOL.md)
- [수치 CSV](results.csv) · [초기 결론](CONCLUSION.md)

브라우저에서는 [참조 설명 HTML](REFERENCE_PROTOCOL.html)과 [결과 해석 HTML](REFERENCE_RESULT.html)을 연다. `make_reference_report.py`는 `render_reference_docs.py`를 통해 MD 원문을 UTF-8 HTML로 변환하며, 브라우저 페이지의 문서 링크도 HTML로 연결한다. 원문 수정 후 같은 보고서 명령을 실행하면 갱신된다. [파일럿 1의 두 방식 비교](report.html#pilot-one-difference)에는 입력 영상/이미지와 모델 시간 배치를 나란히 표시했다.

접근 조건은 [FineVideo 공식 페이지](https://huggingface.co/datasets/HuggingFaceFV/finevideo)에 있다. 토큰 값은 코드, 로그, 채팅에 기록하지 않는다.

## 브라우저 접속이 안 될 때

보고서 파일과 웹 서버는 별개다. 서버가 종료되면 파일이 남아 있어도 `localhost:8765` 링크는 열리지 않는다. 2026-09-07에는 이 상태를 확인해 서버를 재시작했고, 비교 HTML과 MP4의 HTTP 200 응답을 확인했다.

실행 세션에서 서버가 다시 종료되는 현상이 있어, 2026-09-07에 **별도 tmux 서버 `ltx-longcond-report`의 `report` 세션**으로 옮겼다. 비교 HTML·MP4의 HTTP 200과 실행 중인 Python 프로세스를 확인했다. 로그는 `outputs/report_server.log`에 있다. 이미 서버가 실행 중이라면 추가 실행하지 않는다.

```bash
# 상태 확인
tmux -L ltx-longcond-report list-sessions

# 해당 세션이 없고 8765번 서버도 종료된 경우에만 시작
tmux -L ltx-longcond-report new-session -d -s report 'exec python -u -m http.server 8765 --bind 127.0.0.1 --directory /mnt/minu/minseok/LTX-2/longcond/feasibility_long_context > /mnt/minu/minseok/LTX-2/longcond/feasibility_long_context/outputs/report_server.log 2>&1'
```

원격 VS Code에서는 **Ports(포트)**에서 원격 포트 `8765`를 전달한다. 로컬 포트도 8765라면 [최신 긴 입력·Sparse 비교 페이지](http://localhost:8765/reports/long_input/index.html)를 연다. 다른 로컬 포트가 배정되면 주소의 포트 번호를 해당 값으로 바꾼다. 페이지가 열려도 영상은 재생 버튼을 눌러야 움직인다.

서버에서 HTTP 200이어도 사용자 PC의 포트 전달이 연결되지 않으면 위 링크가 열리지 않는다. 이때는 서버를 다시 시작하기 전에 Ports 탭의 8765 행에서 **브라우저에서 열기**를 사용해 실제 전달 주소로 접속한다. 포트가 없으면 **포트 전달(Forward a Port)**에 `8765`를 추가한다. 브라우저에 폴더 목록이 나오면 `report.html`을 열고 최신 5개 비교 링크를 누른다. 접속 주소는 Ports의 **Forwarded Address(전달된 주소)**를 기준으로 한다.

브라우저에서 열기를 눌러도 무한 로딩이고 서버 로그에 새 GET 요청이 없다면, Ports의 8765 행에서 **포트 전달 중지(Stop Forwarding Port)** 후 `8765`를 다시 추가한다. 새 전달 주소로 다시 접속한다. 로컬 전달 주소라면 `http://127.0.0.1:<실제 전달된 포트>/report.html`로도 확인한다. 이 서버는 HTTP를 사용한다. 그래도 접속되지 않으면 주소창 전체 주소와 서버 로그를 함께 확인한다. 서버에서 빠르게 HTTP 200이 반환됐다는 사실만으로 사용자 쪽 연결 복구를 완료 처리하지 않는다.

## 접근 재확인

다음 명령은 **부모 LTX 저장소 루트**(`/mnt/minu/minseok/LTX-2`) 기준이다.

```bash
.venv/bin/python longcond/feasibility_long_context/download_finevideo.py --check-access
```

현재 `longcond` 디렉터리에서는 다음 명령을 사용한다.

```bash
../.venv/bin/python feasibility_long_context/download_finevideo.py --check-access
```

결과는 `reports/finevideo_access.json`에 저장된다. 토큰 존재 여부와 HTTP 상태만 기록하고, 인증값은 기록하지 않는다. 서버가 이유를 제공하면 해당 오류 설명도 보존한다.

## 접근 허용 후 후보 수집

현재 LTX 환경에는 `huggingface_hub`, `av`, `PIL`, `cv2`, `imageio_ffmpeg`가 있다. `pyarrow==21.0.0`은 실험 폴더 `.deps/`에 설치했다. 부모 LTX 가상환경의 패키지는 변경하지 않았다. 환경을 다시 준비할 때 아래 명령을 사용한다. 부모 LTX 저장소 루트 기준이다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache pip install --python .venv/bin/python --target longcond/feasibility_long_context/.deps pyarrow==21.0.0
.venv/bin/python longcond/feasibility_long_context/download_finevideo.py --max-videos 5 --max-shards 1 --max-shard-mib 700 --min-duration 60 --max-duration 600
```

초기 수집은 예측 가능한 용량 제한을 위해 첫 Parquet shard 한 개를 내려받아 최대 5개 후보를 추출하는 방식이다. 첫 파일은 조회 당시 493,919,884 bytes (약 471 MiB)였다. `--max-shard-mib`는 선택한 shard 크기 합계의 상한이며, 통신 재시도에 따른 실제 트래픽 상한은 아니다. 캐시된 shard와 추출한 MP4가 함께 저장되므로 디스크 사용량에는 두 항목이 포함된다.

전체 데이터셋은 다운로드하지 않는다. 기본 범위에서 적합한 후보가 없으면 그 사실을 보고하고 다음 shard를 검토한다. 자동으로 전체 데이터를 순회하지 않는다. 접근 가능한 현재 revision을 조회한 뒤 해당 실행의 다운로드 revision을 고정하여 manifest에 기록한다.

이번 후보를 나중에 다시 받을 때는 dataset revision도 지정한다. 현재 `longcond` 기준이며, 다운로드한 shard가 있으면 캐시를 재사용한다.

```bash
../.venv/bin/python feasibility_long_context/download_finevideo.py --revision 84c74091e1c6ee7a5dffabfafb5c9033e4718883 --max-videos 5 --max-shards 1 --max-shard-mib 700 --min-duration 60 --max-duration 600
```

## 저장 형식

```text
data/finevideo_candidates/<sample_id>/
    source.mp4
    finevideo_metadata.json
    provenance.json
data/finevideo_candidates/manifest.json
reports/finevideo_access.json
```

`provenance.json`에 dataset revision, shard와 row 위치, 원본 식별자, SHA256, 해상도와 FPS를 기록한다. 메타데이터의 영상 길이로 후보를 추리고 첫 프레임 디코딩을 확인한다. 이 확인만으로 전체 영상의 무결성이나 장거리 의존성 검증이 완료된 것은 아니다.

수집 시점의 후보는 `unreviewed`로 저장한다. 후속 검토는 [실험 설정](configs/pilot_examples.json)과 각 실험 `metadata.json`의 `review`에 기록한다. 실제 영상 확인 없이 oracle 또는 실험 완료 사례로 표시하지 않는다. 원본 메타데이터는 자동 생성되어 후보 선정에만 참고하며, 전체 영상 설명이나 Q&A의 미래 정보를 생성 조건에 넣지 않는다.

## 미리보기 및 클립 재생성

부모 LTX 저장소 루트 기준:

```bash
.venv/bin/python longcond/feasibility_long_context/preview_candidates.py
.venv/bin/python longcond/feasibility_long_context/prepare_clips.py
```

현재 `longcond`에서 실제 실행한 명령:

```bash
../.venv/bin/python feasibility_long_context/download_finevideo.py --check-access
uv --cache-dir /tmp/ltx-longcond-uv-cache pip install --python ../.venv/bin/python --target feasibility_long_context/.deps pyarrow==21.0.0
../.venv/bin/python feasibility_long_context/download_finevideo.py --max-videos 5 --max-shards 1 --max-shard-mib 700 --min-duration 60 --max-duration 600
../.venv/bin/python feasibility_long_context/preview_candidates.py
../.venv/bin/python feasibility_long_context/prepare_clips.py
```

특정 구간을 자세히 볼 때는 `preview_candidates.py --candidate fv_84c74091_0000_00000 --start 168 --end 184 --frames 32`처럼 지정한다. 각 미리보기의 JSON 로그에 실행 명령과 요청/디코딩 타임스탬프를 남긴다.

`prepare_clips.py`는 기본 `configs/pilot_examples.json`을 읽는다. 입력 MP4와 revision을 검증하고, 구간 내 프레임으로만 24 FPS 클립을 만든 뒤 전체 클립 디코딩을 확인한다. 반복 실행하면 해당 설정의 파생 클립, 메타데이터, 보고서를 재생성한다. 원본 MP4는 수정하지 않는다.

```text
data/pilot_000_local_cooking/       # local-only 진단
data/pilot_001_interview_return/    # 참조 활용 진단
data/pilot_002_interview_return/    # 참조 활용 진단
    source.mp4                    # 원본 후보를 가리키는 상대 symlink
    metadata.json                 # prompt, 시간, 검토 한계, 원본 프레임 대응
    local_context.mp4
    gt_target.mp4
    oracle_context.mp4            # 참조 진단만
    random_context.mp4            # 참조 진단만
reports/pilot/index.html
reports/pilot/preparation.json
```

## 다음 판단과 최신 재현

원본 전체 Past 참조의 prompt 3종 비교는 완료했다. [NEXT_STAGE.md](NEXT_STAGE.md)는 관리자 Video/Past P0↔P1과 차량 Video/Past P1↔P2처럼 동일 참조에서 결과가 달라진 두 쌍의 진단을 미실행 후보로 남긴다. 피사체 추출/시트는 기본 경로에서 제외하고, 배경도 필요한 정보로 유지한다. 상태·사건·복수 증거와 전역 메모리의 직접 생성/검색 기여는 여전히 미검증이다.

Prompt 실행·평가·보고서 재현 명령은 [PROMPT_CONTROL_RESULT.md](PROMPT_CONTROL_RESULT.md)에 있다. 고정 설정은 `configs/five_case_prompt.json`, ledger/snapshot은 `outputs/five_case_prompt_batch/`, 결과는 `reports/five_case_prompt/seed42/`다. 서버는 기존 8765 포트를 사용한다.

## 이전 5개 2×2 재현

기준 디렉터리는 `longcond`다. 기존 이미지·Local·prompt cache와 완료된 생성을 재사용한다. 새 영상 cache와 출력은 별도 디렉터리에 저장한다. 자세한 입력 통제와 검증은 [결과 문서](FIVE_CASE_GRID_RESULT.md)에 있다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_grid_batch.py --phase prepare
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_grid_batch.py --phase generate
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_five_case_grid.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_five_case_grid_report.py
```

## 이전 5개 Local/Oracle 비교 재현

기준 디렉터리는 `longcond`다. 기존 입력/출력은 덮어쓰지 않는다. 최초 원본 추출·clip 준비는 [프로토콜](FIVE_CASE_PROTOCOL.md), 결과·오류 복구는 [결과 문서](FIVE_CASE_RESULT.md)를 따른다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_batch.py --phase generate
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_five_cases.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_five_case_report.py
```
