# Stage 2: 생성에 직접 기여하는 Addressable Global Memory

2026-09-08. **초기 설계 문서이며 메모리 구현·학습 실행 결과가 아니다.** 사용자는 마지막 긴 입력 비교에서 품질·계산 이점을 확인했다고 보고, feasibility를 여기서 마무리하고 메모리 구축 단계로 넘어가자고 제안했다. Assistant도 전환이 타당하다고 판단한다. Stage 1 정식 생성 120회와 동결 산출물을 보존하고 추가 offset/seed 탐색을 확장하지 않는다.

[Stage 1 최종 결과](LONG_INPUT_RESULT.md) · [실제 입력·출력](reports/long_input/index.html)

## VRAM 차이가 작게 보인 이유

이번 결과는 512×288, 24 FPS, inference mode, 분리 VAE/decoder 프로세스에서 측정했다. 모델 상주 baseline에는 transformer뿐 아니라 이미 전송한 text/condition tensor도 포함된다. 순수 weight byte 수와 같다고 표현하지 않는다.

| PyTorch allocated 측정량 | Native 32초 | Oracle chunk |
|---|---:|---:|
| 상주 모델·조건 baseline | 약 35.392 GiB | 약 35.389 GiB |
| baseline 이후 peak 증가 | 3.624 GiB | 0.887 GiB |
| denoising 전체 peak | 39.016 GiB | 36.276 GiB |

전체 감소는 7.02%지만 baseline 위의 증가분은 75.52% 줄었다. 고정비가 큰 추론 설정이라는 점이 주된 수치적 설명이다. 증가분에도 Target·audio 등 공통 항목이 있으므로 전부 “과거 전용 activation”으로 해석하지 않는다.

VAE 압축도 크다. 설치된 코드의 기본 stride는 시간 8, 높이 32, 너비 32이며 실제 캐시 shape도 이와 일치한다. 연속 과거 32초는 첫 프레임 padding 후 RGB 769×288×512에서 **97×9×16, 128채널** latent가 됐다. 이 BF16 latent 자체는 약 **3.41 MiB**다. 이후 transformer hidden state와 attention 계산의 메모리는 이보다 훨씬 크다. 시공간 격자 수는 약 8×32×32배 줄지만 채널·dtype이 달라 RGB byte 압축률이 8,192배라는 의미는 아니다.

긴 입력은 O보다 video token을 약 4.24배 많이 처리하므로 latent 원본 저장이 작더라도 계산량은 크다. Full-reference/O의 token 비율은 약 4.28배다. 현재 경로는 PyTorch SDPA이며 실제 fused kernel 선택은 이번 로그에서 별도 확정하지 않았다. SDPA는 여러 구현을 선택할 수 있으므로 이론적인 N² attention pair 수를 실제 N² 메모리 할당과 동일시하지 않는다. [PyTorch SDPA 문서](https://docs.pytorch.org/docs/2.14/generated/torch.nn.functional.scaled_dot_product_attention.html)

학습에는 backward를 위한 activation과 학습 파라미터의 gradient/optimizer state가 추가된다. LTX weight를 고정해도 생성 loss를 메모리까지 역전파하려면 연결된 LTX 연산의 gradient 경로가 필요하다. 기존 inference wrapper 전체를 `no_grad`로 사용하면 이 경로가 끊긴다. 현재 7% 절감을 학습이나 더 긴 영상에 그대로 외삽하지 않는다. [PyTorch Autograd 문서](https://docs.pytorch.org/docs/2.14/notes/autograd.html)

## 첫 단계에서 고정할 입출력

첫 작업은 **전체 과거를 읽어 고정 개수 memory token과 원본 대응을 만드는 모듈의 인터페이스**를 정하는 것이다. 메모리 파일을 평균 pooling으로 만드는 것만으로 연구 목표가 충족되지는 않는다. 학습으로 생성에 유용한 정보를 보존하고, 원본 증거 위치도 찾을 수 있어야 한다.

```text
전체 관측 과거 X
  ├─ frozen LTX VAE ─────────────────────────── 원본 latent bank
  ├─ VAE / V-JEPA2 / semantic features
  │       └─ projection + learned fusion
  │                └─ memory compressor ── M: 고정 개수 memory tokens
  │                         └─ memory-to-source 대응
  │
Local + prompt + noisy Target
  └─ LTX generation query ── attention to M
            ├─ memory readout ── 직접 생성 조건
            └─ source relevance ── chunk 선택 ── bank의 세부 latent 회수
```

| 항목 | 첫 설계안 |
|---|---|
| 과거 입력 | `[0,T)`의 전체 프레임 특징, 원본 timestamp/구간 ID, padding mask. GT 미래/미래를 서술한 텍스트 제외 |
| 메모리 내용 | 내용과 시간/공간 위치를 함께 읽는 학습된 token 집합. 의미 범주별 slot을 수작업으로 나누지 않음 |
| 크기 후보 | 우선 K=128, hidden dimension 512의 작은 인터페이스를 후보로 두고 parameter/activation 예산 확인. 실험 설정으로 동결한 값은 아님 |
| 출력 | `memory[B,K,d]`, valid mask, 원본 구간 manifest, `memory_to_source` 조회 인터페이스 |
| 원본 증거 | 별도 VAE latent bank에 유지. 선택된 실제 latent와 원래 source 좌표를 회수 |
| 시간 표현 | 원본의 순서/상태를 보존. 메모리를 Target 프레임과 동일한 clean VAE token으로 취급하지 않음 |
| 현재 Local/prompt | 재사용 가능한 source memory 구축과 구분하고, 생성 query 및 memory readout에 사용 |

최종 연구의 VAE·V-JEPA2·semantic feature fusion 방향은 유지한다. 첫 구현의 tensor/gradient 연결 확인에는 이미 있는 VAE cache부터 사용할 수 있다. 이는 개발 순서와 VAE-only baseline이며, 세 표현을 포함한 연구 방향을 VAE-only로 확정한다는 뜻은 아니다. V-JEPA2와 semantic encoder의 구체적인 모델·sampling·특징 차원은 다음 구현 전에 로컬 자원과 API를 확인해 정한다.

## 압축과 주소 대응의 구현 방향

후보 구조는 작은 learned query 집합이 전체 source feature에 cross-attention하고, memory token끼리 정보를 섞는 resampler다. 긴 source 전체에 N×N self-attention을 반복하지 않도록 설계한다. 원본 대응을 유지한 chunk별 특징 집약 또는 계층적 fusion도 검토하되 배경·물체·사람의 의미 정보를 사전 제거하지 않는다.

생성 query → memory attention과 memory → source 대응을 합성해 source relevance를 얻는 원안을 유지한다. 다층 fusion/residual/self-attention으로 정보가 섞이면 마지막 한 층의 attention이 메모리 내용 전체의 정확한 출처는 아니다. 명시적인 source-address readout을 두고 구간 supervision과 실제 검색 성능으로 대응을 검증한다. 이를 인과적 기여도로 부르지 않는다.

K×N 대응까지 GPU에 항상 보관하면 전체 시스템이 길이에 대해 고정 메모리가 되는 것은 아니다. generation-side memory token 예산과 source feature/bank/address 저장 비용을 분리한다. 전체 attention map의 일괄 저장 대신 source chunk별 점수 계산·집약 등 구현 옵션을 다음 단계에서 확인한다.

## LTX 연결과 첫 학습 검증

직접 생성 경로의 후보는 LTX hidden state가 M을 읽는 학습 가능한 cross-attention adapter다. 학습된 memory feature를 기존 VAE latent와 같은 채널/분포라고 가정하여 그대로 concat하지 않는다. adapter의 삽입 층, normalization, gating, memory 위치 표현은 실제 LTX block API와 gradient 경로를 확인해 결정한다. 원본 evidence 입력은 Stage 1에서 확보한 별도 경로를 재사용하되 후속 학습에서 새 구도/동작 활용을 계속 검증한다.

첫 최소 학습은 **LTX·사전학습 encoder weight를 고정하고 projection/fusion/compressor/direct-conditioning adapter를 학습**하는 안이다. 입력 feature encoder는 frozen cache로 분리할 수 있지만 LTX를 거쳐 M으로 돌아오는 gradient는 유지한다. 처음에는 retrieval 선택을 Oracle로 고정해 생성 학습과 hard selection의 불연속성을 동시에 디버깅하지 않는다. memory-only 예시 또는 evidence dropout을 함께 포함할지 정해, Oracle만으로 loss를 줄이며 메모리를 무시하는 현상을 진단한다.

생성 loss를 중심에 두고 source-address loss를 보조로 둔다. 현재 8-step distilled inference를 그대로 학습 objective로 옮기거나 8 step 전체를 무조건 unroll하지 않는다. 현재 checkpoint와 설치된 trainer의 timestep/flow parameterization·학습 가능 경로를 확인한 뒤 1 minibatch forward/backward 검증부터 시작한다. 새로운 체크포인트 다운로드나 전체 LTX fine-tuning은 이번 설계에서 실행하지 않았다.

첫 구현의 완료 조건은 다음과 같다.

1. 원본 길이·padding에 관계없이 정한 K의 memory를 만들고, valid source 위치로 다시 대응할 수 있다.
2. 미래 입력이 없고 source index/구간 manifest와 bank가 일치한다.
3. 생성 loss의 유한한 gradient가 adapter·compressor·fusion까지 도달하고 고정 weight에는 gradient가 누적되지 않는다.
4. memory를 끄거나 다른 source memory로 바꾸는 개입을 구분할 수 있다. 단순 tensor 연결 성공과 유용한 기억 학습 성공을 분리한다.

이 문서는 위 작업의 설계 착수이며 이 네 항목을 이미 실행해 통과했다는 기록이 아니다.

## 메모리의 두 기여를 분리할 평가

| 조건 | 확인할 질문 |
|---|---|
| Local | 현재 문맥만으로 어디까지 생성하는가 |
| Local + memory | 압축된 전체 문맥이 생성에 직접 기여하는가 |
| Local + 같은 Oracle evidence | 원본 세부 증거만의 기여는 무엇인가 |
| Local + memory + 같은 Oracle evidence | **증거를 고정해도** memory가 추가 정보를 주는가 |
| Local + memory + 선택한 evidence | memory 직접 조건을 유지하면서 학습한 선택이 얼마나 유용한가 |

동일하게 학습한 모델에서 조건을 끄는 개입과, 각각 따로 학습한 ablation을 구분한다. 학습 시 보지 못한 memory-off 조건만으로 기여를 단정하지 않도록 dropout/훈련 조건을 함께 설계한다. 외관 이외의 상태·사건·여러 구간 의존을 포함하고 source 단위로 학습/검증 영상을 분리한다. 현재 진단용 5개는 최종 held-out benchmark로 쓰지 않는다.

## 더 긴 영상으로 확장

사용자의 방향대로 후속 학습/평가에서 입력 과거 길이를 늘린다. **32초에서 연결·gradient 확인 후 60초, 120초, 필요하면 180초**로 확장하는 안을 우선 검토한다. 이는 아직 동결하거나 실행한 length sweep이 아니다. 초기 Target은 3–5초로 유지해 입력 문맥 확장과 출력 길이 확장의 영향을 분리한다.

의존 거리를 고정하고 방해 과거를 늘리는 비교와, 총 길이를 고정하고 필요한 증거를 멀리 두는 비교를 구분한다. 길이만 늘어나고 정답이 Local에 계속 있으면 장거리 기억 과제의 근거가 약하다. memory K와 evidence 예산을 공통으로 두고 품질·시간·전체/추가 VRAM, feature/bank/memory 준비 비용, forward/backward/optimizer 비용을 측정한다. 더 긴 입력에서 이점이 커질 가능성은 있지만 증가율과 학습 가능 길이는 실측 전에는 단정하지 않는다.

새 구현은 `longcond/memory_stage2/` 등에 격리하고 Stage 1 코드·설정·산출물은 보존한다. GPU 허용 범위는 0–4번이다. 이번 턴은 종료 판단과 설계를 기록했으며 신규 생성·특징 추출·학습 job은 실행하지 않았다.
