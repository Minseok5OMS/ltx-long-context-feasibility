# 긴 입력과 선택 chunk 비교 — 25조건 완료

2026-09-08. 신규 **25회 완료**, 기존 95회와 정식 누적 **120회**. [실제 입력·영상 비교](reports/long_input/index.html) · [측정 CSV](reports/long_input/results.csv) · [사전 설계 원본](LONG_INPUT_VS_SPARSE_PROTOCOL.md)

**결론: 필요한 과거 chunk를 선택하는 방식의 품질·계산 이점은 부분적으로 확인했다.** Oracle-sparse는 긴 입력 두 방식에서 드러나지 않던 직원·로봇·차량의 외관을 드러냈고, 로봇은 손으로 조작하던 참조를 독립된 display 구도와 결합했다. Denoising은 Native-Full보다 median **4.66배**, Full-reference보다 **4.70배** 빨랐다. 전체 peak allocated VRAM은 약 **7%**, 모델 상주 baseline 대비 증가량은 약 **76%** 감소했다.

학생의 시점 전환, 보존 작업자의 얼굴 전체 노출, 차량의 주행은 해결하지 못했다. 보육원 직원·차량은 참조 구도/장면도 상당히 따라간다. 따라서 범용 속성 활용이나 연구 전체의 성공 판정은 아니다. 압축 전역 메모리의 직접 생성 효과와 자동 검색은 후속 단계에서 별도로 검증해야 한다.

## 실제 비교와 입력 방식

같은 FineVideo 원본의 연속 과거 `[T−32,T)`에서 다음 3초를 생성했다. H는 앞 30초, Local은 마지막 2초다. 참조의 사람·물체·배경을 제거하지 않았고, 과거 참조를 Target 좌표로 옮기지 않았다.

| 조건 | 생성기에 넣은 내용 | 전체 video token 수 |
|---|---|---:|
| L · Local-only | 독립 Local 2초 clean prefix + Target noise | 2,304 |
| N · Native-Full | 연속 과거 32초를 인코딩한 clean prefix + Target noise | 15,264 |
| F · Full-reference | H 30초 전체를 별도 참조 token으로 추가 + 독립 Local | 15,408 |
| O · Oracle-sparse | F의 H bank에서 필요한 연속 9 latent frame 선택 + 독립 Local | 3,600 |
| U · Uniform-sparse | 같은 H bank의 중앙 고정 index 41–49 선택 + 독립 Local | 3,600 |

O/U는 원본 시간 좌표를 보존한 **F의 정확한 부분집합**이다. U는 균등 위치 규칙의 중앙 단일 chunk이며 9장을 전체 시간에 흩뿌리는 방식이 아니다. N/O는 실제 입력 방식 비교이고 F/O는 같은 bank에서 불필요한 token을 덜어낸 비교다. N/F는 연속 인코딩과 독립 Local 경계 차이를 확인하는 보조 비교다.

연속 RGB 768프레임을 실제로 읽었다. VAE는 첫 RGB를 한 번 padding한 769프레임(N), 721프레임(H), 49프레임(Local)을 공식 `VideoEncoder.tiled_encode`로 처리했다. Temporal tile 80, overlap 24이며 공간 tile은 사용하지 않았다. 긴 영상을 짧은 클립 반복으로 만들지 않았다. Transformer는 전체 N/F token을 매 denoising step에 받는다.

모든 조건의 Target 좌표는 실제 저장값으로 동일하며 `[769/24, 841/24)`초다. Local은 `[30,769/24)`, H bank는 `[0,721/24)`이므로 첫 padding에 따른 1/24초의 경계 겹침이 있다. N의 Local tail은 연속 인코딩이므로 F/O/U의 독립 Local과 동일 latent라고 가정하지 않는다. Sparse가 선택한 9 latent에는 VAE temporal receptive field의 주변 H 정보도 들어갈 수 있어 **RGB 3초만 인코딩한 조건**으로 해석하면 안 된다.

## 생성 전에 동결한 사례

| 사례 | Target 시작 T | Oracle 명목 구간 | 변경·해석상 제한 |
|---|---:|---|---|
| 보육원 직원 | 109.8431s | 83.1764–86.1764s | 이전 관리자와 다른 직원의 재등장 컷. 같은 직원의 더 가까운 노트북 장면도 H에 있음 |
| 로봇 | 260s | 237.3333–240.3333s | Local은 몸통/뒷머리, Oracle은 앞면. 원본 후속은 요청한 display 구도의 GT가 아님 |
| 학생 | 124.5833s | 106.25–109.25s | U와 O가 9개 중 8개 latent index를 공유함 |
| 차량 | 308s | 276–279s | Oracle은 남성 selfie와 주차한 밴. 외부 차체 노출과 주행 성공을 구분 |
| 보존 작업자 | 110.4667s | 86.1333–89.1333s | Oracle에 측면 얼굴과 손 장면/자막이 함께 존재. H에는 다른 작업자도 존재 |

기존 Oracle 4개가 직전 32초 밖에 있어 구간을 재검토했다. 직원/로봇의 T를 변경하고 나머지 3개는 T를 유지했다. 5개 모두 단일 약 3초 chunk이며 자연스러운 복수 증거 의존은 확립하지 못했다. Prompt·평가 속성·구간·seed는 새 결과를 보기 전 [설정](configs/long_input_cases.json)에 동결했고 이후 조정하지 않았다. SHA256: `bdba61857111a43b2576f725d2be1dc262ee88480e40f30a49f712df5060d75f`.

## 정성 결과

1차는 조건명을 확인하기 전 25개 출력의 7개 시점과 주요 8개 출력의 전체 72프레임 sheet를 읽었다. 조건명 매핑 후 나머지 17개 전체 sheet도 확인했다. **Assistant의 전체 프레임 검토이며 실시간 영상 재생을 관찰한 독립 사람 평가는 아니다.** 미세한 identity와 동작은 비교 페이지의 전체 3초 재생으로 재검토할 수 있다. [조건명 확인 전 관찰](reports/long_input/review_blind.json) · [조건별 근거·평가](reports/long_input/review.json) · [25조건 점수 CSV](reports/long_input/qualitative_scores.csv)

| 사례 | Local / Uniform | Native / Full-reference | Oracle-sparse | 판단 |
|---|---|---|---|---|
| 직원 | 방문 평가자의 금발 close-up 지속 | 동일하게 방문 평가자 지속 | 묶은 어두운 머리·빨간 셔츠/남색 조끼의 직원 재등장 | 필요한 외관 긍정. 참조와 비슷한 구도이며 요청한 측면 close-up은 약함 |
| 로봇 | L은 독립 display지만 둥근 은색 얼굴. U는 뒷면 display | 손으로 조작하며 머리가 상단에서 잘림 | 각진 helmet·작은 금색 앞면·어깨를 독립 display와 결합 | 외관 + 새 구도의 가장 명확한 긍정. 초반 dissolve 존재 |
| 학생 | 교사 앞면/학생 뒷면 유지 | 같은 실패 | 같은 실패 | 필요한 얼굴 미노출. 틀린 얼굴 생성으로 단정하지 않음 |
| 차량 | 내부 운전 시점 유지 | 내부 운전 시점 유지 | 밝은 각진 차체·어두운 전면과 외부 장면을 노출 | selfie/주차 구도 재현, 긴 dissolve. 주행 성공은 아님 |
| 보존 작업자 | 측면 얼굴은 보이나 갈색 머리·안경 없음 | 작업대/손의 겹친 영상이 지속 | 회색 머리/안경 일부만 상단에 잘림, 손·몸통 및 자막 | 부분적 변화. 얼굴 전체/요청 구도 성공은 아님 |

사전 예시 rubric(증거·구도/행동·연결 각각 0–2)을 적용했다. 핵심 증거 축에서 O는 N/F 각각에 **명확한 개선 3개, 부분적 개선 1개, 공동 실패 1개**다. O/U에서도 명확한 외관 차이는 직원·로봇·차량에 있다. 학생에서는 O/U의 높은 겹침과 공동 실패 때문에 선택 필요성의 근거가 되지 않는다.

사전의 “최소 두 원본에서 정보 추가 기여, 그중 새 장면 수행 예 존재”와 비용 목표는 이 assistant 평가에서 충족하는 방향이다. N/F 대비 5개 모두 증거 점수가 낮아지지는 않아 품질 유지 **후보**로 볼 수 있다. 다만 실패끼리의 동률도 포함하고 O의 장면 전환에 잔상이 있어 일반적인 영상 품질 우위를 뜻하지 않는다. 특히 L/U의 보존 작업자 영상은 더 깨끗한 새 구도를 만들지만 과거 외관이 다르다.

배경 유지 자체는 실패로 세지 않았다. 차량은 요청한 주행 대신 주차/selfie가 재현된 점, 직원은 요구한 측면 close-up 대신 과거 구도가 유지된 점을 제어 한계로 기록했다. 내부 attention을 계측하지 않았으므로 Full의 실패를 attention 희석 또는 특정 시간 embedding 기전으로 확정하지 않는다.

## 실행 시간과 메모리

25조건 모두 **동일 물리 GPU 0**, 조건별 새 프로세스, 별도 새 decoder 프로세스로 순차 실행했다. GPU는 RTX PRO 6000 Blackwell Server Edition이다. LTX 2.5 22B distilled BF16, 512×288, 24 FPS, Target 72프레임, 8-step Euler ancestral, eta=1, s_noise=1, torch SDPA, SimpleDenoiser를 유지했다. CFG/STG/LoRA/prompt enhancement는 없다. Audio shape/좌표/noise도 동일하게 통제했고 35초 audio를 추가 생성하지 않았다. 아래는 5사례별 측정값의 median이며 반복 벤치마크의 신뢰구간은 아니다.

| 항목 | Local | Native | Full-reference | Oracle | Uniform |
|---|---:|---:|---:|---:|---:|
| Denoising, s | 2.719 | 18.035 | 18.181 | 3.868 | 3.868 |
| Forward CUDA 합, s | 2.657 | 17.966 | 18.114 | 3.803 | 3.802 |
| Peak allocated, GiB | 35.970 | 39.016 | 39.049 | 36.276 | 36.276 |
| 상주 baseline 대비 증가, GiB | 0.582 | 3.624 | 3.656 | 0.887 | 0.887 |
| Peak reserved, GiB | 40.514 | 43.154 | 43.180 | 40.607 | 40.607 |
| Device peak, GiB | 41.229 | 43.869 | 43.895 | 41.322 | 41.322 |
| 실행 본체: 로딩·검사·decoder 포함, s | 20.764 | 36.081 | 36.227 | 21.924 | 21.874 |
| 별도 VAE/text 준비: 로딩 포함, s | 13.779 | 16.470 | 17.091 | 17.091 | 17.091 |
| 준비 + 실행 본체의 개별 측정 합, s | 34.543 | 52.536 | 53.314 | 39.010 | 39.072 |

각 행을 따로 median 내므로 마지막 행이 앞 두 median의 정확한 합일 필요는 없다. [전체 측정](reports/long_input/summary.json) · [사례별 비율과 median](reports/long_input/cost_analysis.json)

- 사례별 N/O, F/O denoising 비율의 median은 **4.663× / 4.703×**다. 전체 allocated 감소는 **7.02% / 7.10%**, 증가분 감소는 **75.52% / 75.73%**다. 상주 모델 baseline 약 35.39 GiB가 큰 부분을 차지한다.
- Device peak는 로딩/검사까지 포함한 100ms 간격 GPU 전체 사용량 표본의 최댓값이며 감소는 **5.81% / 5.86%**다. PyTorch allocated/reserved와 같은 측정량이 아니다.
- 실행 본체는 약 **1.65×** 빠르다. VAE/text 준비까지 더한 구성요소 합의 비율은 **1.35× / 1.37×**다. 이는 별도 프로세스의 측정값을 더한 수치이며 단일 요청의 cold end-to-end 실측으로 부르지 않는다. Python 시작과 source ingest/검토용 영상 제작은 별도다.
- O도 F와 같은 **전체 H bank 구축 비용을 지불했다.** 3초만 인코딩한 것처럼 준비 비용을 제거하지 않았다. 자동 검색과 전역 메모리 구축 비용은 구현되지 않아 포함되지 않았다.
- Decoder는 모두 마지막 conditioning 7 + Target 9 latent만 처리하고 Target 72프레임을 사용했다. Native 전체 35초를 decode해 baseline 비용을 부풀리지 않았다. 실제 decoder 작업은 약 3.8초다.
- F/O video token 비율은 4.28×, video attention pair 수의 이론 비율은 18.32×다. 이 수치를 실측 속도나 메모리 감소 비율로 대체하지 않는다.

## 보조 DINO 평가와 해석

기존 캐시 DINOv2 ViT-B/14로 출력당 12개 프레임의 GT 유사도와 Oracle 표본 중 최대 유사도를 계산했다. 전체/1초 이후 값을 저장했다. [수치](reports/long_input/dino_metrics.json) · [모델·전처리·GPU 2 평가 기록](reports/long_input/evaluation_provenance.json)

GT 전체 유사도는 identity 점수가 아니다. 직원 O는 필요한 직원을 생성했어도 GT의 close-up과 구도가 달라 0.394로, 방문 평가자를 유지한 N의 0.611보다 낮다. O의 Oracle 유사도는 약 0.917로 높으며 참조 구도 재현을 함께 반영한다. 학생도 Oracle에 교사 앞면이 포함돼 실패 출력의 Oracle 최대 유사도가 높다. 로봇은 **원본 후속이 요청한 display의 GT가 아니라는 사실을 생성 전에 동결**했고 GT 순위를 제외했다. 로봇 U의 뒤쪽 display 역시 전체 Oracle 유사도가 높을 수 있어 앞면 helmet 확인을 대체하지 못한다.

인접 프레임 pixel 변화량도 저장했지만 주행·물리적 동작 성공 점수가 아니다. 로봇의 고정 display는 prompt가 요청한 동작이므로 정적이라는 이유만으로 실패 처리하지 않았다.

## 검증과 산출물

[25조건 저장 artifact 감사](reports/long_input/artifact_verification.json)가 통과했다. 실제 입력 RGB/PTS와 GT 분리, cache 부분집합, 공통 prompt/설정, 실제 Target 초기 state와 7회 step noise, 실제 좌표, audio, 8-step의 clean token 고정 오차 0을 검사했다. 출력 75개 영상의 **7,825프레임**을 전부 decode했고 이 중 새 Target은 **1,800프레임**이다. 25조건 모두 denoising/decoder 완료이며 OOM은 없었다.

실제 GPU Target 좌표는 조건 간 bit 단위로 같고, Sparse 참조 좌표도 실제 F 좌표의 정확한 부분집합이다. CPU 이론좌표 재계산은 CUDA float32 division과 최대 3.8147e−6초 차이가 있어 4e−6 허용오차를 쓴다. 실제 조건 간 검사는 여전히 정확 일치다. 이 감사 수정으로 생성 코드를 바꾸거나 결과를 재생성하지 않았다.

첫 Native preflight는 `apply_to` keyword 인자명 차이로 denoising 이전에 중단됐고 [실패 시도](outputs/long_input/failed_preflight/native_full_keyword_api/)에 보존했다. 실제 API 호출을 고치고 CPU preflight를 통과한 뒤 25조건을 실행했다. 이 중단을 정식 생성으로 세지 않는다.

- 동결 설정: `configs/long_input_cases.json`
- 실행 시점 코드: `outputs/long_input/source_snapshot/`와 manifest
- 실제 입력: `data/long_input/<case>/`; RGB 배열과 metadata, H/Local/Oracle/Uniform/GT 표시 영상
- Cache 20개: `outputs/long_input/cache/<case>/`; local/history/native/text
- 출력: `outputs/long_input/seed42/<case>/<condition>/`; config, latent, 실제 noise/좌표, GPU CSV, MP4
- 명령/진행 로그: `outputs/long_input/batch/`; 각 config에도 정확한 command와 cwd 기록
- 결과 페이지: `reports/long_input/index.html`; 입력 5개와 출력 5개씩, A–E 조건 가리기, 전체 72프레임 sheet, 5조건 비교 MP4

연결 문서는 UTF-8 HTML로 제공하며 MD 원문은 저장용 링크로 구분했다. 입력 25개에도 실제 중간 시점 미리보기를 넣었다. Firefox 화면에서 한글·입력·A–E 결과·timeline·재생/조건 공개 버튼 표시를 확인했다. 정적 화면 검사이며 동기 재생 버튼의 실제 상호작용이나 사용자 PC의 포트 전달 검증은 아니다. [브라우저 기록](reports/long_input/browser_verification.json) · [HTML/영상 HTTP 검사](reports/long_input/delivery_verification.json) · [동결 코드 11개 무변경 검사](reports/long_input/source_integrity_verification.json)

실행 기준 디렉터리는 `/mnt/minu/minseok/LTX-2/longcond`이다. 아래 batch는 완료한 job을 건너뛴다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/prepare_long_input_data.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_long_input_batch.py --phase cache --gpu 0
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_long_input_batch.py --phase generate --gpu 0
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/verify_long_input.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_long_input.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_long_input_report.py --assets
```

이후 사용자가 GPU **0–4번** 사용을 허용했다. 이번 비용 비교는 이미 GPU 0으로 완료했고 동결 설정을 소급 변경하지 않는다.

## Stage 1을 어디까지 정리할 수 있나

이번에 승인된 마지막 25조건 실행·평가를 완료했다. **필요한 증거 선택이 frozen LTX의 정보 활용에 도움이 되는 사례가 있고, 전체 입력보다 계산 비용을 줄인다는 근거**를 확보했다. 수십 초 입력을 기술적으로 받는 것과 그 안의 증거를 요청대로 활용하는 것은 구분해야 한다.

다섯 원본·단일 seed·32초·단일 chunk의 진단이며, 성공 가능성을 이미 살펴본 원본을 재사용했다. 보육원 직원처럼 증거가 여러 번 나타나는 경우 선택한 chunk와 Target의 간격이 유일한 의존 거리를 뜻하지 않는다. 시간 길이 증가에 따른 scaling, 상태·사건·상보적 복수 증거, 학습된 검색의 정확도는 미검증이다.

다음은 작은 offset/seed 탐색을 자동 추가하는 대신, **압축 전역 메모리의 직접 생성 조건과 증거 선택을 분리할 후속 설계**를 정하는 단계다. 같은 Oracle 증거를 고정하고 메모리 직접 조건 유무를 비교하는 축을 반드시 남긴다. 이 문서는 후속 학습·adapter 실행 승인이 아니며 현재 새 학습은 시작하지 않았다. [다음 단계 판단](NEXT_STAGE.md)
