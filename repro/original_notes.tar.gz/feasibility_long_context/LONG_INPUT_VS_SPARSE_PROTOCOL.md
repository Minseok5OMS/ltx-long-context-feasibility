# Stage 1 마지막 비교: 긴 과거 입력과 Oracle chunk 선택

2026-09-08. **설계안이며 미실행이다.** 사용자 요청은 30초 이상의 필요한 증거를 포함한 영상 전체를 넣는 방식과, 그 영상에서 필요한 frame chunk만 가져오는 방식의 정보 활용·시간·메모리 비교다. 이전 0/2/4초 offset 비교는 진행하지 않는다. 기존 정식 생성은 95회다.

## 검증할 주장

목표는 “긴 입력이 실패해야 한다”가 아니라 **필요한 정보 활용과 새 장면 생성 품질을 유지하면서 생성 비용을 줄일 수 있는가**다. Sparse가 전체 입력보다 품질도 좋으면 추가적인 이점이다. 전체 입력과 Sparse가 모두 실패한 결과는 효율만으로 성공 처리하지 않는다.

세 질문을 분리한다.

1. 전체 과거를 제공한 LTX가 필요한 외관/장소/물체 정보를 현재 요청에 맞게 사용할 수 있는가?
2. 같은 과거의 필요한 chunk만 제공해도 품질을 유지하거나 개선하는가?
3. 이는 아무 구간이나 적게 넣은 효과를 넘어서는가? 실제 denoising 시간과 GPU 메모리가 얼마나 줄어드는가?

이 비교는 Oracle 선택을 가정한 **원본 증거 입력 경로**의 feasibility다. 검색 정확도, 검색 비용, 학습된 전역 메모리의 직접 생성 기여는 측정하지 않는다. 전역 메모리의 직접 조건/원본 증거 검색이라는 두 연구 목표는 유지한다.

## 현재 LTX에서 확인한 실행 기반

- 설치된 `ltx_core.conditioning.types.latent_cond.VideoConditionByLatentIndex`는 여러 latent frame을 clean prefix로 고정할 수 있다. 긴 prefix 뒤에 짧은 noise tail을 두고 기존 transformer/denoiser로 생성하는 baseline을 구성할 수 있다.
- 현재 고수준 `DistilledPipeline.__call__`은 `images`를 받으며, 임의의 긴 history를 넣는 전용 인자가 있는 것으로 가정하지 않는다. 기존 실험처럼 `DiffusionStage`와 conditioning을 조합하는 별도 runner가 필요하다. Backbone/가중치는 변경하지 않는다.
- 공식 [PyTorch API 문서](https://docs.ltx.io/open-source-model/integration-tools/pytorch-api)는 native pipeline과 `8n+1` 프레임 제약을 설명하지만, 확인한 페이지에서 30초 이상의 과거 조건 활용 성능을 보장하지 않는다. 긴 영상을 생성/편집할 수 있다는 사실과 장거리 증거 활용은 구분한다.
- **실제 로컬 checkpoint 헤더**의 `transformer.positional_embedding_max_pos`는 `[20, 2048, 2048]`이다. 코드에서 RoPE 좌표 정규화에 쓰이며 20초에서 입력을 잘라내는 hard limit은 아니다. 32초 실험의 품질과 메모리 적합성은 아직 검증되지 않았다. 이를 임의로 32/64로 바꾸지 않는다.
- GPU 0–2는 각각 NVIDIA RTX PRO 6000 Blackwell Server Edition, 표시 총 메모리 97,887 MiB다. 조회만 수행했고 이번 설계에서 모델 로딩/생성은 하지 않았다.

## 데이터: 실제 연속 과거 32초와 마지막 Local 2초

5개 FineVideo 원본을 우선 재사용한다. 각 사례는 Target 시작을 T라 할 때 다음 구조다.

| 부분 | 원본 시간 | 역할 |
|---|---|---|
| 오래된 과거 H | `[T-32, T-2)`의 연속 30초 | Full/Sparse가 정보를 읽을 공통 원본 |
| Local L | `[T-2, T)`의 연속 2초 | 모든 조건에서 현재 상황을 제공 |
| Target Y | `[T, T+3)` | 생성·평가 대상, 입력에 사용 금지 |
| Oracle chunk C | H 안의 약 3초, 1개 또는 복수 구간 | 생성에 필요한 증거, 생성 전에 선택 |

Full의 32초는 **원본의 실제 연속 구간**이다. 서로 먼 장면들을 붙여 32초로 만들거나 반복 영상으로 채우지 않는다. 원본 배경·사람·물체는 모두 유지한다.

### 기존 사례를 그대로 잘라 쓸 수 없는 이유

| 기존 사례 | 현재 T | 직전 32초의 시작 | 기존 Oracle | 기존 Oracle 포함 여부 |
|---|---:|---:|---:|---|
| 관리자 | 130.063 | 98.063 | 48–51 | 미포함 |
| 로봇 | 367.634 | 335.634 | 147–150 | 미포함 |
| 학생 | 124.583 | 92.583 | 107–110 | 포함 |
| 차량 | 308.000 | 276.000 | 138–141 | 미포함 |
| 보존 작업자 | 110.467 | 78.467 | 45.5–48.5 | 미포함 |

따라서 “직전 32초 Full”과 “기존 먼 Oracle”을 곧바로 비교하면 안 된다. 먼저 같은 T의 32초 안에 대체 증거가 있는지 원본으로 검토한다. 없으면 같은 원본에서 T를 다시 정하고 Local/Target/Oracle을 함께 다시 선정한다. 그래도 성립하지 않으면 캐시 원본에서 대체 사례를 고르고 이유를 기록한다. 현재 표는 시간 포함 여부만 확인한 것이며, 대체 Oracle의 유효성을 확인한 결과가 아니다.

선정 조건:

- Local에는 검증할 구체적 정보가 보이지 않고 H에는 명확히 보인다. 넓은 범주가 prompt에 있는 것만으로 성공 처리하지 않는다.
- 가능하면 증거 끝과 T 사이에 10초 이상 간격을 둔다. H의 다른 곳에도 같은 정보가 반복되는지 기록한다. 짧은 실질 의존 거리나 반복 노출을 숨기지 않는다.
- 생성 요청이 과거 프레임의 그대로 재현을 요구하지 않도록 새 구도/행동을 명시한다. 정답 머리 모양·색·안경 등의 속성값은 prompt에 적지 않는다.
- 보존 작업자처럼 새 구도에서 외관을 활용할 수 있었던 원본을 첫 후보로 한다. 성공 가능성이 알려진 원본을 재사용하는 진단이며 독립적인 held-out benchmark라고 부르지 않는다.
- 총 5개 중 가능하면 2개는 서로 떨어진 두 chunk의 상보적인 정보가 필요한 사례로 구성한다. 자연스러운 사례가 없으면 억지로 만들지 않고 단일 증거 진단이라는 한계를 남긴다. 이번 단계에 상태·사건 평가 전체를 추가하지 않는다.
- T/원본 구간/평가 속성/chunk/단일 prompt를 **새 생성 결과를 보기 전에** 동결한다. 이후 조건별로 prompt나 chunk를 바꾸지 않는다. 기존 P1/P2 중 사전 진단에 근거해 선택한 경우도 그 사실을 기록한다.

## 비교 조건: 5사례 × 5조건 = 신규 25회

seed 42 하나로 비교하며 기존 95회 결과는 정성 참고로만 쓴다. 좌표·원본 구간·VAE 경계가 달라지므로 기존 Local 영상을 새 대조군으로 그대로 재사용하지 않는다.

| 조건 | 입력 | 확인할 사항 |
|---|---|---|
| L — Local | 독립 인코딩한 Local 2초 | 참조 없이 가능한 생성 |
| N — Native-Full | 원본 연속 32초를 한 논리적 VAE sequence로 인코딩한 clean prefix + 생성 3초 | 사용자가 요청한 native 긴 입력 baseline |
| F — Full-reference | 과거 H 30초의 전체 VAE token + 공통 Local 2초 | 기존 참조 경로로 전체 과거를 제공한 대조군 |
| O — Oracle-sparse | F의 H에서 고른 약 3초의 token + 공통 Local | 필요한 증거만 가져온 효과 |
| U — Uniform-sparse | F의 H에서 내용과 무관하게 고른 **같은 수/같은 chunk 길이 구성**의 token + 공통 Local | 단순한 저비용 샘플링과 증거 선택의 차이 |

**N↔O는 실제 긴 입력 방식과 Sparse 방식의 비교, F↔O는 같은 입력 경로에서 증거 token 선택 효과를 분리하는 비교**다. N↔F는 연속 prefix와 별도 참조/독립 Local 인코딩의 차이를 보여 준다. N과 O 사이에 품질 차이가 나도, F 없이 그 차이를 token 수 하나로 단정하지 않는다.

U는 새 Random reference가 아니다. 같은 원본에서 고정된 균등 시간 규칙으로 고른다. Oracle 위치를 피해 고르지 않으며 우연히 정답이 포함되면 정직하게 기록한다. U에서도 성공하면 단순 샘플링으로 충분한 사례일 수 있다.

예: O가 9 latent frame의 한 chunk라면 U는 과거의 중앙 9-frame chunk를 사용한다. O가 4+5 frame의 두 chunk라면 U는 과거를 두 균등 구간으로 나눈 각각의 중앙에서 같은 4+5 frame을 취한다. 이 규칙은 생성 전 고정한다. Oracle에 따라 U의 **위치**를 조정하지 않는다.

## 가장 중요한 구현 통제

### 동일한 증거 latent와 좌표

F용 H를 한 번 인코딩해 bank를 만든다. O/U는 이 bank에서 정확한 token과 위치 좌표를 gather한다. Sparse RGB만 다시 인코딩하면 temporal VAE 문맥/경계가 달라지므로 본 비교에 섞지 않는다. 여러 RGB chunk를 붙여 하나의 가짜 연속 영상으로 VAE encode하지 않는다.

주 비교에서는 이미지 1장과 긴 영상의 차이를 섞지 않도록 모두 **video latent chunk**를 쓴다. 기본 추가 증거 예산은 causal 첫 특수 frame을 제외한 9 latent frame, 즉 명목 72 pixel frame/3초, 512×288에서 1,296 token이다. 필요하면 1개 9-frame chunk 또는 분리된 4+5 frame 등을 쓰되 총 예산은 동일하게 맞춘다. 실제 원본 PTS와 포함 증거를 기록한다.

Temporal VAE receptive field 때문에 선택 latent에는 표시한 chunk 이전의 문맥도 들어 있을 수 있다. “RGB 3초 외에는 어떤 정보도 없다”는 주장을 하지 않는다. 원본 시간 support와 encoder 방식/tiling/padding을 저장한다. **GT는 전체 인코딩 과정에서도 열지 않는다.**

O/U는 선택된 token의 F 좌표를 그대로 유지한다. 삭제한 구간의 시간 간격을 줄이거나, 모든 참조를 0으로 모으거나 Target 위치로 옮기지 않는다. 선택 내용·token 수·시간 좌표의 효과를 한꺼번에 바꾸지 않는다.

### Local 누출과 Native 비교

L/F/O/U의 Local은 해당 2초 RGB만으로 독립 인코딩한 **동일 tensor**다. 전체 32초 VAE 결과의 마지막 latent를 Local-only에 쓰면 encoder가 과거 정보를 섞었을 가능성이 있어 대조군이 오염된다.

N은 native 연속 인코딩을 유지하므로 Local 경계의 latent가 다를 수 있다. 이것이 F를 별도로 두는 이유다. N까지 Local tensor가 완전히 같다고 보고하지 않는다. N에서도 입력 RGB의 마지막 Local과 Target 시작은 다른 조건과 동일하다.

24 FPS에서 H 720→721, Local 48→49, native history 768→769 frame처럼 기존 first-frame padding 원칙을 적용한다. 공통 Target 좌표를 native history 끝 `769/24`초로 정한다. L/F/O/U의 Local+Target base는 +30초 이동하여 Local `[30, 769/24)`, Target `[769/24, 841/24)`에 둔다. F의 H는 `[0, 721/24)`다. 독립 Local의 첫 가상 padding frame과 H 끝이 1/24초 겹치는 경계를 명시하며, 실제 Target overlap이나 GT 사용은 없다. N과 F의 차이는 이 독립 VAE 경계/추가 padding token까지 포함한다. 실제 `positions.pt`와 PTS 대응을 실행 전에 감사한다.

### 동일한 생성 작업과 실행 설정

- 기존 LTX-2.5 distilled BF16, 512×288, 24 FPS, 새 Target 72 frame/3초, 8-step Euler ancestral, SimpleDenoiser, 기존 sigma/eta/s_noise, prompt enhancement 없음.
- LoRA/CFG/STG/새 학습/semantic encoder/attention 계측/시간 보간 또는 RoPE scale 변경을 추가하지 않는다.
- 각 조건의 생성 Target 초기 noise 및 7회 ancestral noise를 **Target 크기의 독립 tensor**로 생성해 공유한다. 전체 sequence에 seed 42를 주는 것만으로는 동일 noise가 보장되지 않는다. 단순히 기존 base-token 수 기준 noise 코드를 길이만 바꾸어 재사용하지 않는다.
- N의 32초 과거는 고정 입력이다. 35초 전체를 새로 denoise하는 baseline으로 만들지 않는다. 단, 고정 prefix도 native self-attention/FFN 계산에는 참여한다.
- 오디오 입력/평가는 없다. joint audio를 유지할 경우 모든 조건에서 같은 약 5초 Local+Target audio shape·위치·noise를 공유한다. native video 길이 때문에 35초 오디오까지 생성해 baseline 비용을 부풀리지 않는다. `DiffusionStage.audio_fps`의 shape 분리 기능 또는 동일 audio state 구성으로 통제하고 실제 hash를 확인한다. video FPS/RoPE를 바꾸는 용도로 쓰지 않는다.
- Decoder는 별도 새 프로세스로 실행한다. 모든 조건에서 마지막 7개 conditioning latent와 생성 9개 latent의 동일 길이 tail을 decode하고 마지막 72 frame만 평가한다. N은 연속 history의 tail을 쓰므로 독립 Local의 첫 padding latent와 동일하지 않음을 기록한다. Full의 32초 전체를 디코딩하는 추가 작업은 주 비용 비교에서 요구하지 않는다. 필요 시 full native decode는 별도 경계 검증으로 기록한다.
- 같은 attention backend·precision·offload·GPU 수를 사용한다. Sparse에도 전체 bank를 GPU에 올린 뒤 일부만 쓰는 구현을 하지 않는다. CPU/disk bank에서 선택한 token만 전송한다.

## 비용: 준비와 생성 단계를 분리

| 항목 | 기록할 측정치 | 해석 |
|---|---|---|
| 입력 준비 | 원본 decode/resize, VAE encode 시간·peak GPU·CPU RSS·bank bytes | Sparse bank를 만드는 최초 비용도 포함 |
| 모델 로딩 | text encoder/transformer/decoder 로딩 시간, weight-resident GPU baseline | 짧은 실행에서 큰 고정비를 숨기지 않음 |
| 생성 | 입력 gather/H2D 시간, CUDA 동기화한 8-step wall time 및 step별 시간 | 주 speedup은 denoising끼리 비교 |
| GPU 메모리 | peak allocated/reserved, NVML peak, weight baseline 대비 증가량 | 전체 VRAM과 입력 길이로 늘어난 부분을 함께 보고 |
| 출력 | 동일 길이 tail decode 시간·peak, Target 파일 길이/PTS | 긴 과거를 추가 렌더링한 비용과 구분 |
| 전체 | uncached 최초 요청과 bank/text cache가 있는 요청의 총 시간 | retrieval network 비용은 포함하지 않았다고 표시 |

각 조건은 새 프로세스, 한 GPU로 실행하고 GPU 0–2만 사용한다. 기본 profiling은 한 번에 한 조건씩 같은 물리 GPU에서 진행해 CPU/I/O/GPU 경쟁을 줄인다. 사례별 실행 순서는 교차 배치하여 순서 편향을 줄이고, 온도·다른 작업·backend·소프트웨어 버전을 기록한다. 추가 seed를 만들지 않는다. 사전 warmup이 필요하면 대상 상태/난수 소비와 분리하고 내용·시간을 기록한다.

초기 입력 준비 비용을 제외한 speedup만으로 end-to-end 이점을 주장하지 않는다. 이번 O는 F의 latent bank를 활용하므로 **F와 같은 H bank 구축 비용을 이미 지불한다.** 반복 요청에서 bank를 재사용하는 장점은 cold/warm 비용을 분리해 설명한다. 실제 자동 검색·전역 메모리 구축 비용은 후속 모델에서 더해져야 한다.

### 이론적인 크기: 측정 결과가 아님

512×288에서 latent frame당 `(512/32)×(288/32)=144` video token이다.

| 조건 | Video latent frame 구성 | Video token 수 |
|---|---|---:|
| L | Local 7 + Target 9 | 2,304 |
| N | native 32초 97 + Target 9 | 15,264 |
| F | H 91 + Local 7 + Target 9 | 15,408 |
| O/U | 선택 9 + Local 7 + Target 9 | 3,600 |

F/O의 video token 비율은 **4.28배**, dense video self-attention의 token 쌍 비율은 **약 18.32배**다. 이는 전체 FLOPs나 wall time speedup, peak VRAM 비율이 아니다. FFN/projection은 다른 크기로 증가하고 audio/text 경로·모델 가중치·커널 효율이 존재한다. Flash/SDPA 계열 구현은 attention 행렬을 그대로 저장하지 않을 수 있으므로 N²을 VRAM 배율로 해석하지 않는다. 실제 step time·peak를 우선하고 token 수/분석식은 원인 설명에만 사용한다.

## 품질 평가: 필요한 정보와 새 장면 구성을 따로 본다

생성 Target만 평가한다. 비교 페이지에는 원본 32초, 전체 timeline의 Oracle/Uniform 선택 구간, Local, GT, 정확한 prompt, 다섯 결과와 비용을 함께 제시한다. Full을 불리하게 보이게 하는 poster 한 장으로 판정하지 않고 전체 3초를 재생한다.

각 사례에서 입력/출력을 보기 전에 평가할 속성과 요청을 적는다.

| 축 | 점수 예 | 주의할 점 |
|---|---|---|
| 증거 활용 | 0 미노출/틀림, 1 일부 또는 모호함, 2 필요한 정보가 명확히 보임 | 얼굴이 안 보이면 “다른 얼굴”로 단정하지 않고 미노출을 따로 표시 |
| 새 구도/행동 | 0 불이행, 1 부분, 2 명확한 이행 | 정지 차량의 외부 노출과 실제 주행을 구분 |
| 연결/영상 품질 | 0 심각, 1 일부 결함, 2 허용 가능 | 잔상·컷·정지·Local 연결을 별도 기록 |
| 불필요한 과거 재현 | 구도·행동·컷·자막 재현 여부 | 배경 정보가 필요한 경우 배경 유지 자체는 실패가 아님 |

조건명을 가린 A–E 패널로 1차 평가하고 그 뒤 비용/조건명을 확인할 수 있게 한다. 작은 5사례의 승/동/패와 개별 근거를 보고하며 통계적 일반화를 하지 않는다. DINO 전체/1초 이후 유사도는 기존 방식의 보조 자료로만 쓴다. 새 VLM 평가 모델을 도입하지 않는다.

미리 정할 실용적인 판단 기준안:

- **정보 활용의 긍정:** 최소 서로 다른 원본 2개에서 O가 L보다 필요한 정보를 명확히 더 전달하고, 그중 새 구도/행동을 이행한 예가 있다.
- **품질 유지 후보:** O가 N과 F 각각에 대해 5사례 중 4개 이상에서 핵심 정보 활용이 동등 이상이며 새 장면 수행이 체계적으로 악화되지 않는다. 작은 표본의 실용 기준으로만 사용한다.
- **비용의 긍정:** N/O와 F/O 각각의 사례별 시간·메모리 비율을 제시한다. 참고 목표는 median denoising speedup 1.5배 이상, weight baseline 대비 추가 peak allocated 20% 이상 감소다. 전체 VRAM도 반드시 함께 제시한다. 시간만 개선되면 시간 이점만 주장한다.
- O와 U가 같으면 선택적 retrieval 필요성의 증거는 약하다. O가 U보다 좋으면 선택의 추가 가치를 뒷받침한다. 5사례 전체 한 숫자로 품질/효율/선택의 결론을 합치지 않는다.

## 실행 순서와 종료 범위

1. 원본 재검토로 **Full에 증거가 포함되는 5개 구간**을 확정한다. 새 prompt/GT 평가 속성/Oracle·Uniform 규칙·seed·판정 기준을 freeze한다. 원본 캐시를 우선 사용한다.
2. 보존 작업자 후보 1개로 32초 입력의 VAE/좌표/token 수/Target noise/고정 prefix/오디오 길이/decoder tail을 점검한다. 실제 native와 참조 경로가 동작하는지 확인한다. 이때 생긴 최종 설정과 동일한 정식 출력은 본 비교에 재사용한다.
3. 메모리 적합성 확인 후 5×5=25개 본 비교를 완료한다. 조건별 결과·검증·비용·입력 timeline을 제공한다. 기존 95회와 합친 완료 수는 **실제 정식 실행이 끝난 뒤에만** 갱신한다.
4. 이 32초 비교로 Stage 1의 원본 증거 입력 경로를 정리한다. 60/64초 확대·추가 seed·offset sweep·attention 계측은 기본 실행 범위에 포함하지 않는다. 32초로 품질과 비용의 질문이 해결되지 않은 구체적인 이유가 있을 때만 후속 설계를 논의한다.

Full이 96GB급 한 GPU에서 OOM이면 시점/peak/backend를 기록한다. **OOM만으로 정보 활용의 우위를 주장하지 않는다.** 먼저 모든 조건에 공통인 memory-efficient backend/기존 offload 가능성을 확인한다. 해상도/precision/GPU 수를 바꾸면 비교 세트 전체에 동일 적용하고 별도 설정으로 보고한다. 한 조건에만 양자화·낮은 FPS·더 짧은 history를 적용하지 않는다. 30초보다 짧게 줄인 결과로 이번 요구를 완료 처리하지 않는다.

이번에 작성한 것은 이 설계와 후속 대화 기록이다. 신규 데이터 구간 확정, cache encode, runner 구현, 영상 생성, 비용 측정은 아직 하지 않았다.
