# FineVideo 소량 데이터 준비 결과

2026-09-06. 접근 승인 후 첫 Parquet shard를 다운로드하고 후보 5개를 추출했다. **첫 local-only 입력 1개와 참조 활용 진단 입력 2개를 준비했다.** 이후 local-only 생성도 1회 완료했으며 그 결과는 [LOCAL_SMOKE_RESULT.md](LOCAL_SMOKE_RESULT.md)에 있다. 이 문서는 데이터 선정 단계의 기록이다.

- [후보 5개 전체 미리보기](reports/candidates/index_overview.html)
- [진단 입력과 실제 클립 검토 페이지](reports/pilot/index.html)
- [재현 가능한 구간 설정](configs/pilot_examples.json)
- [클립 추출·검증 기록](reports/pilot/preparation.json)
- [접근 검사 기록](reports/finevideo_access.json)

## 확보한 데이터

Dataset: `HuggingFaceFV/finevideo`; revision: `84c74091e1c6ee7a5dffabfafb5c9033e4718883`.
첫 shard는 493,919,884 bytes (471.04 MiB), 추출한 MP4 5개는 합계 92,078,800 bytes (87.81 MiB)다. 설치 의존성, 미리보기, 파생 클립은 별도다. 전체 데이터셋 다운로드는 하지 않았다.

60–600초 조건을 만족하는 첫 5개를 골랐다. 무작위 표본이나 연구 과제에 맞게 선별된 벤치마크가 아니다. 원본 MP4, 전체 자동 메타데이터, SHA256, shard/row 위치를 `data/finevideo_candidates/`에 보존했다.

| Row | 영상 | 실제 길이 | 이번 검토 판단 |
|---|---|---:|---|
| 0 | Training Heavy Equipment Operators | 208.31초 | 과거 인터뷰가 다른 장면 뒤에 돌아온다. 참조 활용 진단 2개 선정. |
| 2 | Life at the Academy - Queensland Police Service | 268.10초 | 다양한 인터뷰·훈련·행사 장면. 재등장 후보는 있으나 정확한 구간 추가 검토가 필요하다. |
| 3 | Vendakka Moru Curry / Okra curd curry | 409.62초 | 고정된 조리 장면의 연속 구간을 local-only 진단으로 선정. 현재 보이는 상태를 곧바로 장기 의존성으로 간주할 수 없다. |
| 6 | Revox Line Relaxer product review | 559.93초 | 많은 구간에 같은 발표자가 계속 보인다. 인물 외관은 local만으로 충분한 경우가 많아 초기 장거리 사례로 우선하지 않았다. |
| 7 | HENRY live performance | 183.44초 | 인물·무대가 대부분 지속되고 조명 변화가 크다. 의상 색상 비교에는 혼동 요인이 있다. |

각 영상에서 24개 프레임을 확인하고, 선정한 구간은 더 조밀한 미리보기 및 추출 클립의 프레임으로 확인했다. 원본 전체를 사람이 연속 재생해 검수한 것은 아니다. 자동 메타데이터의 장면 범위나 활동 설명은 정확한 컷 경계를 대체하지 못하므로, 실제 프레임으로 구간을 정했다.

## 준비한 입력

아래는 모두 원본 시간의 `[start, end)` 구간이다. 초 단위 반올림 표이며 정확한 값은 설정 파일에 있다.

| ID | Local | GT target | Oracle | Random control | Oracle 간격 |
|---|---|---|---|---|---:|
| pilot_000_local_cooking | 246–248 | 248–251 | 없음 | 없음 | 해당 없음 |
| pilot_001_interview_return | 156.825–158.825 | 158.825–161.825 | 90–93 | 44–47 | 65.825초 |
| pilot_002_interview_return | 175.636–177.636 | 177.636–180.636 | 60–63 | 44–47 | 114.636초 |

간격은 `target_start - oracle_end`이며 **원본 영상에서의 시간 간격**이다. LTX에 입력할 참조 token의 위치 좌표나 간격을 정한 것은 아니다.

### Local-only 입력

같은 냄비를 젓는 동작이 local과 target에 이어진다. 2초 local을 조건으로 3초의 동작을 생성해 연결, 움직임, 전처리 및 출력 경로를 확인하는 용도다. Local에 이미 외관이 드러나므로 장거리 증거의 효용을 평가하지 않는다.

### 참조 활용 진단 입력

두 입력 모두 “이전 실내 인터뷰로 전환하고 인터뷰를 이어간다”는 공통 prompt를 쓴다. 정답 의상, 안경, 얼굴 특징은 prompt에 넣지 않았다.

- `pilot_001`: local은 공사 차량이다. 과거 참조와 target에는 연한 셔츠의 인터뷰 인물과 같은 실내 배경이 보인다. 셔츠 외관, 인물 외관, 배경을 진단한다.
- `pilot_002`: local은 안전모를 쓴 작업자다. 과거 참조와 target에는 안경과 수염, 어깨 부위의 특징적인 셔츠 무늬가 보인다. **Local의 안전조끼에도 주황색이 있으므로 주황색 재현만으로 성공이라 판정하지 않는다.**

Random control은 같은 원본의 산·공사장 풍경 3초를 수동 선정했다. Oracle과 길이·FPS·해상도·인코딩을 맞췄다. 이는 통계적인 무작위 추출이 아닌, 내용이 관련 없는 초기 대조군이다. 본 비교 확대 시 무작위 후보 선정 규칙과 다른 인물의 인터뷰 같은 hard negative를 추가 검토한다.

이 두 사례는 **장면 전환을 지시한 참조 활용 진단**이다. Local만 보고 전환 시점이나 등장 인물을 예측하는 과제가 아니다. Prompt가 여러 과거 인터뷰 인물 중 하나를 유일하게 지정하지 않으므로, oracle이 특정 외관을 전달할 수 있는지를 먼저 본다. 두 사례가 같은 원본에서 나왔고 편집된 반복 인터뷰라는 점도 있어 독립적인 장거리 벤치마크 2개로 집계하지 않는다. 성공하더라도 전역 메모리의 직접 생성 기여까지 증명하지 않는다.

`review.status`는 `agent_frame_reviewed_diagnostic`, `human_verified`와 `is_validated_long_range_example`은 `false`다. 원본 `provenance.json`의 `unreviewed`는 수집 시점의 상태이며, 이후 구간 검토는 각 실험 `metadata.json`의 `review`에 기록했다.

## 추출과 확인

- `prepare_clips.py`가 원본 SHA256과 revision을 확인했다.
- 원본 구간 내부 프레임만 사용해 24 FPS, local 48프레임, 각 target/참조 72프레임으로 저장했다. 원본 해상도를 보존했고 파생 클립의 오디오는 제외했다.
- 각 출력 프레임에 대응하는 원본 시간을 보존했다. 기본적으로 가장 최근의 구간 내부 프레임을 선택하고, 시작 경계에서는 첫 구간 내부 프레임을 사용했다. 최대 시간 오차는 약 0.0417초였다.
- 총 10개 클립을 끝까지 디코딩해 프레임 수, 출력 PTS, 길이를 확인했다. Local과 GT가 공유하는 원본 프레임이 없고, 모든 선택 프레임이 지정한 구간 안에 있음을 확인했다.
- 추출된 10개 클립의 프레임 미리보기도 확인했다. 데이터셋의 모든 원본 프레임에 대한 무결성 검사나 사람의 oracle 검수 완료를 주장하지 않는다.

이 클립은 데이터 준비 산출물이다. LTX가 요구하는 공간 크기·latent 길이·프레임 수에 맞추는 처리는 다음 추론 구현에서 결정한다. 그때도 GT 프레임을 조건에 넣지 않도록 원본 시간 및 padding을 기록해야 한다. `evaluation_attributes_do_not_condition_on`과 원본 전체 설명/Q&A는 평가자용 정보이며 생성기에 전달하지 않는다.

## 다음 실행

`pilot_000_local_cooking`의 local-only 생성 1회는 완료했다. 이후 참조 진단 두 개에서 Local / Local+Random / Local+Oracle을 같은 target 초기 noise와 공통 설정으로 비교한다. 참조 복사나 정지 출력도 함께 확인한다.

참조 활용이 확인되면 서로 다른 원본의 자연스러운 재등장·상태 의존 사례 3–5개로 확대한다. 현재는 local-only 결과와 간단한 픽셀 진단만 있으며 distant evidence 비교 성능과 장거리 feasibility 결론은 없다.


## 2026-09-07 추가 원본 5개 비교 완료

기존 5개 후보와 초기 입력은 그대로 보존했다. 캐시된 첫 FineVideo shard의 33행 메타데이터에서 추가 후보를 찾고 rows 10/14/16/25/28/29의 원본 6개를 추출했다. 네트워크 다운로드는 추가하지 않았다. 그중 10/14/25/28/29를 서로 다른 원본의 인물 3개·물체 2개 외관 과제로 고정해 Local/Oracle 10회 비교를 완료했다.

Local에서 이미 보이는 옷 색·몸체 정보는 정답 복원의 근거에서 제외했다. 원본·실제 선택 이미지·GT 사이의 시점 차이, 짧은 학생 간격, 차량 cross-dissolve, 로봇 GT의 정지 구간 등 한계를 사전에 기록했다. Assistant의 샘플 프레임 검토이며 사람의 검수·상태/사건 장거리 벤치마크 검증 완료는 아니다.

[새 5개 사전 설계](FIVE_CASE_PROTOCOL.md) · [결과·관찰·한계](FIVE_CASE_RESULT.md) · [실제 입력과 비교](reports/five_cases/seed42/index.html). 원본 추출 manifest와 per-frame 입력 준비 기록은 `reports/five_case_selection/selection_manifest.json`, `preparation.json`에 있다. 기존 `pilot_examples.json`과 후보 manifest는 바꾸지 않았다.
