# 실제 참조 입력과 LTX 주입 방식

2026-09-06. 완료된 9회 실험의 입력 파일·저장 설정·실제 코드를 대조한 설명이다. **과거 RGB를 LTX VAE로 인코딩한 뒤, 생성용 비디오 token 배열에 clean 참조 token을 추가하고 기존 video self-attention으로 읽게 했다.** 새로운 메모리 모듈이나 검색기를 학습한 실험은 아니다.

[입력과 생성 결과를 함께 보는 페이지](report.html) · [결과 해석](REFERENCE_RESULT.md) · [원본 구간 설정](configs/pilot_examples.json)

## 먼저 이해하기: 파일럿 1의 past와 target_guide

**두 방식 모두 원본 90–93초의 보라색 셔츠 인터뷰를 참조한다.** `target_guide`라는 이름이 GT나 미래 이미지를 넣었다는 뜻은 아니다. 차이는 **얼마나 많은 프레임을 넣는가**와 **모델에 어느 시점의 정보라고 알려주는가**다.

| 질문 | past | target_guide |
|---|---|---|
| 무엇을 넣었나? | 인터뷰 3초 영상 전체, 72프레임 | 같은 영상의 가운데 이미지 1장 |
| 언제의 정보로 배치했나? | 공사 차량 Local보다 앞선 과거 | 생성할 인터뷰의 시작 시점 |
| 설명하면? | “예전에 이런 인터뷰가 있었다.” | “지금 생성하는 장면은 이 외형을 참고해라.” |
| 이번 출력은? | 공사 차량 장면이 계속됨 | 보라색 셔츠와 인터뷰 배경이 재현됨 |

위 따옴표는 이해를 위한 설명이며 실제 prompt에 추가한 문장이 아니다. 실제 prompt·Local·noise는 같았다. 두 경우 모두 VAE로 만든 참조 token을 추가해 self-attention으로 읽게 했다. `target_guide`도 생성할 target token을 이미지로 직접 덮어쓰지는 않았다.

```text
past:          [과거 참조 영상] → [Local 공사 차량] → [생성할 인터뷰]
target_guide:                     [Local 공사 차량] → [생성할 인터뷰]
                                                        ↑
                                             과거 이미지 한 장에
                                             이 시점의 위치를 부여
```

따라서 현재 확인한 것은 “생성 시점에 준 과거 이미지가 이 사례의 외형을 전달했다”까지다. 영상→이미지와 시간 위치가 함께 바뀌었으므로 **시간 위치 덕분인지, 이미지 한 장을 썼기 때문인지 아직 분리되지 않았다.** 다음에는 같은 이미지 한 장을 유지하고 위치만 바꾸어 확인한다. 입력 영상과 실제 대표 이미지를 나란히 보려면 [파일럿 1 비교](report.html#pilot-one-difference)를 연다.

## 1. 어떤 영상을 참조로 넣었나

두 사례 모두 FineVideo의 **Training Heavy Equipment Operators**, 후보 `fv_84c74091_0000_00000`에서 잘랐다. 원본 약 208.3초 전체를 모델에 넣지는 않았다. 관련 구간을 미리 골라 주는 Oracle 조건과, 관련 없는 구간을 골라 주는 Random 대조 조건이다. 실제 구간은 assistant가 프레임을 검토해 선정했으며 사람의 별도 검수를 완료한 데이터는 아니다. 여기서 Random은 **같은 원본의 44–47초 풍경을 수동 선택한 것**이며 무작위 추출 결과가 아니다.

아래 구간은 원본의 초 단위 `[시작, 끝)`이다. 원본 FPS 약 23.976을 24 FPS 클립으로 만들었으므로 실제 선택된 프레임의 timestamp는 구간 경계나 `시작+index/24`와 조금 다를 수 있다. 정확한 대응은 각 `metadata.json`의 `clips.*.source_frame_seconds`에 보존했다.

### 사례 001: 연한 보라색 셔츠의 인터뷰

| 역할 | 원본 구간 | 무엇이 보이나 | 파일 |
|---|---|---|---|
| Local | 156.825333–158.825333초 | 나무 사이 공사 차량 | [2초 영상](data/pilot_001_interview_return/local_context.mp4) |
| Oracle | 90–93초 | 연한 보라색 셔츠, 짧은 밝은 머리, 안경 없는 인터뷰 인물과 원형 표시 배경 | [3초 참조 영상](data/pilot_001_interview_return/oracle_context.mp4) |
| Random | 44–47초 | 눈 덮인 산과 나무가 있는 풍경 | [3초 대조 영상](data/pilot_001_interview_return/random_context.mp4) |
| GT | 158.825333–161.825333초 | Oracle과 같은 외형의 인터뷰가 다시 나오는 구간 | [평가 전용 영상](data/pilot_001_interview_return/gt_target.mp4) |

왼쪽부터 **Local / Random / Oracle / GT**다. 각 열의 처음·가운데·마지막 프레임을 표시했다. `past`는 이 세 장만 넣은 것이 아니라 해당 클립 전체를 인코딩했다. GT는 아래 비교를 위한 표시이며 모델 입력에 포함되지 않았다.

![001의 입력 클립과 평가용 GT](reports/reference/inputs/pilot_001_interview_return/inputs_overview.jpg)

### 사례 002: 안경·수염과 주황색 폴로셔츠의 인터뷰

| 역할 | 원본 구간 | 무엇이 보이나 | 파일 |
|---|---|---|---|
| Local | 175.635789–177.635789초 | 빨간 안전모와 반사 조끼를 착용한 작업자 | [2초 영상](data/pilot_002_interview_return/local_context.mp4) |
| Oracle | 60–63초 | 검은 직사각 안경·수염, 주황색 폴로셔츠 어깨의 검은 반복 무늬 | [3초 참조 영상](data/pilot_002_interview_return/oracle_context.mp4) |
| Random | 44–47초 | 사례 001과 동일한 산 풍경 | [3초 대조 영상](data/pilot_002_interview_return/random_context.mp4) |
| GT | 177.635789–180.635789초 | Oracle과 같은 외형의 인터뷰가 다시 나오는 구간 | [평가 전용 영상](data/pilot_002_interview_return/gt_target.mp4) |

![002의 입력 클립과 평가용 GT](reports/reference/inputs/pilot_002_interview_return/inputs_overview.jpg)

주황색은 Local 조끼에도 있다. 따라서 이 사례에서는 색만이 아니라 안경·수염·어깨 무늬의 전달을 봐야 한다. 두 사례는 같은 원본의 편집된 인터뷰이므로 독립 표본이 아니며, Oracle과 GT의 구도가 비슷한 쉬운 외형 진단이라는 한계가 있다.

### target_guide에서 실제로 넣은 이미지

추가 `target_guide` 실험은 **사례 001에서만 실행했다.** Oracle/Random 영상 각각의 **0부터 세는 프레임 index 36**, 즉 파생 클립 재생 시간 1.5초의 RGB 한 장을 독립 인코딩했다. 3초 영상에서 latent 하나를 잘라낸 방식이 아니다.

| 조건 | 실제 넣은 이미지 | 선택된 프레임의 원본 timestamp |
|---|---|---:|
| Oracle | ![실제 Oracle 대표 이미지](reports/reference/inputs/pilot_001_interview_return/oracle_middle.png) | 91.466378초 |
| Random | ![실제 Random 대표 이미지](reports/reference/inputs/pilot_001_interview_return/random_middle.png) | 45.462089초 |

PNG는 생성 코드와 동일한 디코딩·512×288 전처리를 적용한 **VAE 입력 직전의 RGB**다. 입력 원본 파일과 cache SHA256을 대조한 뒤 lossless PNG로 저장했다. 위 overview JPEG는 표시용 압축 미리보기다. 생성 영상이나 GT로부터 참조 이미지를 만든 것이 아니다.

## 2. 각 결과 열에 들어간 조건

| 실행 묶음 | Local 열 | Random 열 | Oracle 열 |
|---|---|---|---|
| 001 / past | 공사 차량 Local만 | 같은 Local + 산 풍경 3초 | 같은 Local + 보라색 셔츠 인터뷰 3초 |
| 002 / past | 안전모 작업자 Local만 | 같은 Local + 산 풍경 3초 | 같은 Local + 안경·수염 인터뷰 3초 |
| 001 / target_guide | 공사 차량 Local만 | 같은 Local + 산 풍경 대표 이미지 1장 | 같은 Local + 보라색 셔츠 대표 이미지 1장 |

각 실행에는 해당 행의 참조 하나만 들어간다. Random과 Oracle을 동시에 넣지 않는다. 공통 cache에는 두 참조가 모두 저장되어 있지만 **Local-only는 어느 참조 token도 모델에 전달하지 않는다.** 모든 열의 target은 noise에서 생성하며 GT RGB/latent는 입력하지 않는다.

두 사례·모든 조건의 prompt는 정확히 다음과 같고 prompt enhancement는 껐다.

> The video cuts back to a previously shown indoor interview. The interviewee continues speaking in a seated medium shot.

셔츠 색·안경·수염 같은 정답 외형은 prompt에 없다. 다만 인터뷰로 돌아가라는 장면 전환 지시는 주었으며, 여러 인터뷰 인물 중 누구인지 이 문장만으로 유일하게 정해지지는 않는다. 원본 영상의 오디오는 입력하지 않았다. LTX의 audio latent는 함께 생성했지만 오디오를 디코딩·평가하지 않았다.

## 3. RGB가 모델 token이 되기까지

원본 클립은 640×360이며, 생성용 `read_rgb`가 centered Lanczos crop/resize로 512×288을 만든다. 현재 입력은 둘 다 16:9여서 구도는 유지된다. BF16으로 변환한 뒤 `RGB / 127.5 - 1`로 정규화하고 기존 LTX video VAE encoder에 넣는다. Local과 참조는 **각각 독립적으로 인코딩**해 참조 때문에 Local latent 자체가 바뀌지 않게 했다.

| 입력 | VAE에 넣은 pixel frame 수 | VAE latent shape `[B,C,T,H,W]` | 비디오 token 수 |
|---|---:|---|---:|
| Local 2초 | 48프레임 앞에 첫 프레임을 복제 → 49 | `[1,128,7,9,16]` | 7×9×16 = **1,008** |
| past 참조 3초 | 72프레임 앞에 첫 프레임을 복제 → 73 | `[1,128,10,9,16]` | 10×9×16 = **1,440** |
| target_guide 참조 | RGB 1장 그대로 | `[1,128,1,9,16]` | 1×9×16 = **144** |
| 생성할 target 3초 | GT 인코딩 없이 noise로 시작 | 생성 영역 9 latent frame | 9×9×16 = **1,296** |

VAE 시간축 규격 `8k+1`을 맞추기 위한 첫 프레임 복제다. Token 하나의 초기 128차원은 VAE 채널이고, 이후 기존 transformer 입력 projection을 거친다. V-JEPA/VLM 특징이나 학습된 압축 메모리 token을 사용한 것이 아니다.

## 4. 어디에 붙이고 어떻게 attention하는가

```text
Local RGB ── 독립 VAE ──→ Local clean latent (1,008 tokens) ─┐
Target noise ────────────────────────────── (1,296 tokens) ─┼→ video token 배열
Oracle 또는 Random RGB ── 독립 VAE ──→ Reference tokens ──┘
                                                           │
                        기존 LTX transformer의 video self-attention
                        Local / Target / Reference 사이에 attention 허용
                                                           │
                            매 denoising step에서 Target을 업데이트
                            Local / Reference latent는 clean 값으로 고정
                                                           │
                            추가 Reference tokens 제거 → VAE decode
                            → 생성 target 72프레임만 잘라 평가

공통 prompt → 기존 text encoder → 기존 text cross-attention
```

배열에서의 순서는 **`[Local 1,008 | Target 1,296 | Reference R]`**다. 기본 생성 영역은 2,304 token이며, `past`에서는 총 3,744개, `target_guide`에서는 총 2,448개다. Local-only는 2,304개다. 이 수는 video token만 센 값이다.

참조는 text cross-attention의 prompt 자리에 들어가지 않는다. 공식 `VideoConditionByKeyframeIndex`가 참조를 patchify하고 **기존 video token 배열 끝에 추가**한다. Video self-attention에서 target의 query가 참조 token의 key/value에도 접근할 수 있다. 기존 video/audio 상호 attention도 그대로 유지되지만 새 reference 전용 cross-attention layer는 추가하지 않았다.

이번 경로의 video attention mask는 `None`이고, 사용한 SDPA는 `is_causal=False`다. 즉 배열 끝에 붙였다고 앞의 target이 읽지 못하는 구조가 아니다. 추가 attention 강도 wrapper나 특정 layer·step에만 참조를 제한하는 처리는 없으며, 참조는 8개 denoising step 모두에 제공된다. **읽을 수 있도록 연결했다는 사실과 실제로 유용하게 읽었다는 결과는 별개**다. Head별 attention map이나 retrieval score는 추출하지 않았다.

`strength=1.0`은 참조의 `denoise_mask=0`을 뜻한다. **Attention weight를 1로 고정한다는 의미가 아니다.** Local도 같은 mask 0으로 고정하고 target은 mask 1로 denoise한다. Transformer 내부 참조 feature까지 상수로 묶는 것이 아니라, diffusion state의 참조 latent를 각 step에 clean 값으로 유지하는 방식이다. 모든 실행에서 고정 latent 오차가 0임을 확인했다.

## 5. past와 target_guide의 차이: 배열 위치와 시간 좌표

**Token을 배열 어디에 붙이는지와 모델에 어느 시점이라고 알려주는지는 다르다.** 두 형식 모두 참조를 배열 끝에 붙이지만 positional encoding/RoPE에 전달하는 시간 좌표가 다르다. 아래 시간은 모델 내부 좌표이며 원본 영상 timestamp가 아니다.

기본 video/audio 위치에 공통 `ShiftTime(97/24)`를 먼저 적용한다. 따라서 Local 범위는 `[97/24,146/24)` = **[4.041667, 6.083333)초**, target 범위는 `[146/24,218/24)` = **[6.083333, 9.083333)초**다. Local-only도 같은 이동을 사용한다.

| 항목 | past | target_guide |
|---|---|---|
| 참조 내용 | 과거 3초 영상 전체 | 같은 과거 영상 가운데 RGB 한 장 |
| 참조량 | 1,440 token | 144 token |
| 공식 API | `VideoConditionByKeyframeIndex` | 동일 |
| `frame_idx` | `0` | `146` |
| `num_pixel_frames` | `73` | `1` |
| `strength` | `1.0` | `1.0` |
| 참조 시간 범위 | `[0,73/24)` = [0,3.041667)초 | `[146/24,147/24)` = [6.083333,6.125)초 |
| 의미 | Local보다 앞선 과거에 참조 배치 | 생성 시작 구간에 과거 외형을 알려주는 keyframe 배치 |

```text
past의 모델 시간:
0             3.0417        4.0417             6.0833             9.0833초
| Reference |   1초 빈 간격   | Local (고정)     | Target (생성)    |

target_guide의 모델 시간:
                            | Local (고정)     | Target (생성)    |
                                               ↑ 과거 RGB 한 장에
                                                 6.0833초 위치 부여
```

1초 빈 간격은 위치 좌표의 간격이며, 그 구간의 검은 프레임이나 noise token을 만들어 넣지는 않았다. 원본의 `target_start − oracle_end`는 001에서 65.825333초, 002에서 114.635789초지만 이 전체 간격을 모델에 넣지는 않았다.

`target_guide`는 **추가 token**에 생성 시작 시점 위치를 부여한다. Base target token 자체를 reference latent로 덮어쓰거나 GT 첫 프레임을 고정하지 않는다. 따라서 첫 decoded target 프레임이 참조 RGB와 정확히 같아야 하는 조건도 아니다. 다만 생성 시점의 모습을 직접 알려주는 강한 guidance다.

두 실험 사이에는 **시간 위치 + 영상/이미지 형식 + 참조 token 수**가 함께 변했다. 따라서 `target_guide`의 성공을 시간 위치만의 효과 또는 장기 기억의 성공이라고 해석하지 않는다. 다음에는 동일 RGB 한 장·동일 token 수에서 시간 위치만 바꾸려는 이유다.

## 6. 실제 코드와 저장 파일로 확인하기

아래는 실행한 conditioning 구성의 핵심을 숫자로 풀어 쓴 코드다. Local은 지정 latent index에 고정하고, 참조는 별도의 token으로 추가한다.

```python
conditions = [
    ShiftTime(97 / 24),
    VideoConditionByLatentIndex(local_latent, strength=1.0, latent_idx=0),
]

if mode != "local":  # mode는 random 또는 oracle
    if layout == "past":
        reference = tensors[mode]              # 3초 영상을 독립 인코딩
        frame_idx, num_pixel_frames = 0, 73
    else:  # target_guide
        reference = tensors[mode + "_still"]   # RGB 한 장을 독립 인코딩
        frame_idx, num_pixel_frames = 146, 1
    conditions.append(VideoConditionByKeyframeIndex(
        reference, frame_idx=frame_idx, strength=1.0,
        num_pixel_frames=num_pixel_frames,
    ))
# Local-only는 참조 append를 실행하지 않음
```

| 확인할 내용 | 파일과 함수 |
|---|---|
| 구간·prompt·프레임 원본 timestamp | [001 metadata](data/pilot_001_interview_return/metadata.json), [002 metadata](data/pilot_002_interview_return/metadata.json) |
| 전처리·VAE 인코딩·조건 구성 | [run_reference_comparison.py](run_reference_comparison.py)의 `encode_all`, `conditions`; RGB resize는 [run_generation.py](run_generation.py)의 `read_rgb` |
| 위치 이동·같은 noise 생성 | [reference_controls.py](reference_controls.py)의 `ShiftTime`, `PairedNoise` |
| 실제 cache tensor hash·shape | [001 inputs.json](outputs/pilot_001_interview_return/reference_inputs_512x288/inputs.json), [002 inputs.json](outputs/pilot_002_interview_return/reference_inputs_512x288/inputs.json) |
| 실제 모델 설정 예시 | [001 past Oracle config](outputs/pilot_001_interview_return/reference_past_seed42/oracle/config.json), [001 target_guide Oracle config](outputs/pilot_001_interview_return/reference_target_guide_seed42/oracle/config.json), [002 past Oracle config](outputs/pilot_002_interview_return/reference_past_seed42/oracle/config.json) |
| 이번 입력 이미지의 원본/PNG hash와 timestamp | [001 입력 미리보기 provenance](reports/reference/inputs/pilot_001_interview_return/inputs.json), [002 입력 미리보기 provenance](reports/reference/inputs/pilot_002_interview_return/inputs.json) |

각 출력 디렉터리의 `video_positions.pt`는 실제 step 0의 위치 tensor다. `config.json`의 `reference_tokens`, `reference_model_time_range`, `target_model_time_range`, `common_inputs_sha256`으로 문서의 배치를 대조할 수 있다. `metadata.json`은 데이터 준비 당시 기록이며 실행 완료 여부는 출력 `config.json`의 `status`로 확인한다. 출력 비교 영상의 GT 열은 평가용이다.

Upstream 구현은 부모 LTX 저장소 commit `a95ab856bf29407b6b066ede0abe1846050db56c` 기준이다. `packages/ltx-core/src/ltx_core/conditioning/types/keyframe_cond.py`의 `apply_to`가 token 추가·mask·좌표를 구성하고, `model/transformer/transformer.py`의 `attn1`이 video self-attention을 수행한다. `conditioning/mask_utils.py`와 `model/transformer/attention.py`에서 attention mask와 비인과적 SDPA를 확인했다. `tools.py`의 `clear_conditioning`이 추가 token을 디코딩 전에 제거한다.

### KeyframeIndex와 ReferenceLatent의 실제 차이

두 클래스 모두 같은 방식으로 clean 참조 token을 배열 끝에 추가하며, `strength`로 denoise mask를 만들고 기존 self-attention에 노출한다. 둘 다 추가 token에 generated-keyframe marker를 붙이지 않는다. **핵심 차이는 참조 위치 좌표를 만드는 규칙**이다.

| 항목 | `VideoConditionByKeyframeIndex` | `VideoConditionByReferenceLatent` |
|---|---|---|
| 시간 배치 | `frame_idx`로 시간 offset을 지정 | 별도 `frame_idx` 없이 참조 grid에서 좌표 생성 |
| 단일 이미지 | `num_pixel_frames=1`이면 지정 시점에서 1 pixel frame 폭으로 설정 | 기본 VAE grid의 시간 범위를 사용 |
| 다른 참조 해상도/FPS의 좌표 대응 | 별도 배율 인자 없음 | `downscale_factor`, `temporal_scale_factor`로 좌표를 조정 |
| 의도된 사용 | 지정 시점의 이미지·keyframe 조건 | IC-LoRA가 학습한 참조/target 정렬에 맞춘 조건 |
| LoRA 로딩 | 이 클래스는 가중치를 로드하지 않음 | 이 클래스도 가중치를 로드하지 않음 |

**이번 `past`에서는 두 클래스가 만드는 입력이 동일함을 CPU에서 확인했다.** 저장된 001/002의 Oracle/Random cache를 사용해 다음 두 설정을 비교했으며 `latent`, `clean_latent`, `denoise_mask`, `positions`, `keyframes_mask`, `attention_mask`가 모두 일치했다.

```python
VideoConditionByKeyframeIndex(ref, frame_idx=0, strength=1, num_pixel_frames=73)
VideoConditionByReferenceLatent(ref, downscale_factor=1, temporal_scale_factor=1, strength=1)
```

이는 해당 설정의 조건 입력 비교이며, 새로운 생성 실험을 추가한 것은 아니다. `target_guide`의 146-frame offset을 `ReferenceLatent` 기본값이 대신 주지는 않는다. 일반적으로 nonzero offset의 causal 시간 보정, 단일 이미지 처리, 참조 좌표 배율에 따라 두 클래스의 위치가 달라질 수 있다.

이번 실행은 **일반 LTX-2.5 distilled 가중치만 사용했고 IC-LoRA를 로드하지 않았다.** `ReferenceLatent`를 호출한다고 자동으로 IC-LoRA가 적용되지는 않는다. 클래스만 교체하는 것과, 학습된 IC-LoRA 가중치 및 그에 맞는 참조 입력 배치를 적용하는 것은 별개다. 따라서 이번 `past`의 문제를 두 클래스의 이름 차이만으로 설명할 수 없다.

## 7. 비교 통제와 연구 목표와의 관계

같은 cache의 Local latent와 prompt context를 사용했다. 초기 및 7회 ancestral noise는 공통 base-video shape로 CPU에서 생성하고, 추가 clean 참조에는 zero padding해 참조 수 때문에 RNG 소비가 달라지지 않게 했다. 저장된 실제 target noise와 모든 modality의 noise hash를 비교했다. Decoder seed도 고정했다. `denoise_mask` 검사는 모든 step과 최종 상태에서 통과했다.

현재 검증한 것은 **골라 준 원본 시각 증거를 기존 생성기가 사용할 수 있는가**다. 압축 전역 메모리의 직접 생성 조건, 메모리를 이용한 원본 검색, 여러 과거 구간을 종합한 상태·사건 이해는 후속 가설로 남아 있다. 이번의 고정 local/reference latent와 사용자가 제안한 학습된 전역 메모리는 서로 다른 역할이다.
