# 원본 과거 참조를 유지한 prompt 제어 비교 제안

2026-09-08. **사전 설계 기록. 이후 사용자 실행 요청으로 신규 45회를 완료했다.** [실제 결과](PROMPT_CONTROL_RESULT.md) · [60개 영상 비교](reports/five_case_prompt/seed42/index.html). 아래 실행 전 표현은 설계 당시의 기록이며 최신 상태는 결과 문서를 따른다. 사용자 요청은 배경·물체·사람 중 유용한 정보를 생성 시 활용하는 것이다. 피사체 추출·배경 제거·참조 시트로 정보를 사전 제한하는 방향을 제외하고, 원본 과거 프레임을 유지한 prompt 진단을 다음 후보로 삼는다. 여기서 원본 유지는 기존 resize/VAE 전처리 cache를 그대로 재사용하며 추가로 의미 영역을 삭제하거나 재구성하지 않는다는 뜻이다.

[기존 5개 2×2 결과](FIVE_CASE_GRID_RESULT.md) · [정확한 prompt 초안 JSON](configs/five_case_prompt_proposal.json) · [전체 다음 단계](NEXT_STAGE.md)

## 검증할 질문

기존 prompt에도 전환 지시가 있으므로 실패를 prompt 부족으로 확정하지 않는다. 현재 확인할 것은 **원하는 전환·시점·행동을 더 구체화했을 때 Past 참조의 유용성과 새 출력 제어가 함께 개선되는가**다. 배경/인물/물체를 전처리에서 버리지 않고, prompt가 현재 생성할 장면을 구체화하도록 한다.

LTX 공식 안내는 shot의 크기·시점, 구체적 동작, 카메라 이동을 명시하고 전환 시 새 shot을 다시 설명하도록 권한다. 이 일반 지침을 차용하되 정답 외관을 쓰는 예제는 우리의 visual evidence 평가와 맞지 않아 따르지 않는다. Prompt가 reference token의 의미를 실제로 지정할 수 있다는 보장은 이 문서에서 확인되지 않는다. [공식 prompting guide](https://docs.ltx.io/open-source-model/usage-guides/prompting-guide)

## 사용자 추가 요청: 기존 P0에 대안 3종

사용자의 “프롬프트는 3개 추가해줘”를 반영해 **각 사례의 기존 P0에 대안 P1·P2·P3를 추가**한다. 앞서 작성한 P1은 유지하고 P2·P3를 완성했다. 따라서 사례마다 총 4종, 기존 5개에는 대안 prompt 총 15개다. 이번 작업은 문장과 비교 계획의 갱신이며 실행 기록이 아니다.

| 버전 | 구성 | 확인할 질문 |
|---|---|---|
| P0 | 기존 짧은 prompt | 기존 결과 재사용 |
| P1 | 구체적인 컷·시점·화면 구성·동작 | 출력 지시를 명확히 하면 전환과 증거 활용이 개선되는가 |
| P2 | **P1 그대로 + 연속성 문장 1개** | 같은 대상·장소가 이어진다는 설명이 과거 정보 유지에 도움이 되는가 |
| P3 | **P2 그대로 + 참조 역할 문장 2개** | 과거가 제공하는 시각 정보와 새 구도·동작의 역할을 text로 명시하면 도움이 되는가 |

P1→P2→P3에서 요청한 시점·동작은 유지한다. 배경을 일괄 무시하라는 지시는 넣지 않으며, 장소가 이어지는 사례에서는 공간/작업대 정보도 보존 대상으로 기술한다. 차량에는 다른 장소도 가능한 P1을 유지하도록 다시 보이는 주변 환경만 언급한다. 색·무늬·머리·얼굴 등 정답의 구체적 값은 적지 않는다.

## 비교: P0/P1/P2/P3 × Local/Image-Past/Video-Past

| 항목 | 설정 |
|---|---|
| 사례 | 기존 FineVideo 원본 5개 전부 |
| P0 | Local/Image-Past/Video-Past 15개 재사용 |
| P1·P2·P3 | 각각 5개 사례 × 동일한 3조건 |
| 신규 생성 | **5사례 × 3조건 × 3대안 = 45회 계획** |
| 총 비교 출력 | 기존 15 + 신규 45 = 60개 |
| Seed | 42 하나 |
| 참조 | 기존 전체 이미지 144 token / 전체 영상 1,440 token, 내용·시간 좌표 유지 |
| 시간 위치 | Past 공통. 기존 Target 결과는 이전 진단 기록으로 보존하고 신규 생성하지 않음 |
| 현재 실행 상태 | Prompt 작성만 완료. 신규 생성·새 text embedding은 0회 |

각 버전의 같은 text를 Local-only에도 적용한다. P2/P3의 ‘이전 장면’ 표현은 원격 과거 참조가 없는 Local 조건에서도 동일하게 둔다. 그래야 참조 없이 텍스트와 모델의 사전 지식으로 만든 개선을 증거의 효과와 구분할 수 있다.

- 같은 prompt에서 Local → Image/Past 또는 Video/Past 차이: 해당 prompt 아래 참조의 추가 효용.
- P0 → P1 → P2 → P3의 Local 차이: 참조 없이 생긴 prompt 효과.
- 버전별 Oracle−Local 차이의 변화: 문장 추가가 reference 활용에 도움이 됐는지 보는 기술적 비교. 한 seed의 결과이며 통계적 유의성으로 표현하지 않는다.

P1은 구도/행동을 구체화하는 묶음 개입이다. P2/P3도 문장 길이와 반복이 늘어나므로 효과를 특정 단어나 의미 역할 이해의 기전으로 단정하지 않는다. 좋은 버전만 사후 선택해 보고하지 않고 모든 버전의 결과를 함께 비교한다.

## 통제와 실행 전 확인

원본 source/구간/이미지/영상/Local cache, 실제 초기 및 7회 step noise, base AV/참조 좌표, 모델·sampler·512×288·24 FPS·3초 Target·8 step·decoder를 유지한다. 새 prompt의 text embedding만 별도 cache로 만들고 기존 cache/config/출력/감사 snapshot을 덮어쓰지 않는다. 실행 전에 proposal을 고정하고 기존 재사용 결과의 config/hash를 검증한다.

현재 runner는 `SimpleDenoiser`로 조건부 1회 forward를 하며 CFG/STG/negative branch를 사용하지 않는다. **Negative prompt 문자열만 추가해서 제어가 강화된다고 가정하지 않는다.** 이번 1차는 positive prompt 변경만이다. 자동 prompt enhancement는 정답 속성을 추가하거나 여러 변인을 바꿀 수 있으므로 꺼 둔다. 코드 확인 경로는 `run_five_case_grid.py`와 부모 저장소의 `ltx_pipelines/utils/denoisers.py`다.

GT frame·자동 전체 영상 설명·정답 의상/머리/차체 색을 text encoder에 넣지 않는다. 새로 요청하는 camera/action은 생성 제어이며, visual evidence에서 복구할 속성과 별도로 기록한다. GPU 실행·전처리·새 text embedding 생성은 아직 하지 않았다.

## 사례별 실제 prompt 초안

아래 P1은 이전 초안과 동일하다. P2/P3는 추가 문장과 함께 **실제로 넣을 전체 prompt**를 표시한다.

### 보육원 관리자 재등장

P0: The video returns to the nursery manager's seated interview as she continues speaking.

**P1 — 출력 지시 구체화**

> The close-up of the laptop ends with a hard cut to an eye-level medium close-up of the same childcare manager seated in the childcare room. The camera views her from a three-quarter side angle and keeps her face and shoulders in frame. She continues speaking and makes a small hand gesture. The camera stays steady throughout the interview shot.

childcare로 nursery의 의미 모호성을 줄이고, 측면 인터뷰와 실제 발화/손짓을 구체화한다. 옷 색·머리·얼굴 정답은 적지 않는다.

**P2 — P1 + 과거와의 연속성**

추가 문장: The manager's appearance and the recognizable childcare-room setting stay consistent with the earlier interview.

> The close-up of the laptop ends with a hard cut to an eye-level medium close-up of the same childcare manager seated in the childcare room. The camera views her from a three-quarter side angle and keeps her face and shoulders in frame. She continues speaking and makes a small hand gesture. The camera stays steady throughout the interview shot. The manager's appearance and the recognizable childcare-room setting stay consistent with the earlier interview.

**P3 — P2 + 과거 정보와 새 구도·동작의 역할**

추가 문장: The earlier interview provides visual details of the manager and the room. The framing, camera position and ongoing speech follow the new side-angle interview shot described here.

> The close-up of the laptop ends with a hard cut to an eye-level medium close-up of the same childcare manager seated in the childcare room. The camera views her from a three-quarter side angle and keeps her face and shoulders in frame. She continues speaking and makes a small hand gesture. The camera stays steady throughout the interview shot. The manager's appearance and the recognizable childcare-room setting stay consistent with the earlier interview. The earlier interview provides visual details of the manager and the room. The framing, camera position and ongoing speech follow the new side-angle interview shot described here.

### 로봇 모형의 가려졌던 머리

P0: The view switches to the same robot model posed on its display turntable, showing its head and upper body.

**P1 — 출력 지시 구체화**

> The close-up of the robot's lower body ends with a hard cut to a wider display shot. The same robot model stands on its own on its display turntable, with its entire head, both shoulders and upper torso comfortably inside the frame. The camera is fixed at the model's head height. The model maintains its display pose for the rest of the shot.

손에 들린 근접 구도에서 자립한 전시 구도로 전환하고 머리를 frame 안에 넣도록 명확히 한다. 정적인 전시 pose는 의도된 출력이며 정지 자체를 실패로 세지 않는다.

**P2 — P1 + 과거와의 연속성**

추가 문장: The robot model and its display turntable keep the same appearance as in the earlier view.

> The close-up of the robot's lower body ends with a hard cut to a wider display shot. The same robot model stands on its own on its display turntable, with its entire head, both shoulders and upper torso comfortably inside the frame. The camera is fixed at the model's head height. The model maintains its display pose for the rest of the shot. The robot model and its display turntable keep the same appearance as in the earlier view.

**P3 — P2 + 과거 정보와 새 구도·동작의 역할**

추가 문장: The earlier view provides visual details of the robot and its display setting. The model's pose and the camera framing follow the freestanding display shot described here.

> The close-up of the robot's lower body ends with a hard cut to a wider display shot. The same robot model stands on its own on its display turntable, with its entire head, both shoulders and upper torso comfortably inside the frame. The camera is fixed at the model's head height. The model maintains its display pose for the rest of the shot. The robot model and its display turntable keep the same appearance as in the earlier view. The earlier view provides visual details of the robot and its display setting. The model's pose and the camera framing follow the freestanding display shot described here.

### 교실 학생의 얼굴 재등장

P0: The view returns to the student standing at the teacher's desk as she listens and responds.

**P1 — 출력 지시 구체화**

> A hard cut switches from the teacher-facing view to a reverse-angle medium close-up of the same student at the teacher's desk. Her face is fully visible as she looks toward the teacher just beside the camera. She listens and gives a brief response with a small nod. The camera stays fixed on the student throughout the shot.

교사 쪽 시점을 학생 얼굴 쪽 역방향 시점으로 전환한다. 얼굴·곱슬머리·셔츠 색은 prompt로 알려주지 않는다.

**P2 — P1 + 과거와의 연속성**

추가 문장: The student's appearance and the teacher's-desk setting stay consistent with the earlier classroom view.

> A hard cut switches from the teacher-facing view to a reverse-angle medium close-up of the same student at the teacher's desk. Her face is fully visible as she looks toward the teacher just beside the camera. She listens and gives a brief response with a small nod. The camera stays fixed on the student throughout the shot. The student's appearance and the teacher's-desk setting stay consistent with the earlier classroom view.

**P3 — P2 + 과거 정보와 새 구도·동작의 역할**

추가 문장: The earlier classroom view provides visual details of the student and the surrounding classroom. Her gaze, her response and the camera framing follow the new reverse-angle shot described here.

> A hard cut switches from the teacher-facing view to a reverse-angle medium close-up of the same student at the teacher's desk. Her face is fully visible as she looks toward the teacher just beside the camera. She listens and gives a brief response with a small nod. The camera stays fixed on the student throughout the shot. The student's appearance and the teacher's-desk setting stay consistent with the earlier classroom view. The earlier classroom view provides visual details of the student and the surrounding classroom. Her gaze, her response and the camera framing follow the new reverse-angle shot described here.

### 캠퍼 밴 외관으로 시점 전환

P0: The camera transitions outside to the camper van from the tour as it slowly drives across the driveway.

**P1 — 출력 지시 구체화**

> A hard cut switches from the view inside the van to a wide exterior shot of the same camper van on a driveway. A stationary camera stands outside the vehicle at a front three-quarter angle, with the entire van in frame. The van itself rolls slowly forward across the driveway while its wheels turn. The camera remains fixed, and the exterior shot fills the frame.

외부 고정 카메라와 차량 자체 이동을 분리한다. 원본 GT의 dissolve 대신 hard cut을 요청하므로 GT 전환 모양을 복원하는 실험은 아니다.

**P2 — P1 + 과거와의 연속성**

추가 문장: The same camper van seen earlier in the tour keeps its appearance across the cut.

> A hard cut switches from the view inside the van to a wide exterior shot of the same camper van on a driveway. A stationary camera stands outside the vehicle at a front three-quarter angle, with the entire van in frame. The van itself rolls slowly forward across the driveway while its wheels turn. The camera remains fixed, and the exterior shot fills the frame. The same camper van seen earlier in the tour keeps its appearance across the cut.

**P3 — P2 + 과거 정보와 새 구도·동작의 역할**

추가 문장: The earlier view supplies visual details of the van and any surroundings that are visible again. The fixed camera and the van's forward movement follow the new exterior shot described here.

> A hard cut switches from the view inside the van to a wide exterior shot of the same camper van on a driveway. A stationary camera stands outside the vehicle at a front three-quarter angle, with the entire van in frame. The van itself rolls slowly forward across the driveway while its wheels turn. The camera remains fixed, and the exterior shot fills the frame. The same camper van seen earlier in the tour keeps its appearance across the cut. The earlier view supplies visual details of the van and any surroundings that are visible again. The fixed camera and the van's forward movement follow the new exterior shot described here.

### 보존 작업자의 얼굴 재등장

P0: The camera returns to the textile conservator at the workbench, showing her face as she looks down and resumes working.

**P1 — 출력 지시 구체화**

> The close-up of the hands ends with a hard cut to a side-angle medium close-up of the same textile conservator at the workbench. Her face remains in the upper half of the frame, with her hands and the book visible below. She looks down and continues gently cleaning the book. The camera holds this view throughout the shot.

얼굴과 작업이 함께 보이는 측면 구도를 유지한다. 머리색·안경의 정답을 적지 않으며 같은 작업대라는 장소/관계는 유지한다.

**P2 — P1 + 과거와의 연속성**

추가 문장: The conservator, the book and the workbench retain their appearance from the earlier conservation scene.

> The close-up of the hands ends with a hard cut to a side-angle medium close-up of the same textile conservator at the workbench. Her face remains in the upper half of the frame, with her hands and the book visible below. She looks down and continues gently cleaning the book. The camera holds this view throughout the shot. The conservator, the book and the workbench retain their appearance from the earlier conservation scene.

**P3 — P2 + 과거 정보와 새 구도·동작의 역할**

추가 문장: The earlier scene provides visual details of the conservator and the work area. Her cleaning action and the camera framing follow the new side-angle shot described here.

> The close-up of the hands ends with a hard cut to a side-angle medium close-up of the same textile conservator at the workbench. Her face remains in the upper half of the frame, with her hands and the book visible below. She looks down and continues gently cleaning the book. The camera holds this view throughout the shot. The conservator, the book and the workbench retain their appearance from the earlier conservation scene. The earlier scene provides visual details of the conservator and the work area. Her cleaning action and the camera framing follow the new side-angle shot described here.

## 평가: 정보 활용과 출력 제어를 분리

| 축 | 확인 내용 |
|---|---|
| 시점 전환 | 요청한 시점으로 전환하고 평가할 얼굴·머리·외부 차체가 보이는가 |
| 과거 증거 효용 | 같은 prompt의 Local-only보다 실제 과거 외관/환경 세부가 잘 유지되는가 |
| 동작/카메라 | 요청한 피사체 동작과 카메라 동작이 구분되어 실현되는가 |
| 필요한 배경/관계 | 작업대·공간 등이 과제에서 필요하면 유지되는가; 배경 유사성 자체를 실패로 세지 않음 |
| 불필요한 제약 | 요청과 충돌하는 과거 pose/손/컷/자막/배치가 출력 선택을 막는가 |
| Local 연결 | 지정한 전환 이후 잔상·겹침 없이 장면이 성립하는가 |

Hard cut을 요청한 결과를 원본 GT의 dissolve와 픽셀 수준으로 같게 만들 필요는 없다. P1로 요청 동작이 달라진 부분은 prompt 준수로 평가한다. 전체 DINO는 보조로 유지하고 얼굴/물체 영역 비교·샘플 프레임 검토와 함께 읽는다. 로봇은 정적인 전시 pose가 의도된 것이므로 모든 사례에 움직임 크기가 클수록 좋다는 기준을 적용하지 않는다.

이번 5개는 여전히 인물·물체 외관 중심이다. 원본을 유지했다고 일반 배경·상태·사건의 활용까지 검증되는 것은 아니다. 배경 자체가 필요한 경우에는 이후 과거 장소를 다른 시점에서 다시 보여주는 요청 같은 별도 진단을 설계할 수 있지만 이번 45회 비교안에 자동 추가하지 않는다.

## P2/P3 해석의 한계

앞서 소수 후속 후보로 둔 P2를 이번에는 사용자의 prompt 추가 요청에 맞춰 5개 모두 작성했고, P3까지 비교안에 포함했다. 두 버전은 **의미적 역할 지시가 실제로 작동하는지 확인할 가설**이다. `use the reference` 같은 meta instruction을 LTX가 LLM처럼 이해한다고 가정하지 않는다. 일반 모델에 Ingredients의 reference-sheet 문법을 붙여 학습된 기능이 생긴다고 가정하지도 않는다.

P3는 positive text의 추가이며 attention mask·의미 분기·negative prompt 기능을 구현한 것이 아니다. 원본 RGB/VAE latent, 참조 위치와 강도는 P1/P2와 동일하다. 역할 설명의 효과와 단순 반복/길이 효과를 분리하려면 별도 대조가 필요하며 이번 비교만으로 그 기전을 확정하지 않는다.

## 그 이후: 원본을 유지한 강도·학습 인터페이스

P1/P2/P3에서도 원하는 정보의 활용이 안 되면 참조 원본을 유지한 채 attention 강도/denoising-step schedule을 바꾸는 소수 진단을 고려한다. 범용 scalar나 schedule을 사용하며 인물만 통과시키는 수작업 의미 mask를 기본으로 두지 않는다. 참조 영향력을 줄이면 증거가 사라질 수 있고, 후반에만 주입하면 큰 형태 전달이 어려울 수 있어 성공을 보장하지 않는다. 같은 backend에서 all-ones/원래 출력 재현을 먼저 검사한다. Attention mass와 출력 변화는 다르므로 관찰만으로 기전을 확정하지 않는다.

별도 CFG 비교는 현재 distilled 8-step의 sampler 조건과 모델 적합성까지 확인한 독립 개입이어야 한다. 첫 비교에 섞지 않는다. Local을 제거해 문제가 해결돼도 본 과제를 해결한 것이 아니므로 Local은 기본 대조에서 유지한다.

Frozen 모델의 비정렬 과거 참조 활용이 계속 제한되면, 원본 장면을 받으며 다른 시점·동작/사건을 생성하도록 학습하는 reference adapter가 후속 후보이다. 범용 projection/gated cross-attention 또는 IC-LoRA로 구현할 수 있지만 기존 효과용 LoRA의 이름만으로 그 기능을 가정하지 않는다. 현재 Stage 1에서 새 학습을 시작하지 않는다.

압축 전역 메모리의 **직접 생성 조건 + 원본 증거 검색**이라는 두 역할을 유지한다. 필요한 정보는 생성 요청/Local/전역 문맥에 의해 선택되어야 하며, 고정된 피사체 전처리로 역할을 제한하지 않는다.
