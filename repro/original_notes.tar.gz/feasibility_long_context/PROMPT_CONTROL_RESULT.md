# 원본 Past 참조 × P0–P3 prompt 비교 결과

2026-09-08. **사용자가 요청한 신규 45회를 모두 첫 시도에 완료했다.** 기존 P0 15개를 재사용해 60개를 비교했다. 정식 누적 생성은 **95회**다. 원본 전체 참조·Past 좌표·seed 42·실제 noise·Local·모델을 유지했고 positive prompt만 변경했다.

[실제 입력·60개 영상·동기화 비교](reports/five_case_prompt/seed42/index.html) · [60조건 CSV](reports/five_case_prompt/seed42/results.csv) · [입력·출력 감사](reports/five_case_prompt/seed42/artifact_verification.json) · [실제 prompt](PROMPT_CONTROL_PROPOSAL.md) · [고정 실행 설정](configs/five_case_prompt.json)

## 핵심 판단

Prompt 구체화와 연속성 설명은 일부 Past 참조 활용을 바꾸지만 일관되게 개선하지 않는다. 로봇·보존 작업자는 외관과 새 구도의 결합이 관찰되고 차량 Video/Past는 P2/P3에서 외부로 전환된다. 학생은 여전히 실패하고 관리자 Video/Past는 P0 성공에서 P1/P2/P3 실패로 바뀐다. P3의 역할 문장이 P2보다 일관되게 낫다는 근거는 없다.

**부분적인 긍정이다.** 원본을 가리지 않고 Past 위치에서도 과거 외관과 새로운 구도를 결합할 수 있다는 근거는 늘었다. 그러나 더 길고 명확한 prompt가 안정적인 해결책은 아니며, 모든 사례가 입력된 증거를 원하는 방식으로 활용하는 것은 아니다. 배경 유지 자체는 실패가 아니고, 차량에서는 요청한 주행을 실현했는지를 별도로 봐야 한다.

## 비교 구성과 실제 통제

- P0: 기존 짧은 prompt. 5사례 × Local/Image-Past/Video-Past = 15개 재사용.
- P1: 구체적인 컷·시점·화면 구성·동작. P2: P1 그대로 + 연속성 문장 1개. P3: P2 그대로 + 과거 정보와 새 구도/동작의 역할 문장 2개.
- 신규: 5사례 × 3조건 × 3대안 = 45회. 최초 3개 검증 후 나머지 42개를 실행했다. 중단/실패 생성이나 재시도는 없다.
- 원본 전체 이미지 144 token / 영상 1,440 token, 기존 RGB/VAE cache 유지. 새 영상 전처리·마스킹·시트·Target 좌표 이동·adapter·학습 없음.
- 512×288, 24 FPS, Local 48프레임을 49프레임으로 인코딩, Target 72프레임, 모델 전체 121프레임. LTX-2.5 distilled BF16, Euler ancestral 8 step, CFG/STG 없음.
- Local 모델 시간 [97/24,146/24)초, Target [146/24,218/24)초. 이미지 Past [0,1/24)초, 영상 Past [0,73/24)초. 원본 timestamp와 모델 좌표를 구분한다.
- 정답 얼굴/머리/차체 색·무늬를 prompt에 쓰지 않았다. 새 text embedding은 별도 cache이며 기존 입력·출력·평가 CSV를 덮어쓰지 않았다.

## GT 전체 DINO 평균 · 보조 지표

| Prompt | Local | Image/Past | Video/Past | Image−Local | Video−Local |
|---|---:|---:|---:|---:|---:|
| P0 | 0.4174 | 0.4301 | 0.4483 | +0.0127 | +0.0308 |
| P1 | 0.4719 | 0.4145 | 0.4129 | -0.0574 | -0.0590 |
| P2 | 0.4969 | 0.4641 | 0.5179 | -0.0328 | +0.0209 |
| P3 | 0.4648 | 0.4602 | 0.5189 | -0.0045 | +0.0541 |

P2/P3의 Video 평균 상승에는 차량의 외부 전환이 크게 기여한다. 관리자 P2 Local처럼 실제 과거 인물과 달라도 GT 구도와 가까워 DINO가 높을 수 있다. 따라서 평균이나 Oracle−Local 점수만으로 외관 정확도·새 행동 준수·일반화 성공률을 정하지 않는다. P1/P2/P3는 GT와 다른 컷이나 행동을 요청하는 부분도 있다.

## 사례별 관찰

정성 관찰은 assistant가 각 조건의 Target 0·8·16·24·40·56·71번 프레임과 실제 Oracle/GT를 비교한 기록이다. 총 60개 출력을 확인했으며 blind 평가나 사용자 확인 완료가 아니다. 정확한 전환 frame·차량 optical flow·identity 점수는 새로 측정하지 않았다.

### 보육원 관리자 재등장

P1/P2/P3의 Local-only는 실내 인터뷰를 만들지만 실제 관리자와 다른 머리·옷차림이다. Image/Past는 P1에서 노트북에 머물다가 P2/P3에서 과거 외관과 장소가 회복된다. Video/Past는 P0에서 작동했지만 P1/P2/P3 모두 노트북 장면에 머문다.

| Prompt | Local DINO | Image/Past | Video/Past |
|---|---:|---:|---:|
| P0 | 0.2008 | 0.3915 | 0.4193 |
| P1 | 0.4254 | 0.1103 | 0.1117 |
| P2 | 0.4686 | 0.4024 | 0.1084 |
| P3 | 0.4273 | 0.4329 | 0.1121 |

- **P0:** Local은 식물 nursery 같은 장소의 다른 인물을 생성한다. Image/Past와 Video/Past는 과거의 짧은 머리·빨간 상의/검은 겉옷과 보육 공간을 함께 전달하되 과거 정면 구도에 가깝다.
- **P1:** Local은 실내 측면 인터뷰로 바뀌지만 Oracle 두 형식은 3초 동안 노트북을 유지한다. 참조 추가가 오히려 전환을 억제한 조건이며 attention 기전은 미측정이다.
- **P2:** Image/Past에서 과거 인물·장소가 다시 보인다. Video/Past는 노트북을 유지한다. Local의 실내 인터뷰 개선을 정확한 identity 회복으로 세지 않는다.
- **P3:** Image/Past는 과거 외관을 전달하며 P0/P2보다 상반신에 가까운 구도다. Video/Past는 여전히 노트북이다. 요청한 측면 구도를 완전히 따르는 것은 아니다.

[Local의 P0–P3 프레임](reports/five_case_prompt/seed42/five_001_nursery_manager/local_prompt_frames.jpg) · [Image/Past](reports/five_case_prompt/seed42/five_001_nursery_manager/image_past_prompt_frames.jpg) · [Video/Past](reports/five_case_prompt/seed42/five_001_nursery_manager/video_past_prompt_frames.jpg)

### 로봇 모형의 가려졌던 머리

P2/P3에서는 Local도 전시 구도로 전환하지만 둥근 은색 머리를 생성한다. Image/Past는 과거에 가까운 투구형 머리와 금색 얼굴부를 더 일찍 보여주고 Video/Past도 후반에 머리가 보인다. 이 사례는 전환 자체의 prompt 효과와 참조 외관의 추가 기여를 구분할 수 있다.

| Prompt | Local DINO | Image/Past | Video/Past |
|---|---:|---:|---:|
| P0 | 0.8736 | 0.8678 | 0.8770 |
| P1 | 0.8843 | 0.8788 | 0.8811 |
| P2 | 0.8741 | 0.8752 | 0.8846 |
| P3 | 0.8611 | 0.8638 | 0.8879 |

- **P0:** 세 조건 모두 Local의 몸통 중심 근접 구도를 유지해 머리 평가가 제한된다.
- **P1:** 화면이 일부 넓어지지만 머리 노출은 P2/P3보다 제한적이다. 완전한 개선으로 세지 않는다.
- **P2:** Local은 약 0.67초 표본부터 전시 구도지만 둥근 은색 머리다. Image/Past는 투구형 머리/금색 얼굴부가 보이고 Video/Past는 약 1.67초 이후 표본에서 머리가 드러난다. 과거의 손 조작은 함께 재현되지 않는다.
- **P3:** P2와 유사하다. Video/Past는 약 2.33초 표본에서 머리 노출이 뚜렷해 더 늦다. 정적인 전시 pose는 요청된 결과이며 움직임이 적다는 이유로 실패로 세지 않는다. 세부 형상 정확도는 별도 정량 검증하지 않았다.

[Local의 P0–P3 프레임](reports/five_case_prompt/seed42/five_002_robot_head/local_prompt_frames.jpg) · [Image/Past](reports/five_case_prompt/seed42/five_002_robot_head/image_past_prompt_frames.jpg) · [Video/Past](reports/five_case_prompt/seed42/five_002_robot_head/video_past_prompt_frames.jpg)

### 교실 학생의 얼굴 재등장

P0/P1/P2/P3의 세 조건 모두 교사 정면과 학생 뒷모습의 Local 구도에 머문다. 학생 얼굴을 보여주는 reverse-angle 전환이 나오지 않아 외관 활용을 평가할 전제가 충족되지 않는다.

| Prompt | Local DINO | Image/Past | Video/Past |
|---|---:|---:|---:|
| P0 | 0.3772 | 0.3570 | 0.3951 |
| P1 | 0.3805 | 0.4032 | 0.4061 |
| P2 | 0.3914 | 0.4052 | 0.4026 |
| P3 | 0.3623 | 0.3900 | 0.4001 |

- **P0:** 세 조건 모두 학생 얼굴 쪽 전환에 실패한다. 교사의 시선·표정 변화나 작은 DINO 상승은 학생 identity 회복이 아니다.
- **P1:** 세 조건 모두 학생 얼굴 쪽 전환에 실패한다. 교사의 시선·표정 변화나 작은 DINO 상승은 학생 identity 회복이 아니다.
- **P2:** 세 조건 모두 학생 얼굴 쪽 전환에 실패한다. 교사의 시선·표정 변화나 작은 DINO 상승은 학생 identity 회복이 아니다.
- **P3:** 세 조건 모두 학생 얼굴 쪽 전환에 실패한다. 교사의 시선·표정 변화나 작은 DINO 상승은 학생 identity 회복이 아니다.

[Local의 P0–P3 프레임](reports/five_case_prompt/seed42/five_003_student_return/local_prompt_frames.jpg) · [Image/Past](reports/five_case_prompt/seed42/five_003_student_return/image_past_prompt_frames.jpg) · [Video/Past](reports/five_case_prompt/seed42/five_003_student_return/video_past_prompt_frames.jpg)

### 캠퍼 밴 외관으로 시점 전환

Local과 Image/Past는 모든 prompt에서 운전석 내부를 유지한다. Video/Past는 P2/P3에서 실제 과거 밴의 외관과 주변 장소를 보여주는 외부 장면으로 전환된다. 다만 과거 주차 구도에 가깝고 고정 카메라에서 바퀴를 굴리며 앞으로 주행했다는 성공 근거는 부족하다.

| Prompt | Local DINO | Image/Past | Video/Past |
|---|---:|---:|---:|
| P0 | 0.2498 | 0.2422 | 0.2434 |
| P1 | 0.2497 | 0.2454 | 0.2524 |
| P2 | 0.2471 | 0.2441 | 0.7715 |
| P3 | 0.2472 | 0.2499 | 0.7994 |

- **P0:** 세 조건 모두 운전석 내부 장면을 지속한다.
- **P1:** 외부 고정 카메라와 차량 자체 이동을 명확히 지시해도 세 조건 모두 내부를 유지한다.
- **P2:** Video/Past만 약 0.67초 표본에서 외부 장면으로 전환되고 과거의 밴 차체·앞부분·주변 장소가 보인다. 새 주행 동작 성공과는 구분한다.
- **P3:** Video/Past의 외부 전환이 유지되지만 P2보다 전환 겹침이 오래 남아 약 1초 표본부터 외관이 명확하다. DINO가 더 높아도 주행 제어가 더 낫다는 뜻은 아니다. Local/Image는 여전히 내부다.

[Local의 P0–P3 프레임](reports/five_case_prompt/seed42/five_004_van_exterior/local_prompt_frames.jpg) · [Image/Past](reports/five_case_prompt/seed42/five_004_van_exterior/image_past_prompt_frames.jpg) · [Video/Past](reports/five_case_prompt/seed42/five_004_van_exterior/video_past_prompt_frames.jpg)

### 보존 작업자의 얼굴 재등장

새 prompt에서 Oracle 두 형식은 회색 곱슬머리·안경을 유지하며 P0의 정면 작업대 전경에서 측면 근접 구도로 바뀐다. Local-only는 다른 머리와 안경 없는 인물이다. 원본을 가리지 않고 과거 외관과 새로운 구도를 결합할 수 있다는 근거지만 얼굴·손·책의 동시 노출과 전환 잔상은 남는다.

| Prompt | Local DINO | Image/Past | Video/Past |
|---|---:|---:|---:|
| P0 | 0.3856 | 0.2921 | 0.3065 |
| P1 | 0.4198 | 0.4348 | 0.4132 |
| P2 | 0.5034 | 0.3938 | 0.4221 |
| P3 | 0.4260 | 0.3646 | 0.3950 |

- **P0:** Local은 다른 인물을 생성하고 두 Oracle은 실제 과거 인물 외관을 전달하지만 정면의 넓은 작업대 구도다.
- **P1:** 두 Oracle에서 회색 머리·안경과 측면 얼굴 구도가 보인다. Image는 전환 겹침이 있고 Video는 약 1초 표본부터 측면 얼굴이 뚜렷하다. Local도 측면 구도지만 실제 과거 외관과 다르다.
- **P2:** 과거 외관·측면 구도는 유지된다. Image의 Local 손 장면 겹침이 더 오래 남는다. Video는 얼굴 위주여서 요청한 손·책 동시 노출은 제한적이다.
- **P3:** 얼굴과 손/작업물이 함께 보이는 구간이 있지만 상단 얼굴이 잘리거나 겹침이 남는다. P1보다 일관된 개선은 아니다. 샘플 프레임에서 과거 영상의 정면 컷 순서/큰 자막을 그대로 재현하는 양상은 보이지 않는다.

[Local의 P0–P3 프레임](reports/five_case_prompt/seed42/five_005_conservator/local_prompt_frames.jpg) · [Image/Past](reports/five_case_prompt/seed42/five_005_conservator/image_past_prompt_frames.jpg) · [Video/Past](reports/five_case_prompt/seed42/five_005_conservator/video_past_prompt_frames.jpg)

## 검증 결과

- 실행 전 기존 2×2 실물 감사를 다시 수행했으며 이전 감사 기록과 정확히 같았다.
- 기존 P0 5개를 같은 batch-size 1 text encoder로 다시 인코딩해 video/audio embedding hash가 모두 정확히 일치했다. 새 P1/P2/P3 15개도 같은 경로로 각각 인코딩했다.
- 신규 45개에서 prompt와 물리 GPU를 제외한 45개 공통 설정을 P0와 비교했다. 실제 text cache, 원본 참조 latent, 전체 위치 좌표, 초기 및 7회 step noise가 각각 의도한 조건과 일치했다.
- 모든 8 step 및 최종 Local/참조 고정 오차는 0이었다. 최종 Local latent도 기존 cache와 정확히 같다.
- 60개 Target **4,320프레임**, Local 결합/모델 전체 출력을 포함해 **18,780프레임**을 전체 디코딩하고 SHA256·512×288·24 FPS PTS를 검사했다.
- 재사용 P0 15개의 DINO 전체/1초 이후 30개 값은 이전 평가와 **차이 0**이었다.
- 최초 검사에서 새 auditor가 Local의 빈 reference tensor를 hash할 때 stride 오류가 나서 빈 배열 처리를 수정했다. 생성 결과나 기존 공통 코드는 변경하지 않았고, 실물 감사 전체가 통과했다.
- 모델 파일은 기존 로컬 경로·크기·mtime을 비교했다. 새 체크포인트 다운로드나 전체 체크포인트 hash 재계산은 하지 않았다.

## 실행 명령과 경로

기준 디렉터리 `/mnt/minu/minseok/LTX-2/longcond`. GPU 0–2만 사용했고 decoder도 조건마다 별도 새 프로세스로 실행했다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_prompt_batch.py --phase preflight
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_prompt_batch.py --phase prepare
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_prompt_batch.py --phase generate --max-jobs 3
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_prompt_batch.py --phase generate
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_five_case_prompts.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_five_case_prompt_report.py
```

- 고정 실행 설정: `configs/five_case_prompt.json`; 작성한 proposal은 별도 보존.
- 코드 snapshot·사전 검증·실행 ledger·stdout 로그: `outputs/five_case_prompt_batch/`.
- 새 text cache: `outputs/five_*/prompt_text_inputs_512x288/P1|P2|P3/`.
- 신규 결과: `outputs/five_*/prompt_control_seed42/P1|P2|P3/local|image_past|video_past/`.
- 평가·20개 GT 포함 비교 영상·15개 시간별 sheet·정성 기록: `reports/five_case_prompt/seed42/`.

## 다음 판단과 연구 범위

문구를 계속 늘리는 것을 기본 후속으로 삼을 근거는 약하다. 다음 진단이 필요하다면 **관리자 Video/Past의 P0↔P1**과 **차량 Video/Past의 P1↔P2**처럼 동일한 원본/형식/좌표에서 전환이 반대로 바뀐 두 쌍이 적합하다. 기존 출력부터 활용해 Local·참조 활용 경로를 비교하고, 원본을 유지한 attention 강도/step 개입은 그 이후 소수 조건으로 검토한다. 추가 attention 관찰·개입은 이번에 실행하지 않았다.

과거 배경도 필요한 정보일 수 있으므로 피사체 추출/시트를 기본으로 되돌리지 않는다. 학생처럼 Local만으로도 새 시점 지시가 실행되지 않는 경우는 증거 검색 실패와 분리해 생성 제어/입력 경로의 한계로 남긴다. 이번 결과는 외관 중심 5개 진단이며 배경 자체의 장거리 복원, 상태·사건·복수 증거, 학습된 메모리를 검증한 것은 아니다.

압축 전역 메모리의 **직접 생성 조건 + 원본 증거 검색** 두 역할은 유지한다. 현재 prompt 비교는 검색된 원본 증거를 생성기에 넣는 경로의 진단이다. 메모리의 직접 생성 기여는 후속에서 같은 증거를 고정한 별도 비교로 검증해야 한다.
