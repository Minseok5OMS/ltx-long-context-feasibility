# FineVideo 5개 원본 · Local/Oracle 결과

**후속 완료:** 이 문서는 당시 Image/Past 비교 기록이다. 이후 사용자 요청으로 [5개 전체 이미지/영상 × Past/Target 2×2](FIVE_CASE_GRID_RESULT.md)를 완료했다. 아래 두 실패 사례만의 시간 이동 제안은 그 실험으로 대체됐다. 최신 영상은 [5개 2×2 보고서](reports/five_case_grid/seed42/index.html)에 있다.

2026-09-07. **사례 선정, 입력 방식 고정, seed 42의 10회 생성·평가를 완료했다. 두 사례에서 과거 인물 외관의 기여가 보였고, 세 사례에서는 요청한 시점 전환과 증거 활용을 확인하지 못했다.** 현재 고정한 image/past 방식이 여러 사례에 안정적으로 작동한다는 긍정 판정은 내리지 않는다.

[실제 입력과 동기화 비교 영상](reports/five_cases/seed42/index.html) · [사전 고정 프로토콜](FIVE_CASE_PROTOCOL.md) · [CSV](reports/five_cases/seed42/results.csv) · [정성 검토 기록](reports/five_cases/seed42/review.json) · [전체 감사](reports/five_cases/seed42/artifact_verification.json)

## 무엇을 비교했나

기존 인터뷰 진단과 다른 FineVideo 원본 5개를 선택했다. 처음 받은 shard의 33개 행을 검토해 6개 후보 MP4를 추가 추출했으며 5개를 사용했다. 추가 네트워크 다운로드는 없었다. 신규 원본 파일은 약 102.4 MiB다. 무작위로 뽑은 5개나 모든 장거리 과제 유형을 대표하는 표본이 아니다.

모든 사례는 Local 2초, Target 3초다. 과거 3초 선택 구간의 **36번 프레임 한 장만** 독립 VAE 인코딩해 past 위치의 144 token으로 추가했다. 영상 latent는 넣지 않았다. Local/Oracle의 prompt·local·base AV 좌표·실제 초기 및 7회 ancestral target noise·모델·생성 설정을 동일하게 맞췄다. 두 조건 모두 512×288, 24 FPS, seed 42, 기존 LTX 2.5 distilled BF16 8 step이다. IC-LoRA·새 학습·메모리·검색은 없다.

과거 이미지는 원본의 진짜 과거이며, 원본 간격은 선택 구간 끝 기준 약 15–218초다. 모델에는 전체 긴 문맥 대신 Local과 선택된 증거만 입력한다. 모델 시간 좌표는 Oracle `[0,1/24)`, Local `[97/24,146/24)`, Target `[146/24,218/24)`로 공통 고정했다. Local은 denoising 중 고정 조건이며 단순한 디코딩 prefix가 아니다.

장면/시점 전환은 prompt로 요청했다. 정답 옷·얼굴·안경 등의 속성을 prompt에 넣지 않았지만, 인물이나 물체의 역할과 전환 의도는 제공했다. 따라서 자연스러운 전환 예측, retrieval 대상 선택, 상태·사건 추론을 검증하는 실험은 아니다. 입력과 사례는 출력 확인 전에 고정했다.

## 수치와 실제 관찰

DINO는 새 Target의 공통 12프레임을 GT와 비교한 **전체 프레임 보조 유사도**다. 신원 정확도나 의존 속성 복원 점수가 아니다.

| 사례 | 원본 간격 | Local DINO | Oracle DINO | Oracle−Local | 정성 관찰 |
|---|---:|---:|---:|---:|---|
| 보육원 관리자 | 79.063초 | 0.2008 | 0.3915 | +0.1907 | 외관 전달. 참조의 정면 중간 구도를 따름 |
| 로봇 머리 | 217.634초 | 0.8736 | 0.8678 | −0.0058 | 양쪽 모두 머리가 잘린 Local 구도 지속 |
| 교실 학생 | 14.583초 | 0.3772 | 0.3570 | −0.0202 | 양쪽 모두 교사 정면 지속, 학생 얼굴 미노출 |
| 차량 외관 | 167.000초 | 0.2498 | 0.2422 | −0.0076 | 양쪽 모두 운전석 내부 지속 |
| 보존 작업자 | 61.967초 | 0.3856 | 0.2921 | −0.0935 | 회색 머리·안경 전달. 전환 지연과 넓은 참조 구도 |

**외관 기여가 관찰된 사례가 2개라는 기술이며, 일반화 성공률 40%라는 추정이 아니다.** 두 사례도 GT의 새로운 시점까지 정확히 재현한 완전한 성공으로 세지 않는다. 검토는 assistant가 Target 0/0.33/0.67/1/1.67/2.33/2.96초의 샘플 프레임을 확인한 것이며, 사람이 전체 영상을 검수하거나 blind 평가한 결과가 아니다.

### 보육원 관리자: 외관과 관련 장면이 전달됨

Local-only는 긴 머리·붉은 체크 셔츠의 인물을 식물 공간에 생성한다. Oracle은 올린 머리·붉은 긴팔·검은 앞치마와 보육 공간을 함께 전달한다. 0.33초 샘플에서는 전환이 겹치고, 0.67초부터 외관이 뚜렷하다. 이후 손·고개·입의 자세가 달라져 한 장을 정지 재생한 결과는 아니다.

다만 Oracle의 정면 중간 구도·배경을 강하게 따른다. GT는 측면 근접 구도다. Prompt가 GT의 정확한 framing까지 요청하지 않았으므로 이를 별도의 지시 위반으로 보지 않지만, 다른 구도로 외관을 옮기는 능력도 입증하지 않는다. `nursery manager`의 의미가 식물 재배장과 보육원 사이에서 모호하므로, 이 사례의 이득에는 장면 의미를 구별하는 효과도 포함될 수 있다.

### 로봇·학생·차량: 시점 전환이 먼저 막힘

로봇은 양쪽 모두 머리가 잘린 몸통·다리 구도를 유지한다. 검은 몸체와 배경이 이미 Local에 있어 DINO가 약 0.87로 높지만, 평가 대상 머리의 금색 부분이나 형태를 회복했다고 볼 수 없다.

학생은 양쪽 모두 교사를 바라보는 구도를 유지한다. 학생 정면 얼굴을 담은 과거 이미지가 있어도 역방향 시점으로 바뀌지 않는다. 차량은 양쪽 모두 운전석에서 도로를 계속 달리고, 외부 차체가 보이지 않는다. 움직임 자체는 있지만 요청한 전환을 충족하지 못한다.

이 결과로 참조 attention이 0이었다거나 참조 내용을 내부에서 읽지 않았다고 단정할 수는 없다. **현재 입력에서 필요한 시점으로 전환하고 참조 세부를 드러내는 동작이 성립하지 않았다**는 관찰이다. 시점 전환 실패와 전환 후의 세부 합성 능력을 분리할 후속 진단이 필요하다.

### 보존 작업자: DINO 하락과 외관 개선이 동시에 발생

Local-only는 약 1초에 전환이 겹치고, 이후 검은 머리를 묶은 안경 없는 작업자를 측면 근접 구도에 생성한다. Oracle은 1초 샘플까지 손·도구를 지속하지만 1.67초부터 회색 머리와 안경을 갖춘 과거 작업자를 닮은 외관을 넓은 작업대 구도에 생성한다. 이후 고개·손 자세가 변한다.

Oracle은 외관 정보를 전달하지만 참조의 배경·넓은 구도를 따르고 전환이 늦다. 그래서 GT 전체 유사도는 낮다. 1초 이후 공통 샘플 DINO도 Local 0.5368, Oracle 0.3946이므로 초반 지연만의 문제가 아니다. 이 사례는 **DINO 증감을 인물 외관의 성공/실패로 대체하면 안 되는 이유**를 보여준다.

## 검증과 실행 오류 복구

- 10조건의 **52개 공통 설정**, 입력 cache·source clip·원본 PTS·frozen config·실행 코드 snapshot을 검사했다.
- 실제 Oracle clean token은 한 장의 cache latent와 정확히 같았다. Local의 추가 참조는 0 token이었다. 실제 base/참조 좌표는 앞선 성공 N1의 좌표와 정확히 같았다.
- 실제 초기 및 7회 ancestral target noise가 10조건 모두 동일했고, 기록된 seed에서 다시 계산한 noise와 일치했다.
- 8개 denoising step과 최종에서 고정 latent 오차는 모두 0이었다. 최종 Local latent가 cache와 같고, 참조를 제거한 16-frame latent만 디코딩했음을 확인했다.
- Target 720프레임과 Local 결합/전체 디코딩 영상을 포함한 **3,130프레임**을 전체 디코딩하고 해상도·24 FPS PTS·SHA256을 검사했다. DINO checkpoint는 기존 로컬 캐시를 사용했다.

첫 실행은 세 사례의 Local 영상을 완료했으나 세 Oracle의 8-step denoising 후 diffusion VAE의 `CHUNKED_EAGER` 디코더에서 CUBLAS/illegal-memory-access 오류가 발생했다. 디코더를 별도 CUDA 프로세스로 분리해 복구했다. 같은 Local latent를 분리 디코딩한 Target·Local 결합·전체 MP4의 해시는 원래 영상과 모두 같았다. 재실행한 최초 6조건의 생성 latent도 중단 전 저장된 latent와 비트 단위로 같았다.

모든 정식 10조건에 같은 분리 디코더를 적용해 재실행했다. 입력·prompt·noise·모델·decoder seed·사례를 바꾸지 않았다. 이전 3개 완료 예비 Local과 3개 디코더 실패 시도 및 당시 코드/로그는 `image_past_seed42_attempt1/`, `outputs/five_case_batch_attempt1/`에 보존했고 정식 수치에서 제외했다. [복구 기록](reports/five_case_selection/execution_recovery.json)

평가 코드에서 Local의 빈 참조 tensor 해시를 만들 때 stride 오류가 한 번 발생해 빈 byte열의 SHA256을 사용하도록 고쳤다. 생성 코드나 결과는 바꾸지 않았고 이후 전체 감사·평가가 통과했다. 메모리 peak는 **denoising 부모 프로세스와 별도 decoder 프로세스 각각** 기록한다. 표의 약 39.144 GiB는 부모의 allocator peak이며 두 프로세스 동시 device 점유량의 계측치는 아니다.

정식 신규 생성은 조건당 모델 로딩·분리 디코딩을 포함해 **19.76–23.20초**, 부모 프로세스 peak 약 **39.144 GiB**였다. cache 준비·프로세스 시작·후처리 전체 벽시계 시간과는 구분한다. 기존 정식 25회에 이번 10회를 더해 채택한 생성은 총 **35회**다.

## 판정과 다음 방향

합의한 5개 사례의 실행·평가는 완료했다. **과거 이미지가 생성에 기여할 수 있다는 제한적 근거는 늘었지만, image/past를 안정적인 범용 증거 입력 경로로 채택할 근거는 부족하다.** 메모리가 불필요하다는 결과도 아니다. 입력 경로와 전환 제어의 한계가 함께 드러났다.

**당시 제안 · 이후 대체됨:** 학생·차량의 같은 이미지 시간 좌표만 생성 시작으로 이동하는 신규 2회를 제안했으나, 사용자는 5개 전체의 2×2를 먼저 진행하도록 수정했다. 그 비교는 기존 기준 10개 재사용 + 신규 15회로 완료했다. 최신 해석과 attention/prompt의 후속 검토 순서는 [2×2 결과](FIVE_CASE_GRID_RESULT.md)와 [NEXT_STAGE.md](NEXT_STAGE.md)를 따른다.

전역 메모리의 직접 생성 조건과 원본 증거 검색이라는 두 역할은 모두 유지한다. 새로운 메모리 학습은 아직 시작하지 않았다. [후속 기술 제안과 미검증 항목](NEXT_STAGE.md)에 정리했다.

## 재현·산출물

기준 디렉터리는 `/mnt/minu/minseok/LTX-2/longcond`다. 최초 추출·입력 준비는 [사전 프로토콜](FIVE_CASE_PROTOCOL.md)에 있다. 같은 코드/입력이면 완료된 생성은 건너뛴다. 기존 입력 파일을 재작성하지 않는다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_batch.py --phase generate
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_five_cases.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_five_case_report.py
```

- 입력: `data/five_*/metadata.json`, `outputs/five_*/five_case_inputs_512x288/`.
- 정식 생성: `outputs/five_*/image_past_seed42/{local,oracle}/`.
- 실행 명령·로그·코드 snapshot: `outputs/five_case_batch/`. 최초 cache 준비 ledger는 `outputs/five_case_batch_attempt1/prepare_ledger.json`에 보존되어 있다.
- 수치·feature·정성·감사·동기화 영상: `reports/five_cases/seed42/`.
- 원본 선정·전체 후보 메타데이터·source preview·오류 복구: `reports/five_case_selection/`. 이곳의 전체 FineVideo 메타데이터는 생성 입력으로 사용하지 않는다.

기존 `results.csv`는 초기 9조건을 보존한다. 이번 수치는 별도 CSV이며 이전 실험과 평균해 하나의 성공률로 만들지 않는다.
