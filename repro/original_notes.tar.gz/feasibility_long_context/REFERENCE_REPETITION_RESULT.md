# 과거 이미지 반복수 1·2·4·10 결과

2026-09-07. **반복수 2·4에서도 인터뷰 외형은 전달됐다. 4회는 전환이 더 오래 겹쳤지만 1초 이후 유사도는 1·2회와 비슷했고, 10회에서는 3초 동안 공사 장면이 지속됐다.**

[실제 입력과 동기화 비교](reports/reference_repetition/seed42/index.html) · [조건별 CSV](reports/reference_repetition/seed42/results.csv) · [사전 진단 설계](REFERENCE_REPETITION_DIAGNOSIS.md)

## 실행 범위와 결과

사용자가 다음 단계 진행을 요청해 seed 42에서 2·4회만 새로 생성했다. 기존 이미지/past의 1회(이전 A)와 10회(이전 B)는 원본 설정·좌표·latent·검증 기록을 대조해 재사용했다. 새 생성 2회, 비교 대상 4조건이다.

| 반복수 | 참조 token | DINO 전체 3초 | DINO 1초 이후 | 관찰 |
|---|---:|---:|---:|---|
| 1 · 기존 | 144 | 0.7726 | 0.9208 | 인터뷰 외형 전달 |
| 2 · 신규 | 288 | 0.7404 | 0.9238 | 인터뷰 외형 전달 |
| 4 · 신규 | 576 | 0.6726 | 0.9201 | 초반 전환이 더 오래 겹친 뒤 외형 전달 |
| 10 · 기존 | 1,440 | 0.0345 | 0.0256 | 3초 동안 공사 장면 지속 |

DINOv2 ViT-B/14의 동일한 12개 target 시점에서 전체 프레임 cosine을 계산했다. 1초 이후는 frame 26·32·39·45·52·58·65·71의 평균이며, 신규 결과를 보기 전에 정한 보조 구간이다. 신원 정확도나 자동 전환 감지 값은 아니다.

전체 구간의 frame 0·14·28·43·57·71과 초반 frame 0·2·4·6·8·12·16·20을 확인했다. 1·2회는 0.83초 샘플에서 인터뷰가 뚜렷하다. 4회는 0.83초에도 공사 차량·나무와 인터뷰가 겹치지만 1.17초 샘플에서는 인터뷰가 뚜렷하다. 이후 연한 셔츠·인물·실내 배경이 유지되고 얼굴·입 모양이 변한다. 10회는 검토한 모든 시점에서 공사 장면을 지속한다.

신규 2·4회의 인접 프레임 픽셀 MAE는 각각 1.3632, 1.7134(0–255 스케일)다. 완전한 정지 출력은 아니지만, 이것만으로 자연스러운 동작이나 참조 복사 부재까지 검증하지는 않는다. 현재 성공은 과거 인터뷰의 외형 재현 성격이 강하다. 정성 기록은 assistant의 샘플 프레임 검토이며 사용자 검수나 blind 평가와 구분한다.

## 해석

- **측정한 지점 중 4회까지는 전달되고 10회에서 실패한다.** 5–9회는 실행하지 않았으므로 정확한 실패 임계점, 단조성, 모든 seed에서의 경계를 주장하지 않는다.
- 1→2→4회에서 전체 점수는 낮아지지만 1초 이후는 모두 약 0.92다. 초반 전환 지연·혼합이 전체 점수 차이의 주요 부분과 관련된다. 반복량 증가가 즉시 외형 전달 능력 소실을 뜻하지는 않는다.
- 10회는 평가한 3초 범위에서 인터뷰로 전환하지 않았다. 더 긴 생성에서도 영원히 전환하지 않는다는 뜻은 아니다.
- 같은 내용·시간 좌표에서도 반복량에 따라 동작이 달라진다는 앞선 해석은 유지된다. 실제 attention 가중치·내부 표현을 측정하지 않아 비중 변화의 방향이나 기전을 확정할 수는 없다.
- 다른 실험에서 영상 1,440 token을 생성 위치로 옮기면 성공했다. 이번 결과는 일반적인 token 상한이나 모든 영상 참조의 한계를 정한 결과가 아니다.

## 실제 입력과 통제

모든 조건은 원본 90–93초 클립의 frame 36(약 91.466378초)을 독립 인코딩한 `oracle_still` `[1,128,1,9,16]`를 사용한다. 이 tensor를 시간축으로 1·2·4·10회 복제한다. RGB 재인코딩, 새 영상, 새 정보는 추가하지 않았다.

모든 복사본의 공간 좌표와 시간의 시작·끝은 기존 1회와 같다. 참조는 `[0,1/24)`초, Local은 `[97/24,146/24)`초, Target은 `[146/24,218/24)`초다. 입력을 추가하는 API의 임시 causal grid는 latent 길이에 맞춰 만든 뒤 참조 시간의 양 끝을 기존 1회의 좌표로 덮는다. 실제 모델에 들어간 좌표가 정확한 복제인지 검사했다.

모델·prompt·local·base AV 좌표·초기 및 7회 step noise·sampler·guidance·해상도·FPS·생성 길이·decoder seed를 통제했다. Local·Reference는 clean 상태로 고정하고 Target을 denoise한다. 추가 참조는 디코딩 전에 제거한다. GT는 평가에서만 읽었다. 기존 일반 distilled 경로를 사용했고 IC-LoRA나 새 학습은 없다.

## 검증과 재현

- 실제 설치된 `state_with_conditionings` 경로에서 1·2·4·10회의 입력 token, 공간·시간 좌표, 고정 mask와 동일 target noise를 검사했다. CPU와 GPU에서 두 테스트가 통과했다. CPU 좌표 계산의 기존 1 ULP 차이는 최대 1e−6초 허용했고 실제 GPU 좌표는 anchor와 정확히 일치했다.
- 네 조건의 공통·paired 설정 38개와 실제 저장된 초기 및 7회 step noise가 일치했다. 선언한 seed로 target noise를 재생성해 일치함을 확인했다.
- 새 실행의 실제 clean reference token은 기존 이미지의 정확한 2·4회 복제다. 모든 8개 step과 최종 고정 오차는 0이며 최종 Local latent도 원본과 정확히 같다.
- 네 Target의 전체 288프레임을 디코딩해 24 FPS PTS를 확인했다. 각 출력 파일 SHA256, 기존 1회·10회의 config/좌표/latent 감사 기록도 확인했다. 두 anchor의 DINO 재평가는 기존 값과 정확히 같았다.
- GPU 0에서 2회는 18.24초, GPU 1에서 4회는 15.99초에 완료했다. 모델 로딩·디코딩 포함 시간이며 기존 입력 cache 준비는 제외한다. 최대 PyTorch GPU 할당은 두 조건 모두 약 39.145 GiB다. 조건별 별도 프로세스를 사용했고 이번 신규 실행은 첫 시도에 성공했다.

`longcond` 디렉터리 기준:

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/test_repetition_controls.py -v
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_repetition.py --case N2 --seed 42 --gpu 0
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_repetition.py --case N4 --seed 42 --gpu 1
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_reference_repetition.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_reference_repetition_report.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_reference_report.py
```

신규 산출물: `outputs/pilot_001_interview_return/reference_repetition_seed42/repeat_2/`, `repeat_4/`. 보고서·CSV·DINO 특징·감사·정성 기록은 `reports/reference_repetition/seed42/`에 있다. 기존 runner를 수정하지 않고 `run_reference_repetition.py`를 추가했다. 생성 runner SHA256은 `4393d8af4e493c764d449714b2bdabdf8488323af602972be8a1a8548a1ef15c`이며 동일 이름의 `outputs/source_snapshots/` 하위 폴더에 당시 코드도 보존했다.

## 다음 작업

이번 두 조건은 외형 전달 여부가 명확하므로 추가 seed나 5–9회 탐색을 자동으로 늘리지 않았다. 내부 attention 측정은 선택적인 후속 진단이다. 이제 사용자와 합의한 **5개 의존성 사례의 Local-only / Local+Oracle 비교**를 위해 사례를 고르고 입력 형식을 고정하는 것이 다음 본 작업이다. 신규 Random·20개 확대는 필수가 아니다.

이미지 한 장의 성공은 검색한 외형 증거의 활용 가능성을 보여준다. 영상의 시간 정보나 새로운 상태·사건 활용, 압축 전역 메모리의 직접 생성·검색 기여는 후속 검증 대상으로 유지한다.
