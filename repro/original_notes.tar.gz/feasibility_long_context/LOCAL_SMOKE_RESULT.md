# 첫 local-only 생성 결과

2026-09-06. **준비한 요리 영상의 2초 local로부터 3초를 생성하는 실행을 완료했다.** 입력·생성 경로는 다음 참조 활용 진단으로 진행할 수 있는 상태다. 장거리 참조의 효과를 평가한 결과는 아니다.

- [GT와 생성 영상 비교 페이지](reports/local_smoke/index.html)
- [Local 포함 5초 비교 영상](outputs/pilot_000_local_cooking/local_seed42/comparison.mp4)
- [생성된 target 3초](outputs/pilot_000_local_cooking/local_seed42/local_only.mp4)
- [실행 설정](outputs/pilot_000_local_cooking/local_seed42/config.json)
- [실행 로그](outputs/pilot_000_local_cooking/local_seed42/run.log)
- [수치 및 출력 검증 기록](reports/local_smoke/summary.json)
- [환경·입력 규격 설명](SETUP_NOTES.md)

## 실행 내용

`pilot_000_local_cooking`의 원본 246–248초를 사용했다. 미래 GT 248–251초 영상은 생성 완료 후 비교 페이지를 만드는 단계에서만 읽었다. 원본 전체 설명, Q&A 또는 target의 외관 설명을 prompt에 넣지 않았다.

| 항목 | 실제 설정/관찰 |
|---|---|
| 실행 환경 | 기존 `.venv`를 사용하는 `uv run --no-sync --project ..` |
| 사용 GPU | 물리 GPU 0만 노출; 사용자 허용 범위 0–2 |
| 모델 | 로컬 LTX 2.5 22B distilled BF16, video VAE, Gemma4 text encoder |
| 해상도·FPS | 512×288, 24 FPS |
| 길이 | 실제 local 48프레임, 정렬용 복제 1프레임, 생성 target 72프레임 |
| 생성 | 8-step Euler ancestral, seed 42, prompt enhancement 없음 |
| 처리 범위 | Distilled 첫 단계만 사용; audio latent는 공동 생성하지만 audio 입력·디코딩·평가 없음 |
| 총 실행 시간 | 약 35.87초; 모델 로딩과 출력 저장 포함 |
| GPU 메모리 | PyTorch 최대 할당 39.18 GiB, 최대 예약 40.53 GiB |
| Local latent 유지 | 모든 8개 step 및 최종 상태의 최대 절대 오차 0 |

GPU 작업 종료 후 GPU 0 사용량은 약 14 MiB로 돌아왔다. GPU 1–2는 이번 실행에 사용하지 않았다.

## 확인한 동작과 한계

입력 경계 프레임, GT/생성 비교 프레임, 생성 3초의 24개 미리보기 프레임을 확인했다. 냄비·주변 조리대·의복의 배치가 이어지고, 손과 도구가 냄비를 젓는 움직임이 나타난다. 단순히 마지막 local 프레임을 정지 상태로 출력한 결과는 아니다. 첫 생성 프레임에도 장면이 크게 바뀌는 현상은 보이지 않았다.

다만 손과 도구의 경계가 흐리고 일부 프레임의 모양이 불안정하다. GT의 정확한 동작 경로와 일치하지 않는다. 한 seed, 낮은 해상도, refinement 없는 첫 단계 출력에 대한 관찰이므로 최종 영상 품질이나 다양한 입력에 대한 안정성을 확정하지 않는다. 프레임 검토와 자동 디코딩을 수행했으며 사람이 전체 영상을 재생해 검수한 결과는 아니다.

0–255 RGB 기준 간단한 픽셀 진단은 다음과 같다. **학습된 지각 유사도나 벤치마크 성능 점수가 아니다.**

| 진단 | 생성 | GT |
|---|---:|---:|
| 인접 프레임 평균 절대 차이 | 4.616 | 5.125 |
| 마지막 local → 첫 target 평균 절대 차이 | 7.658 | 7.211 |

생성 영상에서 인접 프레임 차이가 0.1 미만인 쌍의 비율은 0%였다. 이는 정지 출력 여부의 보조 신호이며 동작의 물리적 정확성을 보장하지 않는다. 생성/GT 전체 픽셀 MAE는 23.333이며, 동작 타이밍 차이도 포함하므로 이 수치로 장거리 feasibility를 판정하지 않는다.

Local 조건은 RGB 고정이 아니라 VAE latent 고정이다. Diffusion VAE로 다시 디코딩한 prefix의 원본 대비 RGB MAE는 약 5.155다. 비교 영상의 앞 2초는 두 패널 모두 원본 local을 사용하므로, 원본 local과 생성 target 사이의 실제 연결을 볼 수 있다. 별도 `decoded_model_sequence.mp4`에는 정렬용 프레임까지 포함한 모델의 전체 디코딩을 보존했다.

## 검증 및 재현

Local MP4의 SHA256, 준비 메타데이터의 원본 시간 범위, local/target 인접성, VAE latent shape, 생성 중 finite 값 및 prefix 고정, 출력 프레임 수·PTS와 전체 출력 디코딩을 검사했다. GT와 생성 target 모두 72프레임/3초다.

`local_latent.pt`, `prompt_context.pt`, `target_initial_noise.pt`, `generated_latent.pt`, `denoising_trace.json`을 실행 폴더에 저장했다. Target 초기 noise shape는 `[1,1296,128]`, SHA256은 `ca8cf6c7debda2469031e4f0fe1a2f2b9a661398837c877d5bfed4c9fbef47aa`다. 동일 seed만으로 향후 참조 token 추가 시 동일 target noise가 된다고 가정하지 않는다.

실제 실행 명령은 `longcond` 기준이다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_generation.py --mode local --gpu 0 --seed 42 --prepare-only
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_generation.py --mode local --gpu 0 --seed 42
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_local_report.py
```

완료된 출력 폴더는 재생성 시 덮어쓰지 않도록 막았다. 다시 생성하려면 `--output-dir feasibility_long_context/outputs/pilot_000_local_cooking/local_seed42_repeat`처럼 새 폴더를 지정한다. `make_local_report.py --run-dir ...`로 해당 실행의 보고서를 다시 만들 수 있다. 보고서 스크립트는 공통 `reports/local_smoke/` 페이지를 지정한 실행 기준으로 갱신한다.

부모 LTX 저장소 루트에서 실행하려면 다음 형식을 사용한다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync python longcond/feasibility_long_context/run_generation.py --mode local --gpu 0 --seed 42 --output-dir longcond/feasibility_long_context/outputs/pilot_000_local_cooking/local_seed42_repeat
```

## 다음 단계

현재 local-only 경로를 바탕으로 인터뷰 재등장 사례에서 non-local 참조를 넣는 방식을 구현한다. 먼저 한 사례의 Local/Random/Oracle을 공통 prompt, target 초기 noise, ancestral step noise와 출력 조건으로 비교하고 실제 참조 활용을 확인한다. 그 후 두 번째 사례로 확인한다. 이 결과가 있어야 distant evidence의 효용을 논할 수 있으며, 전역 메모리의 직접 생성 기여는 후속 별도 가설이다.
