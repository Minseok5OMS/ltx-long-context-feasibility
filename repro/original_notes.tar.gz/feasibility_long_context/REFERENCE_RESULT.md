# 첫 참조 활용 실험 결과

**후속 실험 완료:** 아래 초기 9회와 별도로 참조 형식 × 시간 위치의 2×2 비교를 세 seed에서 완료했다. [후속 결과](TEMPORAL_POSITION_RESULT.md)와 [동기화 영상](reports/temporal_position/index.html)을 먼저 확인할 수 있다. 아래에는 초기 실험의 결과와 당시 해석을 보존한다.

2026-09-06. **시각 참조를 생성에 반영할 가능성은 확인했지만, 과거 시간 위치에 둔 영상을 안정적으로 활용하는 능력은 아직 확인하지 못했다.** 학습 없이 기존 LTX-2.5 distilled를 사용했다. 두 인터뷰 사례의 Local/Random/Oracle 6회와 첫 사례의 추가 이미지 진단 3회, 총 9회의 완료된 생성을 평가했다.

[입력과 생성 결과 비교](report.html) · [결과 CSV](results.csv) · [실제 참조 이미지·구간·주입 방식](REFERENCE_PROTOCOL.md)

## 결과를 보기 전에: 무엇을 어떻게 넣었나

| 실행 묶음 | 공통 Local | Random 참조 | Oracle 참조 | 주입한 참조 |
|---|---|---|---|---|
| 001 / past | 공사 차량 156.825–158.825초 | 산 풍경 44–47초 | 보라색 셔츠 인터뷰 90–93초 | 각각 3초 영상 전체, 1,440 token, 과거 시간 위치 |
| 002 / past | 안전모 작업자 175.636–177.636초 | 동일한 산 풍경 44–47초 | 안경·수염·무늬 셔츠 인터뷰 60–63초 | 각각 3초 영상 전체, 1,440 token, 과거 시간 위치 |
| 001 / target_guide | 001과 동일 | 산 풍경 클립의 프레임 36 | 보라색 셔츠 클립의 프레임 36 | 각각 RGB 한 장, 144 token, 생성 시작 시간 위치 |

표의 구간은 원본 시간이다. 각 열은 Local-only / Local+Random / Local+Oracle의 별도 실행이며 Random과 Oracle을 함께 넣지 않았다. Local-only에는 먼 과거 참조가 없다. GT는 평가 전용이다.

주입 흐름은 **참조 RGB → 독립 LTX VAE 인코딩 → `[Local | Target noise | Reference]` video token 배열 → 기존 video self-attention**이다. 모든 step에서 Local과 Reference의 diffusion latent를 고정하고 Target을 생성한다. 참조는 text prompt나 새 메모리 adapter에 넣은 것이 아니다. 추가 참조 token은 디코딩 전에 제거한다.

`past`는 참조에 모델 시간 0–3.041667초를, `target_guide`는 6.083333–6.125초를 부여한다. 생성 target의 모델 시간은 둘 다 6.083333–9.083333초다. `target_guide`도 target token을 직접 덮어쓰지는 않지만, 생성 시작 시점의 모습을 알려주는 강한 조건이다. `strength=1`은 참조 latent를 clean 상태로 고정한다는 의미이며 attention weight를 1로 정한다는 뜻이 아니다.

**실제 입력의 처음·가운데·마지막 프레임, 정확한 대표 이미지 두 장, 원본 영상 링크, tensor shape, attention·mask·시간 좌표, 코드 대응은 [참조 입력·주입 설명](REFERENCE_PROTOCOL.md)에 모았다.** 비교 페이지에도 각 결과 바로 위에 Local/Random/Oracle 입력을 표시했다.

## 관찰

DINOv2 ViT-B/14의 target 12프레임 평균 cosine이다. 전체 장면 유사도를 보는 보조 지표이며 인물 정확도 점수가 아니다.

| 사례 / 입력 | Local | Random | Oracle | Oracle − Local | Oracle − Random |
|---|---:|---:|---:|---:|---:|
| 001 / 과거 영상 `past` | 0.2713 | 0.3017 | 0.0392 | −0.2322 | −0.2626 |
| 002 / 과거 영상 `past` | 0.4106 | 0.3097 | 0.4469 | +0.0364 | +0.1372 |
| 001 / 생성 시점 이미지 `target_guide` | 0.2713 | 0.2271 | 0.8596 | +0.5883 | +0.6325 |

- **001, past:** Oracle 조건에서는 공사 차량 장면이 이어졌다. Local/Random은 다른 인물이 있는 인터뷰로 전환했지만 정답 외형은 복원하지 못했다.
- **002, past:** Oracle 출력에 과거 폴로셔츠 어깨의 검은 반복 무늬가 나타났다. 하지만 local의 안전모와 인물이 남았으며, 정답의 검은 안경·수염은 나타나지 않았다. 의상 세부가 일부 반영된 징후이며 인물 복원 성공은 아니다. 주황색은 local 조끼에도 있어 그 자체를 성공으로 세지 않았다.
- **001, target_guide:** 과거 영상의 가운데 이미지 한 장을 생성 시작 시점의 추가 keyframe으로 주자, 연한 보라색 셔츠·짧은 밝은 머리·안경 없는 외형·원형 표시 배경이 나타났다. 첫 target 프레임에는 local 장면이 남고 이후 전환한다. Random 이미지는 산 풍경을 먼저 유도하고 이후 다른 인터뷰로 바뀌었다.

외형 판정은 assistant가 조건별 6개 표본 프레임을 확인한 기록이다. 사람의 검수, blind 평가 또는 정밀한 신원 판별이 아니다. 자세 변화와 전체 디코딩 프레임의 픽셀 변화를 함께 확인했다. `target_guide` Oracle의 인접 프레임 MAE는 0.920/255이며, 과거 Oracle 프레임과의 최근접 축소 픽셀 MAE 평균은 7.190/255다. 단순 정지 화면은 아니지만 참조와 매우 비슷한 재구성이다. 이 수치로 복잡한 복사·암기나 새로운 사건 생성 능력을 판별할 수 없다.

## 무엇을 검증했는가

각 조건은 같은 prompt, local latent, target 초기 noise, 7회 ancestral step noise, audio noise, 모델과 생성 설정을 사용했다. 저장된 noise tensor의 SHA256까지 확인했다. 모든 8개 step과 최종 상태에서 local 및 참조의 고정 latent 오차가 0이었다. 추가 reference token은 target의 생성 token을 덮어쓰지 않는다. GT 영상은 생성 후 평가에서만 읽었다.

512×288, 24 FPS, local 2초 + target 3초, 8-step distilled 첫 단계이며 refinement/upscaler는 사용하지 않았다. CPU 입력 cache를 공유하고 물리 GPU 0–2만 사용했다. 완료된 생성별 모델 로딩 포함 시간은 약 16–20초, PyTorch 최대 할당 메모리는 약 39.14 GiB였다. 입력 인코딩과 별도 평가 시간은 이 시간에 포함되지 않는다. CPU noise 정책이 달라 이전 요리 local-only 실행과 같은 noise라고 비교하지 않는다.

`past`는 3초 과거 영상을 독립 인코딩한 1,440 token을 과거 시간 좌표로 추가했다. Source의 간격은 약 66/115초지만 모델에서는 참조와 local 사이 빈 시간을 1초로 압축했다. `target_guide`는 같은 과거 영상의 가운데 프레임을 독립 인코딩한 144 token에 생성 시작 시점 위치를 부여했다. **시간 위치와 참조량·영상/이미지 형식이 함께 달라졌으므로 위치만의 효과라고 할 수 없다.**

한 프로세스에서 여러 조건을 연속 실행한 첫 `target_guide` 시도는 두 번째 조건의 diffusion VAE 디코딩에서 CUDA illegal-memory-access로 중단됐다. 조건별 새 프로세스를 사용하는 dispatcher로 수정한 뒤 세 조건을 다시 완료했다. 중단 시도는 `outputs/pilot_001_interview_return/reference_target_guide_seed42_attempt1/`에 보존했고 평가에서 제외했다. 원인 전체를 규명한 것은 아니며, 분리 실행으로 이번 재현을 완료했다.

기본 `past` 실행의 원본 runner SHA256은 `98a6c8bfbc7ff15616195c4d419303f43ae5a1fff12105e400bfe465b85322f2`이며 같은 이름의 `outputs/source_snapshots/` 하위 폴더에 소스를 보존했다. 이후 변경은 `--all-modes`의 프로세스 분리 dispatch다. 기본 실험과 추가 진단의 Local 생성은 실제 저장된 latent와 target 영상 SHA256까지 완전히 일치했다. 총 9회 target의 648프레임·PTS 및 보고서 내부 링크도 검사했다. 문서에 적은 Local/Target/Reference 시간 범위는 모든 실행의 저장된 위치 tensor와 일치했다. 입력 미리보기의 원본·PNG hash도 확인했다. 실행별 설정과 소스 hash는 각 `config.json`, 검사 결과는 [artifact_verification.json](reports/reference/artifact_verification.json)에 있다.

## 판단과 다음 단계

현재 결과는 **조건 활용에 대한 제한적인 긍정, 비정렬 과거 영상 활용에 대한 혼합 결과**다. 메모리의 직접 생성 기여·검색·긴 의존성 해결은 아직 평가하지 않았다. 같은 원본 인터뷰의 반복 장면이고, prompt가 장면 전환을 지시하며, seed가 하나뿐이다. 이 세 행을 합쳐 벤치마크 평균이나 성공률을 주장하지 않는다.

다음은 **동일한 과거 이미지 한 장과 동일한 token 수를 고정하고 과거 위치 / 생성 위치만 바꾸는 비교**가 적절하다. 같은 local·prompt·noise에서 다른 인터뷰 인물의 이미지를 넣는 hard negative도 함께 보면, 원하는 외형을 선택적으로 전달하는지 확인할 수 있다. 그 뒤 공통 seed 2–3개로 반복하고 서로 다른 원본의 자연스러운 재등장·상태 의존 사례로 확대한다. 현재 결과만으로 전체 메모리 학습을 시작하거나 연구 목표를 검색 전용으로 축소할 근거는 없다.

## 실행과 산출물

명령 기준 디렉터리는 `longcond`다. 아래는 이번 실행에 사용한 명령 형식이며 `--example`으로 `data/pilot_001_interview_return`와 `data/pilot_002_interview_return`를 지정한다. `--mode`는 Local/Random/Oracle, GPU는 각각 0/1/2를 사용했다. 동일 출력 경로에 다른 코드·입력이 있으면 덮어쓰지 않고 중단한다. 기록된 기본 실험은 dispatcher 수정 전 소스로 실행했다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_comparison.py --example feasibility_long_context/data/pilot_001_interview_return --prepare-inputs --gpu 0
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_comparison.py --example feasibility_long_context/data/pilot_001_interview_return --mode oracle --gpu 2 --layout past --seed 42
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_comparison.py --all-modes --gpu 0 --layout target_guide --seed 42
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_reference.py --example feasibility_long_context/data/pilot_001_interview_return --gpu 0 --layout past --seed 42
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_reference.py --example feasibility_long_context/data/pilot_002_interview_return --gpu 1 --layout past --seed 42
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_reference.py --gpu 0 --layout target_guide --seed 42
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/test_reference_controls.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_reference_report.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/verify_reference_artifacts.py
```

`outputs/<example>/reference_<layout>_seed42/<mode>/`에 target·연결 영상, 설정·로그, 최종 latent, 실제 초기/step noise, 위치 tensor를 보존했다. `reports/reference/<example>/<layout>_seed42/`에는 DINO 특징, 점수·통제 검사 JSON, 외형 검토 JSON과 비교 페이지가 있다. 기존 로컬 DINOv2 소스·가중치를 사용해 추가 다운로드와 패키지 변경 없이 평가했다.
