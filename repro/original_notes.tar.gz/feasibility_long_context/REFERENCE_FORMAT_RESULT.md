# 영상 past 실패 원인 진단: A–E 실행 결과

2026-09-07. **성공한 이미지 latent를 동일한 과거 시간 좌표에서 10회 복제하는 것만으로도 실패가 재현됐다.** 따라서 영상의 temporal encoding이나 여러 시점으로 펼친 시간 배치가 있어야만 실패하는 것은 아니다. 현재 조건에서는 참조의 반복도/token 수가 중요한 원인 후보로 좁혀졌다.

[실제 입력과 A–E 동기화 영상](reports/reference_format/seed42/index.html) · [조건별 CSV](reports/reference_format/seed42/results.csv) · [진단 설계](REFERENCE_FORMAT_DIAGNOSIS.md)

사용자 의견에 따라 **seed 42 하나**로 B·C·D만 새로 생성했다. A·E는 기존 결과를 검증해 재사용했다. 신규 생성 3회, 비교 대상 5조건이다. 성공/실패 구분이 명확하고 설계에 포함된 A 성공/B 실패 분기에 해당해 추가 seed는 실행하지 않았다.

## 결과

| 조건 | 입력과 시간 배치 | Token | DINO 전체 3초 | DINO 1초 이후 | 정성 관찰 |
|---|---|---:|---:|---:|---|
| A · 기존 | 이미지 1장, 한 시점 | 144 | 0.7726 | 0.9208 | 인터뷰 외형 전달 |
| B · 신규 | A latent ×10, 모두 같은 시점 | 1,440 | 0.0345 | 0.0256 | 공사 장면 지속 |
| C · 신규 | B와 같은 latent, 여러 시점 | 1,440 | 0.0382 | 0.0360 | 공사 장면 지속 |
| D · 신규 | 기존 영상 latent, 모두 같은 시점 | 1,440 | 0.0374 | 0.0304 | 공사 장면 지속 |
| E · 기존 | 기존 영상 latent, 여러 시점 | 1,440 | 0.0392 | 0.0344 | 공사 장면 지속 |

DINOv2 ViT-B/14의 동일한 12개 target 시점에서 전체 프레임 cosine을 계산했다. 1초 이후 점수는 그중 frame 26·32·39·45·52·58·65·71의 평균이다. 이 보조 구간은 B·C·D의 출력을 확인하기 전에 평가 코드에 정했으며, 자동 전환 감지나 신원 정확도 점수가 아니다.

GT와 A–E의 frame 0·14·28·43·57·71을 확인했고, 초반 frame 0·2·4·6·8·12·16·20도 추가로 확인했다. A는 초기 공사 장면에서 인터뷰로 전환했다. 약 0.33초 샘플부터 인터뷰가 겹치고 0.83초에는 인터뷰가 뚜렷하다. B·C·D·E는 전체 검토 구간에 걸쳐 공사 차량과 나무 장면을 이어갔다. 높은 DINO를 얻지 못한 것이 단순한 전환 지연만으로 설명되지는 않는다.

새 출력의 인접 프레임 평균 절대 픽셀 차이는 0–255 스케일에서 B 4.397, C 3.449, D 5.371이다. 차량·나무·먼지의 위치와 모양 변화가 있고, D 후반에는 흐림도 보인다. 정지 출력은 아니지만 인터뷰 참조 활용에는 실패했다. 정성 기록은 assistant의 샘플 프레임 검토이며 사용자의 영상 검수나 blind 평가는 아니다.

## 이번 비교로 좁혀진 것

**가장 중요한 비교는 A→B다.** B는 A에서 쓴 독립 이미지 latent를 정확히 10회 복제했다. 각 복사본의 공간 좌표와 시간의 시작·끝도 A와 동일하다. 새로운 RGB, 움직임, 영상 VAE 인코딩, 여러 시점 배치를 넣지 않았다. 이 조작으로도 인터뷰 외형 전달이 실패했다.

이는 현재 과거 위치에서 **참조의 수/중복도를 늘리는 개입만으로 실패가 발생할 수 있다**는 근거다. 복제는 attention에서 참조가 차지하는 비중 등도 바꿀 수 있어, 단순한 연산량이나 메모리 용량 문제로 해석하지 않는다. 실제 attention 가중치나 내부 표현 변화는 이번에 측정하지 않았다.

B↔C와 D↔E에서는 시간 분산을 없애도 회복되지 않았다. 다만 네 조건이 모두 실패한 결과이므로 그 사이의 작은 DINO 차이로 시간 배치나 VAE 표현의 영향이 없다고 판단할 수 없다. 기존 영상 실패의 모든 원인이 설명됐다는 뜻도 아니다.

앞선 실험에서는 **동일한 1,440 token 영상이 생성 시간 위치에서 성공**했다. 따라서 “많은 token은 항상 나쁘다”는 결론도 맞지 않는다. 이번 결과와 앞선 결과를 함께 보면 참조량·반복도와 시간 위치의 상호작용을 더 조사해야 한다.

## 실제 입력과 주입 방식

모든 조건의 참조 출처는 원본 90–93초의 과거 인터뷰다. A·B·C의 대표 이미지는 클립 frame 36, 원본 약 91.466378초다. A의 cache shape은 `[1,128,1,9,16]`이고 B·C는 시간축으로 정확히 10번 복제한 `[1,128,10,9,16]`이다. D·E는 기존 영상 cache `[1,128,10,9,16]`을 그대로 사용했다. VAE·text encoder 입력 cache를 새로 만들지 않았다.

- A·B·D: 모든 참조 token의 시간 구간을 동일한 `[0,1/24)`초에 배치했다.
- C·E: 기존 영상의 저장된 causal grid를 그대로 사용했다. 전체 범위는 `[0,73/24)`초다.
- 공통 Local: `[97/24,146/24)`초. 공통 Target: `[146/24,218/24)`초. Audio의 기본 시간 좌표도 유지했다.

이번 조작은 앞선 평행 이동과 달리 참조 내부의 시간 배치를 변경한다. 참조를 한곳에 모을 때 시간의 시작·끝 좌표를 모두 바꿨다. 공간 좌표·token 내용·배열 순서·denoise mask·keyframe marker는 유지했다. 원본 영상의 구간을 바꾸거나 latent를 재인코딩한 것이 아니다.

`run_reference_format.py`는 기존 runner와 같은 512×288, 24 FPS, 8-step distilled, BF16, Euler ancestral eta=1, SimpleDenoiser, joint AV 생성 경로를 사용한다. 참조를 추가한 뒤 `ReferenceTimeLayout`이 기존 A/E에서 저장한 좌표를 적용한다. Local·Reference latent를 고정하고 Target만 denoise하며 추가 참조는 디코딩 전에 제거한다. GT는 평가에서만 읽었다. IC-LoRA·메모리 모델·새 학습은 사용하지 않았다.

## 검증과 실행 기록

- CPU/GPU에서 실제 입력 cache의 복제 순서, B=C latent, D의 원본 영상 latent 보존, B=D 좌표, C=E 좌표, mask와 base 좌표 보존을 검사했다. 실제 `state_with_conditionings` 호출 경로를 사용한 두 검사가 모두 통과했다.
- 첫 시도는 conditioning 메서드의 keyword 인자 이름 불일치로 denoising 전에 멈췄다. 인자 이름을 수정하고 실제 호출 경로 검사를 보강한 뒤 세 조건을 다시 실행했다. 중단된 설정·로그·당시 코드는 `outputs/pilot_001_interview_return/reference_format_seed42_attempt1/`에 보존했으며 결과에 포함하지 않았다.
- 완료된 다섯 조건의 실제 초기 및 7회 step noise를 비교하고 선언한 seed로 다시 만들 수 있음을 검사했다. 공통 모델·Prompt·Local·base AV 좌표·sampler 설정이 일치했다.
- 새 실행에는 실제로 추가된 clean reference token도 저장했다. B·C의 token이 A의 정확한 10회 복제이고 D의 token이 기존 영상 cache와 같음을 확인했다.
- 모든 8개 step과 최종 상태에서 Local·Reference 고정 오차는 0이었다. 최종 base latent에서 Local 7칸이 입력과 정확히 같았다. 모든 출력 파일 SHA256, Target 360프레임의 전체 디코딩과 정확한 24 FPS PTS를 확인했다.
- 기존 A·E를 재평가한 DINO는 이전 점수와 정확히 일치했다. 원본 설정·코드를 보존하며 재사용했다.
- GPU 0·1·2에서 각각 B·C·D를 실행했다. 새 생성은 모델 로딩·디코딩 포함 B 17.38초, C 19.44초, D 16.48초였다. 최대 PyTorch GPU 할당은 약 39.145 GiB다. 이미 준비된 입력 cache 생성 시간은 제외한다.

`longcond` 디렉터리 기준 재현 명령:

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_format.py --case B --seed 42 --gpu 0
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_format.py --case C --seed 42 --gpu 1
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_reference_format.py --case D --seed 42 --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_reference_format.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_reference_format_report.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_reference_report.py
```

신규 출력은 `outputs/pilot_001_interview_return/reference_format_seed42/`의 `B_repeat_same`, `C_repeat_spread`, `D_video_same`에 있다. 설정·로그·reference token·좌표·noise·생성 latent·영상이 포함된다. 보고서·CSV·DINO 특징·정성 기록·검증 provenance는 `reports/reference_format/seed42/`에 있다. 이전 결과 CSV와 생성 파일은 유지한다.

## 다음 방향

우선 같은 이미지·같은 과거 시간 좌표에서 **반복수를 2·4로 낮춰 어느 범위에서 외형 전달이 깨지는지** 확인하는 것이 적절하다. 그 결과와 함께 참조 반복에 따른 attention 비중 변화를 측정하거나 보정하는 비교를 검토한다. Attention 개입을 사용할 때는 해당 연산 경로와 backend 차이까지 통제해야 하며, 이것은 후속 설계 과제다.

위 제안에 따라 이후 [반복수 2·4 진단](REFERENCE_REPETITION_RESULT.md)을 완료했다. 2·4회에서도 외형을 전달했고, 4회는 전환이 더 오래 겹쳤지만 1초 이후 유사도는 1·2회와 비슷했다. Attention 측정은 아직 수행하지 않았다. 다음 본 작업은 사용자와 합의한 5개 사례의 Local/Oracle 비교다. 최종 연구의 압축 전역 메모리 직접 기여와 원본 evidence 검색 역할은 모두 후속 검증 대상이다.
