# 참조 시간 위치 2×2 비교 결과

2026-09-06. **같은 영상 참조의 시간 좌표만 바꾸면 생성 결과가 크게 바뀐다. 다만 이미지 한 장은 과거 위치에서도 외형을 전달하므로, 시간 위치와 참조 형식의 상호작용으로 해석해야 한다.**

[입력·동기화 비교 영상 보기](reports/temporal_position/index.html) · [조건별 CSV](reports/temporal_position/results.csv) · [원래 실험 설계](TEMPORAL_POSITION_ABLATION.md)

파일럿 001의 Oracle 참조를 이미지/영상 × 과거/생성 시간 위치로 비교했다. Seed 42의 기존 두 결과를 검증해 재사용하고 빈 두 조건을 생성한 뒤, seed 43·44에서 네 조건을 반복했다. **신규 생성 10회, 분석 대상 12개 조건**이다. GPU 0·1에서 생성하고 GPU 2에서 기존 로컬 DINOv2로 평가했다.

## 결과

아래는 생성 target의 12개 시점에서 측정한 DINOv2 전체 프레임 cosine이다. 신원 정확도나 메모리 성능이 아닌 보조 유사도다.

| Seed | 이미지 / 과거 | 이미지 / 생성 | 영상 / 과거 | 영상 / 생성 |
|---|---:|---:|---:|---:|
| 42 | 0.7726 | 0.8596 | 0.0392 | 0.9062 |
| 43 | 0.7119 | 0.8440 | 0.0481 | 0.8683 |
| 44 | 0.7352 | 0.8534 | 0.0419 | 0.8692 |
| 평균 | **0.7399** | **0.8523** | **0.0430** | **0.8812** |

같은 참조 형식에서 생성 위치−과거 위치의 평균 차이는 이미지 **+0.1124**, 영상 **+0.8382**다. 세 seed 모두 같은 방향이다. 영상의 위치 효과에서 이미지의 위치 효과를 뺀 차이는 평균 **+0.7257**로, 위치 효과가 두 형식에서 크게 다르다. 이는 기술 통계이며 유의성 검정이나 독립 사례 평가가 아니다.

GT와 네 조건을 각 seed의 0, 0.58, 1.17, 1.79, 2.38, 2.96초에서 확인했다. 정성 기록은 assistant의 샘플 프레임 검토이며 사용자 검수나 blind 평가는 아니다.

- **영상 / 과거:** 세 seed 모두 공사 차량과 나무 장면을 계속 생성했다. 인터뷰 외형이 나타나지 않았다.
- **영상 / 생성:** 세 seed 모두 인터뷰의 연한 보라색 셔츠·짧은 밝은 머리·원형 표시 배경을 재현했다. 처음에는 공사 장면과 겹치지만 0.58초 샘플에서는 인터뷰가 뚜렷하다.
- **이미지 / 과거:** 세 seed 모두 결국 인터뷰 외형을 전달했다. 다만 seed 43·44의 0.58초에는 공사와 인터뷰가 겹쳤고, 1.17초 이후에는 인터뷰가 뚜렷했다.
- **이미지 / 생성:** 전환이 더 빨랐다. 첫 target 프레임에는 공사 장면이 남지만 0.58초에는 인터뷰가 뚜렷하다. Seed 43에는 양손 제스처도 보인다.

이미지의 점수 차이를 곧바로 외형 보존 능력 차이로 해석하면 안 된다. **전환 지연을 본 뒤 추가로 계산한 사후 진단**에서, 1초 이후의 기존 8개 샘플만 평균하면 이미지/과거는 seed별 0.9208·0.9225·0.9314, 이미지/생성은 0.9314·0.9213·0.9281이다. 차이가 작고 방향도 일정하지 않다. 이번 이미지의 전체 구간 점수 개선은 주로 더 빠른 장면 전환과 관련된 것으로 보인다. 원래 전체 구간 지표는 그대로 유지했다. 계산 결과는 `reports/temporal_position/transition_diagnostics.json`에 있다.

영상/생성 조건에는 입·머리 자세 변화가 있지만 참조의 구도와 동작에 매우 가깝다. 인접 프레임 평균 절대 픽셀 차이는 0–255 스케일에서 0.647–0.747이고, 128×72로 축소해 과거 Oracle의 가장 가까운 프레임과 비교한 평균 차이는 4.53–5.15다. 완전한 정지 영상이라고 판단할 근거는 없지만, 높은 DINO를 새로운 상태나 사건의 생성 성공으로 해석할 수도 없다.

## 실제로 바꾼 것

두 형식 모두 원본 90–93초의 과거 인터뷰에서 가져왔다. 이미지에는 같은 클립의 frame 36, 원본 약 91.466378초의 RGB 한 장을 독립 인코딩한 cache를 썼다. 영상에는 72프레임 앞에 첫 프레임을 한 번 복제해 73프레임을 인코딩한 cache를 썼다.

| 항목 | 이미지 | 영상 |
|---|---|---|
| 참조 token | 144 | 1,440 |
| 과거 위치의 시간 구간 | [0, 1/24)초 | [0, 73/24)초 |
| 생성 위치의 시간 구간 | [146/24, 147/24)초 | [146/24, 219/24)초 |
| 좌우 비교에서 바뀐 값 | 추가 참조 시간 좌표 +146/24초 | 추가 참조 시간 좌표 +146/24초 |

공통 Local은 [97/24, 146/24)초, Target은 [146/24, 218/24)초다. 영상 참조 끝은 padding을 보존해 Target보다 1/24초 길다. 이는 모델 시간 좌표이고, RGB 출처는 계속 과거다. GT는 생성 입력에 쓰지 않았다.

`VideoConditionByKeyframeIndex(frame_idx=0)`로 동일한 causal grid를 만든 뒤, `ShiftReferenceTime`이 **추가 참조의 시간 좌표만** 이동한다. 영상의 `frame_idx`를 직접 nonzero로 바꾸면 causal 보정이 달라져 73프레임 폭이 80프레임으로 바뀌므로 그렇게 실행하지 않았다.

일반 LTX-2.5 distilled, 512×288, 24 FPS, 8-step Euler ancestral, eta=1, BF16, 동일 Prompt·Local·모델·기본 AV 좌표·seed별 실제 초기 및 7회 step noise를 사용했다. 참조는 추가 token으로 attention에 참여하며, Local과 참조 latent는 생성 중 고정한다. 추가 참조는 디코딩 전에 제거한다. IC-LoRA·새 메모리 모듈·학습은 사용하지 않았다.

## 검증과 재현

- CPU/GPU 조건 검사 5개가 통과했다. GPU에서 기존 이미지/생성 및 영상/과거 좌표를 **정확히** 재현했다. CPU의 나눗셈은 CUDA의 reciprocal 연산과 최대 약 1 ULP 차이가 있어 CPU 대조에만 1e-6초 허용치를 사용했다.
- 12개 조건의 공통 설정, 실제 cache hash, reference tensor, 원본 실행 코드 hash, 실제 초기·7회 step noise, base 좌표, 최종 latent를 검사했다. 모든 좌우 쌍의 저장된 좌표는 지정한 시간 이동과 정확히 일치했다.
- 모든 8개 step과 최종 Local·Reference 고정 오차는 0이었다. 기존 두 결과의 DINO 재평가도 이전 점수와 정확히 일치했다.
- 새 생성은 회당 15.38–19.40초, 최대 PyTorch 할당 GPU 메모리 39.145 GiB였다. 모델 로딩·디코딩 포함, 이미 준비된 입력 cache 생성 시간 제외다.

`longcond` 디렉터리에서 실행한 명령이다. 반복 실행 시 완료된 동일 코드·입력 조건은 건너뛴다. 각 생성은 독립 프로세스를 사용한다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_temporal_position.py --seed 42 --reference-kind image --position past --gpu 0
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_temporal_position.py --seed 42 --reference-kind video --position target --gpu 1
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_temporal_seed.py --seed 43 --gpu 0
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_temporal_seed.py --seed 44 --gpu 1
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_temporal_position.py --seeds 42 43 44 --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_temporal_report.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_reference_report.py
```

신규 설정·로그·latent·noise·영상은 `outputs/pilot_001_interview_return/temporal_position_seed{42,43,44}/`에 있다. 재사용 두 조건은 기존 `reference_past_seed42/oracle/`, `reference_target_guide_seed42/oracle/`에 그대로 있다. `reports/temporal_position/artifact_verification.json`에 조건별 실제 경로와 hash를 기록했다. 원래 Local/Random/Oracle의 `results.csv`와 구분해 이번 수치는 `reports/temporal_position/results.csv`에 저장했다.

## 해석과 다음 단계

2026-09-07 후속 논의: 영상 past와 이미지 past의 차이 원인을 먼저 조사하도록 **token 수·시간 배치·latent 표현 차이를 분리하는 진단을 우선 제안**했다. [갱신된 진단 설계](REFERENCE_FORMAT_DIAGNOSIS.md)에 중간 offset의 의미와 신규 세 조건을 설명했다. 이후 seed 42의 B·C·D 3회로 실행 완료했으며 [A–E 결과](REFERENCE_FORMAT_RESULT.md)에 기록했다.

사용자의 temporal RoPE 가설은 **특히 영상 참조에 대해 강하게 지지된다.** 같은 영상과 token 수, 같은 noise에서 시간 좌표만 바꿔 결과가 뒤집혔다. 다만 RoPE 계산 자체나 특정 attention head를 따로 조작한 실험은 아니며, 위치 입력이 기존 video/AV attention에 미치는 전체 효과를 관찰했다.

이미지가 더 먼 과거 위치에서도 작동하고 영상은 실패하므로, 단순히 “멀수록 참조를 못 쓴다”거나 “시간 위치가 모든 변수 중 가장 중요하다”고 결론 내릴 수 없다. 형식 간에는 내용·token 수·시간 폭·VAE temporal encoding이 함께 달라진다.

처음에는 중간 offset으로 위치 민감도를 확인하고 다른 인물 참조로 외형 선택성을 확인하는 것을 제안했다. 2026-09-07 논의에서는 위의 **영상/이미지 차이 원인 분리 진단을 먼저 진행하는 방향**으로 우선순위를 조정해 제안했다. 그 뒤 관련 조건의 중간 offset과 다른 인물 참조, 다른 원본의 자연스러운 재등장·상태 의존 사례로 확대한다. 이 후속 실험은 아직 실행하지 않았다.

최종 연구의 압축 전역 메모리가 직접 생성에 주는 기여와 원본 evidence 검색 역할은 여전히 별도 검증 과제다. 현재 결과는 그 전에 해결할 LTX 참조 입력 배치의 민감도를 확인한 진단이다.
