# 참조의 temporal RoPE 위치 영향 분리: 실험 설계

2026-09-06. 사용자는 현재 결과에서 temporal RoPE embedding의 영향이 가장 클 것이라는 가설을 제시했다. 기존 실험은 참조량과 시간 위치를 함께 바꿨으므로 이를 분리하는 아래 설계를 수립했다. **이 2×2 비교는 seed 42·43·44에서 실행 완료했다.** 아래에는 당시 설계를 보존하며, 실제 관찰과 검증은 [결과 문서](TEMPORAL_POSITION_RESULT.md)와 [비교 영상](reports/temporal_position/index.html)에 기록했다.

## 첫 비교: 2×2 조건

파일럿 001의 동일한 과거 인터뷰 90–93초에서 시작한다. 행 안에서는 저장된 reference latent를 그대로 재사용하고 시간 좌표만 변경한다. Local, prompt, 기본 모델, 생성 위치, 초기 및 step noise, decoder seed는 대응 조건끼리 고정한다.

| 참조 입력 | 과거 위치: reference 시작 0초 | 생성 위치: reference 시작 146/24초 |
|---|---|---|
| 같은 대표 이미지 한 장 / 144 token | **추가할 조건** | 기존 `target_guide`에 해당 |
| 같은 3초 영상 / 1,440 token | 기존 `past`에 해당 | **추가할 조건** |

기존 결과는 표의 대각선 두 칸이다. 먼저 seed 42에서 빈 두 칸을 채운다. 이후 네 조건을 공통 seed 43, 44에서도 반복해 한 seed에만 나타나는 변화인지 확인한다. 기존 결과 재사용 시 생성 입력·좌표·noise·설정의 동일성을 검사하고 원본 코드 snapshot과 provenance를 유지한다.

각 행의 좌우 비교는 **같은 시각 정보와 같은 token 수에서 temporal 위치만의 영향**을 본다. 각 열의 상하 비교는 영상/이미지 참조 형식의 차이를 보지만, 여기에는 token 수·동작 정보·VAE temporal encoding의 차이가 함께 있으므로 단순 token 수 효과라고 해석하지 않는다.

## 좌표 변경 방식

Reference는 동일한 방식으로 먼저 인코딩·patchify하고 같은 위치 grid를 만든다. 그 뒤 **추가 reference token의 시간 좌표에만 일정한 offset을 더한다.** 공간 좌표, 시간 구간 폭과 상대 간격, token 배열 순서, clean latent, denoise mask는 보존한다. Local/Target/Audio의 기본 좌표는 모두 고정한다.

```python
# 동일한 reference conditioning state를 만든 뒤
positions = state.positions.clone()
positions[:, 0, base_video_tokens:, :] += reference_time_offset_seconds
# 나머지 state와 생성 설정은 그대로 유지
```

현재 `VideoConditionByKeyframeIndex`는 `frame_idx == 0`일 때와 아닐 때 VAE의 causal 좌표 보정 규칙이 달라진다. 특히 영상에서는 **frame_idx만 0→146으로 바꾸면 순수한 평행 이동이 되지 않을 수 있다.** 따라서 공통 grid를 만든 후 좌표를 이동하고, 변경된 값이 reference 시간축뿐인지 tensor로 검사한다.

기본 Local 범위는 [4.041667,6.083333)초, Target은 [6.083333,9.083333)초다. 이미지 참조 시간 폭은 1/24초, 영상 참조는 기존 padding을 보존한 73/24초다. 영상 참조를 시작점 기준으로 이동하면 끝은 9.125초여서 Target 끝보다 1/24초 길다. 이 범위를 기록하고, 편의를 위해 참조를 자르거나 시간축을 늘리거나 줄이지 않는다. 참조 RGB의 출처는 계속 과거이며 위치 이동으로 GT가 입력되는 것은 아니다.

## 무엇으로 판단할까

주판정은 인터뷰 인물의 외형·셔츠·배경이 전달되는지, Local 장면이 남거나 섞이는지, 움직임이 이어지는지다. DINO 전체 프레임 유사도는 보조 지표로 사용한다. 결과 페이지는 각 행의 과거/생성 위치를 나란히 재생할 수 있게 구성한다.

- 이미지와 영상 모두 생성 위치로 이동했을 때 반복적으로 좋아지면, 이 진단에서 **참조 시간 위치가 결과를 크게 바꾼다**는 근거가 된다.
- 이미지가 두 위치에서 모두 좋고 영상이 두 위치에서 모두 나쁘면, 참조 형식·양·temporal encoding의 영향을 더 조사한다.
- 이미지의 생성 위치에서만 좋으면, 위치와 참조 형식이 함께 작용하는 결과다.

이 비교만으로 특정 attention head의 기여나 모든 장면에서의 단조로운 거리 감쇠를 증명하지 않는다. 위치 입력 변화가 video self-attention 및 기존 AV 연결에 미치는 전체 영향을 관찰하는 실험이다.

위치 영향이 확인되면 **같은 이미지의 중간 시간 offset**을 추가해 변화 양상을 보고, 다른 인터뷰 인물의 과거 이미지로 바꾸어 어떤 외형을 따라가는지도 확인한다. 후자는 참조 외형의 선택적 전달 진단이며 검색 정확도 평가와 구분한다. IC-LoRA 적용이나 메모리 학습은 이 비교의 변인에 추가하지 않는다.
