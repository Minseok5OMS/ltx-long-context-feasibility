# 공식 2.5 IC-LoRA 목록과 참조 마스킹 검토

2026-09-08. 사용자 제공 [All LTX-2.5 IC-LoRAs](https://docs.ltx.io/open-source-model/integration-tools/ic-lo-ra-adapters#all-ltx-25-ic-loras)의 15개 모델 카드 링크를 직접 열어 용도를 확인했다. Ingredients의 파일 목록도 확인했다. 가중치 다운로드·로딩·이미지 전처리·신규 생성은 하지 않았다. 정식 생성 누적은 50회다.

**후속 사용자 의견 반영:** 이 문서는 공식 카드·입력 규격의 검토 기록이다. 사용자는 배경·물체·사람 모두의 정보를 활용해야 하므로 피사체 추출·배경 제거·시트 제작으로 입력을 제한하는 방향을 재검토하도록 했다. 아래 Ingredients/마스킹 적용 제안은 미실행이며 현재 우선순위에서 내렸다. 최신 방향은 [원본 전체 Past 참조의 prompt 비교](PROMPT_CONTROL_PROPOSAL.md)와 [다음 단계](NEXT_STAGE.md)를 따른다.

## 공식 지원 안내와 모델 이름

공식 문서는 지원하지 않는 버전을 항목에 표시한다고 안내한다. Ingredients는 2.5 목록에 있고 미지원 표기가 없다. 따라서 **공식 안내상 2.5 적용 후보로 취급**한다. 해당 목록의 15개 카드 링크는 확인 시점 모두 `LTX-2.3-22b-IC-LoRA-*` 저장소로 연결됐다. 학습 기반과 파일명이 2.3인 사실을 2.5 미지원으로 해석하지 않는다. [공식 목록](https://docs.ltx.io/open-source-model/integration-tools/ic-lo-ra-adapters)

Dub-It과 Relight는 같은 목록에서도 2.5 지원 개발 중으로 명시한다. 표 위의 HDR도 2.3 전용/2.5 개발 중이다. 목록에 있다는 사실만으로 예외 표시까지 무시하지 않는다. 현재 우리 512×288·8-step·Local prefix에서의 성능은 공식 지원 여부와 별도로 미검증이다. 이는 새로운 호환성 장애가 확인됐다는 뜻이 아니다.

## 15개 모델 카드 검토

아래 용도는 각 카드의 설명을 요약했으며, 연구 적합성은 assistant의 판단이다.

| 공식 항목·실제 모델 카드 | 주 입력·용도 | 이번 문제에서의 판단 |
|---|---|---|
| [Ingredients](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Ingredients) | 인물·소품·장소의 참조 시트 → 새 행동의 영상 | 시트 기반 외관 재사용 후보; 현재 원본 유지 경로의 우선순위에서는 제외 |
| [Union Control](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Union-Control) | Canny·Depth·Pose, 절반 해상도 참조 | 형상/자세 제어. 외관 추출 전용은 아님 |
| [Motion Control](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Motion-Track-Control) | 희소 움직임 궤적, 절반 해상도 참조 | 외관 전달 후 새 이동을 제어할 후속 후보 |
| [Pixel Spatial Upscaler](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Pixel-Spatial-Upscaler) | 저해상도 영상 → 2×/4× 세부 생성 | 현재 외관/장면 분리 질문의 직접 해법은 아님 |
| [In-Outpainting](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-In-Outpainting) | 영상과 mask → 영역 채우기/화면 확장 | 주어진 장면 편집. 비정렬 과거 외관 전달과 다름 |
| [Water Simulation](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Water-Simulation) | 원본 장면을 유지하며 물 추가 | 외관 분리용 아님 |
| [Colorization](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Colorization) | 흑백 영상 채색 | 과거 정답 색을 찾아 옮기는 기능과 다름 |
| [Decompression](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Decompression) | 압축 손상 복원 | 복원용 |
| [Deblurring / Deblur](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Deblur) | 흐린 원본 영상 선명화 | 복원용, 구도 보존이 목적 |
| [Day to Night](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Day-To-Night) | 같은 구도·움직임을 유지하며 밤으로 변환 | 조명 편집용 |
| [Instant Shave](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Instant-Shave) | 수염 제거, 다른 모습·움직임 유지 | 지정 속성 편집용, 범용 속성 전달용 아님 |
| [Cross-Eyed](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Cross-Eyed) | 눈 방향 효과, 표정·움직임·구도 보존 | 지정 효과용 |
| [Clean Plate](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Clean-Plate) | 사람·움직이는 물체 제거 후 빈 배경 복원 | 피사체를 남기는 전처리와 반대 목적 |
| [Dub-It](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-DubIt) | 영상·음성을 이용한 더빙 | 2.5 개발 중 표기, 이번 외관 과제의 우선 후보 아님 |
| [Relight](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Relight) | 방향 구체를 넣은 영상으로 태양광 방향/강도 변경 | 2.5 개발 중 표기, 조명 제어용 |

## Ingredients의 실제 입력

현재 [파일 목록](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Ingredients/tree/main)에 공개된 가중치는 **`ltx-2.3-22b-ic-lora-ingredients-0.9.safetensors`**, 표시 용량 약 **1.31 GB**다. 카드의 Usage 부분에는 학습 중 파일명도 남아 있으므로 실제 다운로드 파일명은 이 목록을 따른다. 바이너리는 받거나 검사하지 않았다.

카드 규격은 검은 배경에 인물/소품 등의 패널을 배치한 정지 참조 시트를 영상으로 반복해 넣는 것이다. 학습 bucket은 768×448·121프레임·24 FPS이고 참조 해상도 비율은 1이다. 참조 설명과 생성할 행동의 설명을 나누어 사용한다. 일반 LoRA 로더로 가중치만 적용하고 reference 입력을 생략해서는 의도한 조건 방식이 되지 않는다. [Ingredients 모델 카드](https://huggingface.co/Lightricks/LTX-2.3-22b-IC-LoRA-Ingredients)

당시 적용 제안은 실제 과거 RGB의 관측된 피사체만으로 시트를 구성하는 것이었다. 관측하지 않은 뒷모습/외관을 생성하거나 정답 외관을 prompt에 써서 증거를 대체하지 않는다는 통제를 제안했다. 이 구성의 효과와 Local 결합은 미검증이다. 이후 사용자가 배경도 필요한 정보라고 강조했으므로 피사체 시트로 제한하는 이 제안은 현재 기본 경로에서 제외했다.

## 피사체 추출·시트 생성은 자동인가

09-08 사용자 질문에 따라 [공식 Ingredients distilled workflow](https://github.com/Lightricks/ComfyUI-LTXVideo/blob/master/example_workflows/2.3/LTX-2.3_ICLoRA_Ingredients_Single_Stage_Distilled.json)의 실제 노드 연결을 확인했다. 이 예제는 `LoadImage`로 이미 준비된 `ingredients_input.jpg`를 읽는다. 이후 이미지 크기 조절, `RepeatImageBatch`를 통한 프레임 반복, `LTXAddVideoICLoRAGuide`의 참조 인코딩·주입이 연결된다. 원본 영상에서 피사체 선택·segmentation·배경 제거·시트 합성을 수행하는 노드는 이 예제에 없다.

모델 카드는 별도의 reference-sheet generator로 시트를 준비하라고 설명하지만, 확인한 생성 workflow가 그 과정을 자동 실행하지는 않는다. 따라서 Ingredients 가중치를 로드하는 것과 원본 영상→참조 시트를 자동화하는 것은 별개다. 현재 프로젝트에도 그 자동 전처리는 구현하지 않았다. 실제 원본 증거를 보존하려면 관측된 과거 RGB의 추출·합성 경로를 따로 준비해야 한다. 생성형 도구로 새로운 뒷모습/세부를 만드는 것은 다른 증거 조건이다. 이번에는 workflow 확인과 문서 보완만 했고 신규 실행은 없다.

## 앞서 제안한 RGB 마스킹은 어떻게 주입하나

이것은 Ingredients의 학습된 시트 입력과는 별도인 무학습 진단 제안이었다. 아래는 주입 방식에 대한 설명이며, 최신 사용자 방향에 따른 실행 계획이 아니다.

1. 기존 과거 프레임의 피사체를 수동 영역 지정 또는 segmentation으로 골라 이진 mask `M`을 만든다. 피사체는 1, 그 밖은 0이다. 이번에는 mask를 만들지 않았다.
2. RGB 공간에서 `I_masked = M * I_source + (1 - M) * constant_gray`로 배경을 일정한 색으로 대체한다. 피사체 위치·크기와 canvas 크기를 유지한다.
3. **합성된 RGB 이미지 전체**를 기존 LTX VAE에 독립 인코딩한다. 512×288 단일 이미지는 기존과 같은 144 reference token이다.
4. 기존 `VideoConditionByKeyframeIndex(..., frame_idx=0, strength=1, num_pixel_frames=1)`로 Past 위치의 참조 token을 추가한다. Local·Target noise와 생성 설정은 유지한다. 참조 token은 denoising 중 깨끗한 조건이며 디코딩 전에 제거한다.

`M` 자체를 생성기에 추가 채널로 전달하지 않는다. 투명 alpha나 background token 삭제도 아니다. **회색 배경 역시 VAE와 attention에서 읽히는 이미지 내용**이다. 따라서 모델이 회색 배경을 그대로 재현할 수도 있고, 피사체 자세·구도도 남아 있다. 이 진단은 불필요한 배경 정보를 제외하는 효과만 확인하며, 학습된 identity adapter를 대신하지 않는다.

Attention mask 방식은 RGB를 변경하지 않고 참조 token과 base token 사이 attention 접근을 제한하는 다른 개입이다. 로컬 `ConditioningItemAttentionStrengthWrapper`는 이를 지원하지만 VAE/참조 내부 self-attention을 통한 간접 배경 전달까지 지우지 않는다. 둘을 같은 mask 방식으로 혼용하지 않는다.

## 당시 우선순위 제안 · 최신 원본 유지 방향으로 대체됨

당시에는 단순 배경 가리기를 필수 선행 실험으로 두지 않고 Ingredients의 적용을 먼저 검증하는 편을 제안했다. 공식 지원 안내를 근거로 현재 2.5를 우선 재사용하고 실제 adapter 적용/입력 배치/출력을 검사하자는 안이었다. 이 우선순위는 **배경·물체·사람 모두가 필요한 원본 정보를 보존해야 한다는 최신 사용자 의견에 따라 대체됐다.**

당시의 adapter on/off 및 Local 결합 비교도 미실행이다. 새 전처리·adapter 다운로드·생성·학습을 실행하지 않았다. 공식 모델의 규격·지원 안내와 우리 과제의 기본 경로 선택을 구분하기 위해 이 검토 기록을 보존한다.
