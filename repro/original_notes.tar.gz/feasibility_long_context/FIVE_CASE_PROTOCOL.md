# 서로 다른 FineVideo 원본 5개 · 사전 고정 프로토콜

2026-09-07. 사용자 요청: 사례 5개 선정, 입력 방식 고정, Local/Oracle 10회 생성·평가까지 수행한다. GPU 0–2와 실행 권한을 사용자가 사전에 허용했다.

이 문서는 생성 전 작성했다. 사례·prompt·구간·속성·설정은 `configs/five_case_examples.json`에 고정하고, 준비된 입력과 실행 당시 코드는 SHA256 및 snapshot으로 기록한다. 결과를 보고 사례나 seed를 바꾸지 않는다.

## 질문과 사례 선정

**Local에 없는 외관을 담은 과거 이미지 한 장을 주면, 기존 LTX의 새 target 생성이 개선되는가?** 이전 인터뷰 원본과 다른 FineVideo 원본 5개를 사용한다. 전체 메모리 학습이나 상태·사건·복수 과거 의존성의 검증은 이번 범위가 아니다.

이미 받은 첫 shard 33개 행의 메타데이터에서 후보를 찾고 원본 프레임을 직접 확인했다. 기존 5개 후보에 6개 원본을 추가 추출했으며 네트워크 다운로드는 추가하지 않았다. Local에 대상 외형이 계속 노출되는 요리·발표·공연과 상태 순서 해석이 애매한 도어벨 설치 영상은 제외했다. 무작위 표본이 아니며 assistant의 샘플 프레임 검토이고 사람의 검수 완료가 아니다.

| 사례 | Local → Target | 과거 선택 구간 | 평가할 속성 | 주의점 |
|---|---|---|---|---|
| 보육원 관리자 | 노트북 → 관리자 근접 인터뷰 | 48–51초 | 얼굴·올린 머리·붉은 긴팔과 검은 앞치마 | Oracle은 더 넓은 정면 구도 |
| 로봇 모형 | 머리가 잘린 몸통/다리 → 전시 포즈 | 147–150초 | 각진 머리·작은 금색 얼굴 부분·상단 어깨 형태 | 검은 몸체·흉부는 이미 Local에 있음 |
| 교실 학생 | 교사 정면/학생 뒷부분 → 학생 정면 | 107–110초 | 얼굴·앞쪽 곱슬머리·안쪽 밝은 셔츠 | 후드 색은 Local에 있음; 비슷한 역방향 촬영; 간격 약 15초 |
| 캠퍼 밴 | 운전석 내부 → 움직이는 차량 외부 | 138–141초 | 차체·측면 줄무늬·전면과 창문 배치 | GT 앞부분 cross-dissolve; 뒤에 다른 밴도 있음 |
| 보존 작업자 | 손·도구 → 작업자 얼굴 근접 | 45.5–48.5초 | 얼굴·짧은 회색 머리·안경 | 회색 소매는 Local에 있음; GT 끝은 아래로 pan |

모든 조건에 동일한 역할/카메라 전환 prompt를 준다. 정답 색·옷·안경 등의 평가 속성은 prompt에 넣지 않는다. 전환 방향은 사람이 알려주므로 자연스러운 cut 예측이나 검색 대상을 스스로 고르는 능력을 평가하지 않는다. 전체 FineVideo 설명·Q&A는 conditioning에 넣지 않는다.

## 실제 입력과 통제

- 두 조건: Local-only / Local+Oracle. 각 사례 seed 42, 신규 10회. 신규 Random 및 추가 seed 없음.
- Local 원본 2초를 24 FPS 48프레임으로 추출하고 첫 프레임을 앞에 복제하여 49프레임 VAE encode: 7×9×16 = 1,008개의 고정 latent token.
- 과거 3초 구간은 선택/검토용이다. 그 구간의 **36번 프레임 한 장만** 독립적으로 VAE encode: 1×9×16 = **144 token**. 실제 전처리 RGB는 cache의 `oracle_image.png`로 보존한다. 3초 영상 latent는 입력하지 않는다.
- `VideoConditionByKeyframeIndex(frame_idx=0, num_pixel_frames=1, strength=1)`로 참조를 append한다. 시간 범위 `[0, 1/24)`; 기존 N1 성공 조건과 동일하다. IC-LoRA, `VideoConditionByReferenceLatent`, 새 학습은 사용하지 않는다.
- Local은 denoising 중 고정 조건이다. 디코딩 때만 앞에 붙이는 것이 아니다. Base AV 좌표는 두 조건 모두 +97/24초 이동한다. Local `[97/24,146/24)`, Target `[146/24,218/24)`. 이 좌표는 원본 증거와 target 사이의 실제 시간 간격을 재현하는 것이 아니다.
- Base 121프레임에 대응하는 2,304 video token 중 1,296개만 생성한다. 참조는 decoder 전에 제거되고, 디코딩 결과 `[49,121)`의 72프레임만 target으로 평가한다.
- 해상도 512×288, 24 FPS, 3초, LTX 2.5 22B distilled BF16, 기존 8-step Euler ancestral, CFG/STG 없음, eta=1, s_noise=1. 기존 로컬 checkpoint와 `uv run --no-sync`를 재사용한다.
- Prompt·local cache·base 위치·초기 noise·7회 ancestral target noise·decoder seed를 조건 쌍에서 동일하게 고정한다. 실제 noise와 위치·고정 참조 tensor를 저장하고 검사한다. GT 영상은 생성 runner에서 열지 않는다.
- 원본 추출 시 `[start,end)` 경계와 실제 source PTS를 기록하여 Local/GT 혼입을 검사한다. 원본 내 간격은 별도 기록한다.

## 생성 전에 정한 평가

주평가는 각 사례의 위 속성과 새 view/행동의 양립 여부다. Local 대비 Oracle의 개선/부분 개선/불명확/악화를 기록하고, 참조 구도 복사와 동작 실패를 별도로 표시한다. 같은 인물 여부는 시각적 유사성 관찰이며 신원 확인이나 정량 정확도로 부르지 않는다. 5개·1 seed의 결과로 통계적 유의성이나 일반화 성공률을 주장하지 않는다.

보조 지표는 기존과 같은 DINOv2 ViT-B/14 normalized CLS cosine이다. 새 target의 frame `[0,6,13,19,26,32,39,45,52,58,65,71]`을 GT와 시간별 비교하고 평균한다. 1초 이후의 기존 8개 샘플 평균도 공통 보조값으로 제공한다. 이 점수는 인물 정확도가 아니며 구도·배경·전환 지연을 함께 반영한다. GT가 끝에 얼굴에서 벗어나는 사례에서는 특히 주의한다.

모든 72 target 프레임의 연속 pixel 변화와 실제 참조 이미지에 대한 feature/pixel 유사도를 기록한다. 이 수치만으로 정지·복사를 판정하지 않고 동기화 비교와 프레임을 확인한다. 로봇 GT 자체가 거의 정지인 구간에는 같은 motion 기준을 강제하지 않는다.

산출물: 사례별 Local·실제 Oracle 이미지·평가용 GT, GT/Local/Oracle 동기화 영상, 정성 관찰, CSV, 설정·입력·noise·좌표·고정 latent·영상 전체 디코딩 감사, 한국어 HTML 및 문서. 결과가 부정적이거나 섞여도 모두 공개한다.

## 실행

기준 디렉터리: `/mnt/minu/minseok/LTX-2/longcond`.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/prepare_five_cases.py
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_batch.py --phase prepare
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_batch.py --phase generate
```

추출 스크립트는 기존 입력을 덮어쓰지 않는다. Batch는 GPU당 한 프로세스씩 배치하며 cache 준비와 각 Local/Oracle 생성은 서로 다른 새 프로세스에서 실행한다.
