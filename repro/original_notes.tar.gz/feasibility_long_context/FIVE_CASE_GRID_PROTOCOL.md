# 5개 사례의 참조 형식 × 시간 위치 2×2 · 사전 설계

2026-09-07. 사용자는 막힌 두 사례만 시간 이동하는 제안 대신 **5개 사례 모두에서 이전과 같은 2×2 비교**를 먼저 진행하고, 그 뒤 attention 및 prompt 제어를 검토하자고 요청했다. 아래 비교를 진행하며 기존 prompt나 Local 조건은 바꾸지 않는다.

| 참조 형식 | 과거 위치 | 생성 시작 위치 |
|---|---|---|
| 이미지 한 장 | 기존 5회 재사용 | 신규 5회 |
| 과거 영상 | 신규 5회 | 신규 5회 |

기본 seed는 앞선 합의대로 **42 하나**다. 총 Oracle 20조건 중 기존 5개를 재사용하고 **신규 15회**를 생성한다. Local-only 5개도 비교 기준으로 재사용하므로 보고서에는 25개 생성 결과를 표시한다. 재사용 전 설정·실제 noise·좌표·입력·코드·영상 hash를 확인한다. 신규 Random·추가 seed·attention 계측·prompt 변경·학습은 이번 묶음에 넣지 않는다.

## 동일하게 유지하는 것

기존 `configs/five_case_examples.json`의 원본 5개, 구간, prompt, 평가 속성과 입력 cache를 바꾸지 않는다. Local 48프레임을 첫 장 복제로 49프레임 VAE encode한 1,008 token, Target 72프레임, 512×288, 24 FPS, 기존 LTX 2.5 distilled BF16 8 step, Euler ancestral, eta=1, s_noise=1, CFG/STG 없음, decoder seed 20042다.

Base video 2,304 token과 AV 위치의 +97/24초 이동, 생성할 1,296 token의 초기 noise 및 7회 ancestral noise는 모든 조건에서 같다. Actual tensor를 저장하고 검증한다. 조건별 denoising과 decoder는 각각 새 프로세스로 실행하며 GPU 0–2만 사용한다. IC-LoRA·새 모델·재다운로드·전체 메모리 학습은 없다.

## 조작하는 두 축

이미지는 기존 과거 3초 구간의 36번 RGB frame을 **독립적으로** encode한 144 token이다. 영상은 **같은 3초 구간 전체 72프레임** 앞에 첫 장을 복제해 73프레임으로 독립 encode한 10×9×16=1,440 token이다. 기존 이미지·Local·prompt cache는 유지하고 영상 latent만 별도 cache에 추가한다. 영상의 한 latent slice를 이미지 조건으로 취급하지 않는다.

모든 참조는 `VideoConditionByKeyframeIndex(frame_idx=0, strength=1)`로 append하고, 기존 `ShiftReferenceTime`으로 **추가 참조의 시간 좌표만** 이동한다. 공간 좌표·참조 내용·token 수·clean latent·mask·base AV 좌표는 같은 형식의 past/target 쌍에서 유지된다. 참조는 decoder 전에 제거한다.

| 조건 | token 수 | 참조 모델 시간 |
|---|---:|---|
| Image / Past | 144 | `[0,1/24)`초 |
| Image / Target | 144 | `[146/24,147/24)`초 |
| Video / Past | 1,440 | `[0,73/24)`초 |
| Video / Target | 1,440 | `[146/24,219/24)`초 |

Local `[97/24,146/24)`, Target `[146/24,218/24)`는 네 조건에서 같다. 영상의 마지막 끝점이 Target보다 1/24초 뒤인 것은 앞선 실험과 같은 causal padding 규칙 때문이다. 위치는 영상의 causal time grid 전체를 평행 이동하며 `frame_idx=146`에서 grid를 새로 만들지 않는다.

**Target 위치에 둬도 참조 RGB는 진짜 과거다. GT나 미래 영상은 입력하지 않는다.** 원본의 약 15–218초 간격과 모델 좌표의 간격은 별개다.

이미지/영상 비교에서는 정보량·token 수·temporal VAE 표현이 함께 달라진다. 따라서 이를 시간 정보만의 효과로 해석하지 않는다. 영상에는 원래 선택 구간의 다른 자세·부분 시점·컷도 포함된다. 특히 보존 작업자는 선택 영상 초반의 손 근접과 후반 작업대 컷이 함께 들어가며, 단일 이미지는 후반 정면 한 장이었다. 이 차이를 입력 페이지에서 보여준다.

## 사전 평가와 해석

각 사례의 2×2와 Local 기준을 함께 본다. 평가할 속성은 기존 5개와 같다. (1) 필요한 시점으로 전환하는지, (2) Local에 없던 속성이 드러나는지, (3) 움직임과 양립하는지, (4) 참조 구도·배경·동작을 재현하는 정도를 분리해 기록한다.

DINOv2 ViT-B/14는 기존과 같은 전체 프레임 보조 유사도다. Target frame `[0,6,13,19,26,32,39,45,52,58,65,71]`의 GT aligned cosine과 1초 이후 공통 8개 샘플 평균을 계산한다. 기존 10개 기준 결과의 재평가가 일치하는지 확인한다. DINO를 인물/물체 정확도로 부르거나 점수 증감만으로 외관 전달을 판정하지 않는다.

사례별로 이미지의 target−past, 영상의 target−past와 두 위치 효과의 차이(상호작용 contrast)를 제공한다. 이는 한 seed의 기술 통계이며 유의성 검정이 아니다. 원본 5개·prompt로 지시한 전환·외관 과제라는 한계도 유지한다. 실패나 애매한 결과를 포함한 모든 조건을 공개한다.

2×2 완료 후에야 attention과 prompt 제어의 우선순위를 정한다. 이번 실행 중 점수를 보고 추가 prompt/seed/조건을 자동 도입하지 않는다.

## 산출물과 실행 기준

새 코드는 `prepare_five_case_video.py`, `run_five_case_grid.py`, `run_five_case_grid_batch.py`에 격리한다. 결과는 `outputs/five_*/reference_grid_seed42/`, 보고서는 `reports/five_case_grid/seed42/`에 기록한다. 기존 generation runner·입력·출력·CSV는 보존한다.

기준 디렉터리 `/mnt/minu/minseok/LTX-2/longcond`:

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_grid_batch.py --phase prepare
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_grid_batch.py --phase generate
```
