# 5개 사례의 이미지/영상 × 시간 위치 2×2 결과

2026-09-07. **5개 전체의 2×2 비교를 완료했다.** 기존 Image/Past 5개와 Local 기준 5개를 재사용하고, Image/Target·Video/Past·Video/Target 15개를 새로 생성했다. 모두 seed 42이며 prompt·Local·실제 noise·모델 설정을 유지했다.

**로봇·학생·차량은 두 Past 조건에서 막혔지만 두 Target 조건에서는 필요한 외관이 드러났다. 관리자·보존 작업자는 Video/Past에서도 작동했다.** 다만 생성 위치에서 과거의 구도·손동작·주차 장소·컷·자막까지 재현되는 경향도 확인했다. 참조를 이용할 수 있는가와 새 장면/동작에 맞게 이용하는가는 다른 문제다.

[실제 입력과 2×2 동기화 영상](reports/five_case_grid/seed42/index.html) · [사전 설계](FIVE_CASE_GRID_PROTOCOL.md) · [25조건 CSV](reports/five_case_grid/seed42/results.csv) · [정성 기록](reports/five_case_grid/seed42/review.json) · [실제 입력·출력 감사](reports/five_case_grid/seed42/artifact_verification.json)

## 비교와 통제

사용자는 막힌 두 사례만 시간 이동하는 제안 대신 5개 모두의 2×2를 먼저 진행하자고 수정했다. 기존 원본·구간·이미지·prompt를 바꾸지 않았다. Attention 측정, prompt 변경, 신규 Random/seed, 학습은 이번에 하지 않았다.

이미지는 과거 3초 구간의 36번 RGB frame을 독립 VAE 인코딩한 **144 token**이다. 영상은 같은 구간 전체 72프레임 앞에 첫 장을 복제한 73프레임을 독립 VAE 인코딩한 **1,440 token**이다. 기존 이미지·Local·prompt cache는 유지하고 영상 cache만 추가했다.

같은 참조 형식의 Past/Target 쌍에서는 latent 내용·token 수·공간 좌표를 고정하고 추가 참조의 시간 좌표만 +146/24초 옮겼다. Image의 시간은 `[0,1/24)` → `[146/24,147/24)`, Video는 `[0,73/24)` → `[146/24,219/24)`다. 영상의 causal grid를 그대로 평행 이동했다.

Base AV 좌표, Local `[97/24,146/24)`, 생성 Target `[146/24,218/24)`는 동일하다. Target 좌표의 참조도 **진짜 과거 RGB**이며 GT는 생성 runner에서 열지 않았다. Local 1,008 token만 고정하고 1,296개 Target token을 생성한다. 참조는 append되어 attention에 참여한 뒤 decoder 전에 제거되며, Target latent를 참조로 직접 고정한 것이 아니다.

모든 조건은 512×288·24 FPS·Target 3초·기존 LTX 2.5 distilled BF16 8-step Euler ancestral·CFG/STG 없음·IC-LoRA 없음이다. 조건별 새 denoising 프로세스와 별도 새 decoder 프로세스를 사용했다.

## 전체 프레임 DINO

새 Target의 공통 12개 시점을 GT와 비교한 보조 유사도다. 인물/물체 정확도, 주행 성공률, 통계적 유의성이 아니다.

| 사례 | Local | Image/Past | Image/Target | Video/Past | Video/Target |
|---|---:|---:|---:|---:|---:|
| 보육원 관리자 | 0.2008 | 0.3915 | 0.4547 | 0.4193 | 0.5150 |
| 로봇 머리 | 0.8736 | 0.8678 | 0.8251 | 0.8770 | 0.7724 |
| 교실 학생 | 0.3772 | 0.3570 | 0.6916 | 0.3951 | 0.6496 |
| 차량 외관 | 0.2498 | 0.2422 | 0.6468 | 0.2434 | 0.6377 |
| 보존 작업자 | 0.3856 | 0.2921 | 0.3716 | 0.3065 | 0.2291 |
| 이 5개의 단순 평균 | 0.4174 | 0.4301 | 0.5980 | 0.4483 | 0.5608 |

평균은 선택된 5개의 기술 통계다. 로봇처럼 필요한 머리가 없어도 몸체·배경 때문에 점수가 높은 사례가 있으므로 평균을 feasibility 성공 여부로 대체하지 않는다. 전체 데이터셋으로 일반화하지 않는다.

### 시간 위치 효과와 상호작용

| 사례 | Image Target−Past | Video Target−Past | Video 위치 효과−Image 위치 효과 |
|---|---:|---:|---:|
| 관리자 | +0.0632 | +0.0957 | +0.0325 |
| 로봇 | −0.0427 | −0.1045 | −0.0618 |
| 학생 | +0.3347 | +0.2544 | −0.0802 |
| 차량 | +0.4046 | +0.3942 | −0.0103 |
| 보존 작업자 | +0.0795 | −0.0774 | −0.1569 |

보존 작업자는 이미지와 영상에서 DINO 위치 효과의 부호가 다르다. 영상 참조 초반에 손 근접, 후반에 작업대 컷이 있어 Video/Target이 그 순서를 따라가기 때문이다. 출력과 입력에 근거한 해석이며 attention 내부 기전은 아직 측정하지 않았다.

1초 이후 공통 8개 샘플의 결과도 `summary.json`과 HTML에 제공했다. 학생은 Image 0.3406→0.6357 / Video 0.3743→0.6315, 차량은 Image 0.1126→0.7886 / Video 0.1103→0.7803이므로 단순한 초반 전환 지연만으로 차이를 설명할 수 없다. 관리자에서는 전체 점수의 위치 차이가 1초 이후 Image +0.0443 / Video +0.0458로 줄어 전환 시점의 영향도 있다. 보존 작업자는 Image의 전체 상승과 달리 1초 이후는 0.3946→0.3722로 낮다.

## 사례별 정성 해석

Assistant가 5개 전체의 Target 0/0.33/0.67/1/1.67/2.33/2.96초 프레임을 검토했고, 차량·보존 작업자는 1.33초의 더 큰 비교도 확인했다. 사람이 전체 영상을 재생하며 검수하거나 blind 평가한 결과는 아니다.

### 관리자: 영상 과거 조건도 작동한다

Image/Past와 Video/Past 모두 약 0.33초에 노트북과 인터뷰가 겹치고, 0.67초부터 올린 머리·붉은 긴팔·검은 앞치마가 보인다. Image/Target은 0.33초부터, Video/Target은 첫 샘플부터 인터뷰를 보여준다. 이후 손·고개·입의 움직임이 있다.

네 조건 모두 과거의 보육 공간과 중간 구도를 따른다. GT는 측면 근접이다. 따라서 영상 과거 조건이 작동한다는 관찰과 새로운 구도 활용의 성공을 구분한다. Local-only의 식물 재배장처럼 보이는 장면에는 `nursery` 의미 모호성도 영향을 주었을 수 있다.

### 로봇: DINO는 내려가지만 머리가 드러난다

두 Past 조건은 머리가 잘린 큰 몸통·다리 구도를 지속한다. 두 Target 조건은 각진 머리와 작은 금색 얼굴 부분을 첫 샘플부터 보여준다.

Image/Target은 처음에 조작자의 손도 나타나지만 약 1초 이후 샘플에서는 거의 사라진다. Video/Target은 손으로 모형을 만지는 과거 동작·근접 구도를 더 강하게 따른다. GT의 넓은 전시 포즈를 제대로 생성한 것은 아니다. 낮아진 DINO를 머리 정보 미사용으로 해석하면 잘못이다.

### 학생: 위치 이동으로 역방향 시점이 열린다

두 Past 조건은 교사 정면을 유지하고 학생 얼굴이 보이지 않는다. Image/Target은 첫 샘플부터, Video/Target은 첫 샘플의 혼합 이후 0.33초부터 학생 정면을 보여준다. 과거 얼굴·곱슬머리·밝은 안쪽 셔츠가 전달된다.

두 Target 모두 참조의 정면 구도를 강하게 따르고, Image/Target은 움직임이 작다. GT 후반의 돌아서는 행동은 나오지 않지만 공통 prompt가 그 정확한 행동을 지시하지는 않았다. 참조 활용의 회복과 새로운 동작 일반화를 같은 성공으로 세지 않는다.

### 차량: 외관 활용과 장면 통합의 차이

두 Past는 운전석 내부 주행을 지속한다. 두 Target은 차체·측면 줄무늬·전면과 창문 배치를 드러낸다.

Image/Target은 일부 샘플에서 Local의 운전석·도로 잔상과 삽입 영상 같은 경계를 남긴다. Video/Target에서는 이 잔상이 덜 보이지만 과거 주차 장소·카메라 이동을 강하게 재현한다. 카메라 변화와 차량 자체 주행을 구별해야 하며, prompt가 요청한 "진입로를 천천히 주행하는 밴"을 성공했다고 볼 근거는 부족하다. GT 장소까지 prompt가 지정한 것은 아니므로 장소 차이 자체를 지시 위반으로 세지는 않는다.

### 보존 작업자: 참조의 컷과 자막까지 따라감

두 Past 모두 뒤늦게 회색 머리·안경의 작업자를 넓은 작업대 구도에 생성한다. Video/Past도 작동한다. Image/Target은 첫 샘플부터 작업자를 보여준다.

Video/Target은 첫 약 1초에 과거의 책/손 근접과 자막을 보여주고, 이후 과거 작업대 인물·자막을 재현한다. GT는 처음부터 작업자 측면 근접이다. **Video/Target의 낮은 GT 유사도는 참조를 쓰지 않은 결과보다 참조의 장면 순서까지 따라간 결과에 가깝다.** Pixel 단위 동일 복사를 주장하지는 않지만, 과거 장면·컷·자막 재현은 샘플에서 직접 보인다.

## 이번에 수정할 결론

1. **Video/Past가 일반적으로 실패하는 것은 아니다.** 이전 공사 인터뷰에서는 실패했지만 관리자·보존 작업자에서는 외관이 전달됐다. 1,440 token 자체를 항상 나쁜 조건으로 볼 수 없다.
2. **로봇·학생·차량의 Past 실패는 이미지/영상 양쪽에서 나타나고, 시간 이동 후 필요한 외관 노출이 회복됐다.** 앞선 두 사례만의 제안보다 5개 전체 2×2가 이런 공통점과 예외를 더 명확히 보여줬다.
3. **시간 위치 이동은 새 장면 제어와 동의어가 아니다.** 참조 구도·동작·자막까지 강해지는 경우가 있다. Image/Video 축에는 내용·token 수·temporal VAE 표현이 함께 바뀌므로 순수한 동작 정보 효과라고 해석하지 않는다.
4. **DINO와 외관 판단을 계속 분리한다.** 로봇은 점수가 내려가도 필요한 머리가 나타나며, 보존 작업자는 참조를 강하게 써서 GT와 멀어질 수 있다.

현재 결론은 **선택한 과거 증거를 기존 LTX가 활용할 수 있다는 근거가 강화됐고, 새 view/동작과의 결합 및 참조 재현 억제가 다음 과제**라는 것이다. 일반적인 장거리 기억, 상태·사건 추론, 메모리의 두 역할은 아직 검증하지 않았다.

## 검증·실행 기록

- 기존 시간 이동/causal grid 테스트 2개가 통과했다. 실제 신규 pipeline에서는 GPU에서 생성된 base 좌표가 재사용 Image/Past와 정확히 같음을 확인했다.
- 재사용 10개 결과의 source·cache·모델 기록·code snapshot·noise·좌표·고정 latent·MP4를 재검사했고 이전 감사 JSON과 동일했다. 기존 DINO 전체/1초 이후 **20개 값의 재평가 차이는 모두 0**이었다.
- 신규 15개에서 재사용 기준과 **49개 공통 설정**을 대조했다. 실제 참조 clean token은 해당 독립 이미지/영상 cache와 같았다. 위치는 기존 image/video past grid의 정확한 평행 이동이고 base AV·공간 좌표는 유지됐다.
- 실제 초기 및 7회 step Target noise는 전체 25조건에서 동일했다. 8 step과 최종 고정 오차는 모두 0이었다. 생성 latent는 Local prefix를 보존하고 참조를 제거한 16개 latent frame만 포함했다.
- Target **1,800프레임**, Local 결합·전체 decoded 영상까지 **7,825프레임**을 전체 디코딩하고 SHA256·512×288·24 FPS PTS를 검사했다. 영상 입력은 원본 PTS·전처리 RGB hash·cache hash로 확인했다.
- 신규 15회는 첫 시도에 모두 성공했다. 모델 로딩·분리 decoder 포함 20.92–24.22초/회, 부모 allocator peak 최대 약 39.144 GiB, 별도 decoder 최대 약 3.308 GiB다. 두 프로세스의 동시 device 점유량을 합산 계측한 값은 아니다.

정식 신규 생성은 기존 35회에 15회를 더해 **총 50회**다. 재사용 결과와 input encoding은 신규 생성으로 중복 집계하지 않는다. 이번 묶음의 중단/재시도 생성은 없다.

## 다음 순서

**후속 방향 수정:** 아래는 2×2 직후의 제안이다. 이후 사용자는 전체 장면의 Target 위치 주입을 기본에서 제외했고, 09-08에는 배경·물체·사람 모두가 필요한 정보일 수 있으므로 의미 영역을 제거하는 전처리도 기본으로 두지 않도록 했다. 최신 제안은 [원본 전체 Past 참조를 유지한 5사례 × 3종 prompt 비교](PROMPT_CONTROL_PROPOSAL.md)이며 [NEXT_STAGE.md](NEXT_STAGE.md)를 따른다. 신규 생성·prompt 비교·adapter 적용은 아직 하지 않았다.

사용자 요청대로 이제 attention과 prompt 제어를 검토할 근거가 마련됐다. **추가 attention 계측·prompt 비교는 아직 실행하지 않았다.** [NEXT_STAGE.md](NEXT_STAGE.md)에 결과에 맞춰 구체화했다.

- Attention은 학생의 Past/Target처럼 출력 경로가 달라지는 조건과 보존 작업자의 Image/Video Target처럼 과거 재현 양상이 다른 조건을 우선 관찰할 수 있다. 전체 평균만 보지 않고 generated query의 시간·공간·layer·step에 따른 Local/참조 비중과 token 수 차이를 구분한다. 관찰 backend가 원래 생성 결과를 바꾸지 않는지 먼저 확인해야 한다.
- Prompt 제어는 로봇의 "손 없는 전시 구도"와 차량의 "고정 외부 카메라에서 실제 주행"처럼 이번에 미흡했던 목표를 정답 외관 누출 없이 명확히 하는 방향이다. 같은 조건에서 prompt만 바꾸고, 과거 참조의 외관 유지와 새로운 제어 준수를 따로 본다.

메모리 학습을 시작하거나 메모리를 검색 인덱스로 축소하지 않는다. **직접 전역 생성 조건과 원본 증거 검색**이라는 두 역할은 이후 학습·비교에서 각각 검증한다.

## 재현

기준 디렉터리 `/mnt/minu/minseok/LTX-2/longcond`. 최초 입력 영상 cache 생성은 [사전 설계](FIVE_CASE_GRID_PROTOCOL.md)에 있다.

```bash
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_grid_batch.py --phase generate
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/evaluate_five_case_grid.py --gpu 2
uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/make_five_case_grid_report.py
```

실행 명령·로그·코드 snapshot은 `outputs/five_case_grid_batch/`, 신규 생성은 `outputs/five_*/reference_grid_seed42/`, 별도 영상 cache는 `outputs/five_*/five_case_video_inputs_512x288/`다. CSV·features·정성 기록·감사·비교 영상은 `reports/five_case_grid/seed42/`에 있다. 이전 runner·metadata·cache·CSV·실험 결과는 보존했다.
