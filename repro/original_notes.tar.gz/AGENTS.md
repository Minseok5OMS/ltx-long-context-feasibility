# longcond 작업 지침

이 폴더는 **Addressable Global Memory for Long-Context Video Generation** 연구 작업 공간이다.
새 대화에서도 아래 목표와 현재 단계를 먼저 파악하고 작업한다.
사용자와의 소통 및 작성 문서는 **한국어 또는 영어**를 사용한다. 기본 설명 언어는 한국어다.

## 먼저 읽을 문서

- [RESEARCH_CONTEXT.md](RESEARCH_CONTEXT.md): 사용자와 논의한 핵심 목표, 명확해진 의도, 현재 상태, 다음 단계.
- [연구 개념 원문](long_context_video_generation_research_concept.txt): 전체 연구 문제와 제안 구조. 연구 설계를 검토하거나 구현할 때 읽는다.
- [Feasibility 지시문 원문](ltx_long_context_feasibility_instructions.txt): Stage 1의 데이터·실험·산출물 명세. 실험 구현 전에 읽는다.

현재 사용자의 명시적 요청과 수정 사항을 우선한다. 원문의 전체 산출물 목록을 모든 대화에서 즉시 전부 실행하라는 지시로 해석하지 않는다. 단계별 작업 요청은 그 범위에서 끝까지 수행한다.

## 반드시 유지할 연구 목표

긴 원본 영상의 **압축된 전역 메모리**를 학습하고, 생성 시 메모리에 attention하여 두 가지 도움을 받는다.

1. **직접 생성 조건:** 전체 영상에 걸친 문맥·관계·사건의 흐름·상태 정보를 생성기에 전달한다.
2. **원본 증거 검색:** 필요한 원본 구간의 위치를 찾고, 해당 LTX VAE latent를 가져와 세부 시각 정보를 보충한다.

메모리를 단순한 검색 인덱스로 축소하지 않는다. 직접 검색이 잘 작동하더라도 전역 메모리의 직접 생성 기여는 별도로 검증해야 한다.
최종 과제는 재등장·외관 유지뿐 아니라 상태·사건·여러 과거 구간의 의존성을 포함한다. 초기의 색상/재등장 예시는 입력 경로를 확인하는 진단이다.

사용자는 과거 프레임의 **배경·물체·사람 모두에서 필요한 정보를 활용**하려 한다. 피사체 추출·배경 제거·참조 시트로 의미 정보를 사전 제한하는 방식을 기본 경로로 두지 않는다. 기존 resize/VAE 전처리는 유지하되, 필요한 정보는 생성 요청·Local·전역 문맥에 따라 선택하도록 한다. 배경 유지 자체를 실패로 평가하지 않는다.

## 단계와 실행 원칙

- 최신 단계 전환 논의: 사용자는 32초 비교의 품질·계산 이점을 확인했다고 보고 **feasibility를 마무리하고 메모리 만드는 단계로 전환**하자고 제안했다. Assistant는 Stage 1 종료와 Stage 2 초기 설계를 기록했다. `feasibility_long_context/MEMORY_STAGE2_PLAN.md`를 확인한다. 현재는 설계 작성 단계이며 memory 구현·특징 추출·학습 실행은 아직 없다. 후속 학습의 입력 영상 길이 확대는 사용자 방향이고, 구체적인 60/120초·memory token 예산·adapter 구성은 동결 전 제안이다. 아래 Stage 1의 학습 금지는 해당 완료 단계의 범위이며, 이후 사용자가 요청하는 Stage 2 구현을 일괄 금지하는 뜻으로 해석하지 않는다.
- 최신 GPU 허용 범위는 사용자 추가 지시에 따라 **0–4번**이다. 아래 과거 실험의 0–2 기록은 당시 범위다. 완료한 long-input 25조건은 비용 비교를 위해 모두 GPU 0에서 완료했으며, 동결한 실행 스크립트/설정은 소급 변경하지 않는다. 이후 새 실행·평가는 0–4 안에서 계획한다.
- 현재 진행 상태는 `RESEARCH_CONTEXT.md`에서 확인하고, 파일·로그·결과로 검증한다. 설계 제안과 실행 완료를 구분한다.
- 최신 사용자의 “진행해” 요청으로 **연속 과거 32초 대 선택 chunk의 5사례 × 5조건, 신규 25회**를 완료했다. 정식 누적 **120회**다. 구간을 생성 전에 재검토·동결했고 관리자 원본은 다른 직원 T=109.8430667, 로봇은 T=260으로 변경했다. 나머지 3개는 T 유지/Oracle 변경이다. 학생 O/U는 8/9 index 겹침, 로봇 원본 후속은 display GT가 아니므로 GT DINO 제외다. O는 직원·로봇·차량 외관을 더 잘 드러냈고 로봇은 새 display와 결합했다. 학생은 공동 실패, 보존 작업자는 얼굴 일부만 노출, 직원·차량은 참조 구도 재현이 남는다. N/F 대비 denoising 4.66×/4.70×, 전체 peak allocated 약 7% 감소, 상주 baseline 대비 증가분 약 76% 감소다. 25조건 입력/좌표/noise/고정 latent와 7,825프레임 검증을 통과했다. `feasibility_long_context/LONG_INPUT_RESULT.md`, `reports/long_input/`(feasibility 하위), 동결 `configs/long_input_cases.json`을 확인한다. 사전 protocol의 미실행/95회는 당시 기록이다. 다음 Stage 2 설계는 미착수 후보이며 attention/offset/추가 seed/학습을 자동 시작하지 않는다.
- Stage 1은 기존 LTX에서 과거 Oracle 증거의 효용을 확인한다. 초기 Local/Random/Oracle 비교는 완료했으며, 최신 사용자 의견에 따라 신규 본 비교는 **5개 사례의 Local-only / Local+Oracle** 중심으로 줄였다. 신규 Random·20개 확대는 필수가 아니다. 5개 Local/Oracle 비교 후 사용자는 5개 전체에서 **이미지/영상 × 과거/생성 시작 위치 2×2**를 먼저 진행하라고 수정했다. seed 42로 기존 Image/Past 및 Local을 재사용하고 신규 15회를 완료했다. 이후 P1/P2/P3 prompt 제어 비교 45회도 완료했으며 attention 측정은 미실행이다.
- 데이터는 사용자가 선택한 **FineVideo (`HuggingFaceFV/finevideo`)**를 사용한다. 초기 후보 5개/진단 입력 3개에 이어 캐시 shard에서 추가 원본 6개를 추출하고 다른 원본 5개의 Local/Oracle 비교를 완료했다. 구체적인 구간과 한계는 `feasibility_long_context/DATA_REVIEW.md`, `feasibility_long_context/FIVE_CASE_PROTOCOL.md`, `feasibility_long_context/FIVE_CASE_RESULT.md`에 있다. 진단용 사례를 장거리 벤치마크 검증 완료로 간주하지 않는다.
- 5개 2×2 후 사용자는 전체 과거 장면의 Target 좌표 주입과 피사체 추출/배경 제거/시트에 의한 의미 제한을 기본에서 제외했다. 이어 P1(출력 지시), P2(P1+연속성), P3(P2+참조 역할)를 추가하고 실행하도록 요청했다. **5사례 × Local/Image-Past/Video-Past × 3대안의 신규 45회를 완료**했고 기존 P0 15개와 60개를 비교했다. 당시 정식 누적은 **95회**였다. 로봇/보존 작업자는 외관과 새 구도 결합, 차량 Video/Past P2/P3는 외부 전환이 관찰됐으나 주행 성공은 불확실하다. 학생은 계속 실패했고 관리자 Video/Past는 새 prompt에서 오히려 노트북을 유지했다. `feasibility_long_context/PROMPT_CONTROL_RESULT.md`, `feasibility_long_context/reports/five_case_prompt/seed42/`, 고정 설정 `feasibility_long_context/configs/five_case_prompt.json`을 확인한다. 다음 두 쌍의 attention/입력 경로 진단은 `NEXT_STAGE.md`의 미실행 제안이며 새 실험·adapter·학습을 자동 시작하지 않는다.
- Stage 1에서는 새로운 모델 학습, 전체 메모리/검색 네트워크, V-JEPA2/VLM 특징 추출, AR 변환, VQA 구현을 시작하지 않는다. 메모리 학습은 후속 단계의 범위다.
- 현재 설치된 LTX 코드와 로컬 체크포인트를 우선 재사용한다. 실제 API를 확인하고, 불필요한 모델 재다운로드와 upstream 변경을 피한다.
- 사용자가 GPU 0–2번 사용을 허용했고 `uv run` 실행을 제안했다. 기존 환경을 보존하는 `uv run --no-sync`를 사용하며, 각 프로세스의 GPU 노출을 허용 범위 안으로 제한한다. 요리 Local-only 1회, 초기 참조 비교 9회, 후속 시간 위치 비교의 신규 생성 10회를 완료했다. 후속 비교는 기존 2회 재사용을 포함한 12조건·3 seed다. 이어서 seed 42로 B·C·D 진단 3회(A·E 재사용 포함 5조건), 이미지 반복수 2·4 진단 2회(1·10회 재사용 포함 4조건)를 완료했다. 이후 서로 다른 FineVideo 원본 5개의 이미지/past Local/Oracle 10회를 완료해 그때 정식 생성은 35회였고, 이후 5개 전체 2×2의 신규 15회를 완료해 당시 총 50회였고, 이어 prompt 비교 45회를 더해 당시 총 95회였다. 두 Target 조건에서 로봇·학생·차량의 필요한 외관 노출이 회복됐고, 관리자·보존 작업자는 Video/Past에서도 작동했다. 참조 구도·동작·컷/자막 재현은 남아 있다. 2×2 결과는 `feasibility_long_context/FIVE_CASE_GRID_RESULT.md`, 최신 prompt 결과는 `feasibility_long_context/PROMPT_CONTROL_RESULT.md`에 있다. 앞선 Image/Past 비교에서는 인물 2개의 외관 전달과 참조 구도 영향이 관찰됐고, 나머지 3개는 필요한 시점 전환에 실패했다. 안정적 범용 활용이나 상태·사건 검증 완료가 아니다. 1·2·4회는 외형 전달, 10회는 3초 동안 공사 장면 지속이며 정확한 실패 임계점과 attention 기전은 미검증이다. 조건별 새 프로세스를 사용한다. 신규 5개에서는 Oracle denoising 후 CUDA decoder 오류가 나서 decoder도 별도 새 프로세스로 분리했다. 10조건을 같은 방식으로 재실행했고 이전 시도는 보존했다. 같은 Local의 재디코딩 영상과 재실행 6조건의 latent가 정확히 일치함을 확인했다.
- 새 실험 코드는 이 폴더 아래 `feasibility_long_context/` 등에 격리한다. LTX 저장소 루트는 이 폴더의 부모이므로 실행 명령의 기준 디렉터리를 명시한다.
- 비교 조건의 prompt, target 초기 noise, seed, 모델, 생성 길이, FPS, 해상도, sampler, guidance 등 공통 설정을 통제한다. GT target은 조건 입력에 누출하지 않는다.
- 실행 명령, 설정, 결과 경로, 실제 검증 내용과 한계를 기록한다. 실행하지 않은 실험의 결과를 만들거나 추정으로 완료 처리하지 않는다.

## 후속 대화를 위한 기록

사용자가 목표를 명확히 하거나 실험이 진행되면 `RESEARCH_CONTEXT.md`의 관련 부분을 갱신한다.
사용자가 명시한 의도, 검토 중인 기술 제안, 관찰된 결과를 분리하고, 과거 상태를 최신 사실처럼 남기지 않는다.
