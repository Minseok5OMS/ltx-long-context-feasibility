# 연구 목표와 작업 상태

마지막 갱신: 2026-09-09 (Asia/Seoul)

**최신 작업 순서 · 09-09:** 사용자는 메모리 단계 구현에 앞서 이번 feasibility 결과를 GitHub에 정리하자고 요청했고 repository 생성·clone을 직접 할지 물었다. 우선 기존 LTX 저장소와 분리한 저장소에 연구 질문, 실험별 통제/변경 사항, 120회 결과의 주요 관찰·실패·한계, 품질/비용 비교, 재현 코드·설정과 결과 탐색 경로를 정리하는 방향이다. 아직 새 저장소 URL/clone 경로는 전달되지 않았으며 저장소 생성·이관·push는 실행하지 않았다. Stage 2 초기 설계는 보존하고, 당면 작업은 feasibility 정리다.

**최신 단계 전환 · 사용자 논의:** 사용자는 긴 입력/선택 chunk 비교에서 품질·계산 이점을 확인했다고 보고, **feasibility를 이 정도로 마무리하고 메모리 구축 단계로 넘어가자**고 제안했다. Assistant도 Stage 1 종료와 Stage 2 설계 착수가 타당하다고 판단했다. 후속 학습에서는 과거 영상 길이를 더 늘리는 방향을 검토한다. 이번 턴은 [메모리 첫 설계](feasibility_long_context/MEMORY_STAGE2_PLAN.md)를 작성했으며 신규 feature 추출·메모리 구현·학습 job을 실행한 것은 아니다. 과거의 “Stage 2 미착수 후보”는 당시 상태이고 현재는 **초기 설계 작성** 단계다. 정식 생성 누적 120회 유지.

VRAM 해석: 실제 상주 baseline 약 35.39 GiB에는 transformer와 이미 전송한 text/condition이 포함된다. N/O의 baseline 이후 peak 증가량은 3.624/0.887 GiB로 약 76% 줄지만 전체 allocated는 39.016/36.276 GiB로 약 7% 감소다. VAE의 시간 8·공간 32×32 압축과 inference mode도 비용 구조의 일부다. 32초 Native cache는 `[1,128,97,9,16]` BF16, latent 자체 약 3.41 MiB지만 transformer hidden/attention 비용과는 다르다. 실제 SDPA 내부 kernel은 별도 확인하지 않았다. 학습 시 LTX weight를 고정해도 memory로 생성 loss를 전달하는 gradient 경로가 필요해 현재 추론 VRAM 비율을 그대로 외삽하지 않는다.

Stage 2 설계 제안과 사용자 의도를 구분한다. 사용자 의도는 memory 단계 전환과 후속 입력 길이 확대다. K=128/d=512 후보, resampler·별도 memory cross-attention, 기존 VAE cache로 첫 tensor/gradient 연결 확인, 이후 V-JEPA2/semantic fusion, 32→60→120초 등은 Assistant의 초기 구현 제안이며 아직 실험 설정으로 동결하지 않았다. 압축 메모리의 직접 생성 조건과 원본 증거 선택 두 역할, 배경·물체·사람 전체 정보, 상태·사건·복수 증거 평가를 유지한다.

**최신 실행 권한:** 사용자가 추가로 GPU **0–4번** 사용을 허용했다. 이전 0–2번 제한은 당시 기록이다. Long-input 본 생성 25조건은 공정한 비용 측정을 위해 이미 모두 GPU 0에서 완료했으며, 동결된 실행 설정은 소급 변경하지 않는다. 전체 25조건 감사와 DINO·정성 프레임 평가를 완료했다. 최신 결과는 아래 긴 입력 비교 기록을 따른다.

이 문서는 이 폴더의 다른 작업 대화에서도 연구 목표와 논의 상태를 이어가기 위한 기록이다.
연구 개념 원문과 feasibility 명세는 아래 파일에 있으며, 이 문서는 이후 대화에서 명확해진 의도와 현재 단계를 함께 기록한다.

- [연구 개념 원문](long_context_video_generation_research_concept.txt)
- [Feasibility test 원문](ltx_long_context_feasibility_instructions.txt)

## 사용자가 하려는 연구

**Addressable Global Memory for Long-Context Video Generation**

수십 초~수분 길이의 원본/context 영상, 최근 local context, 선택적인 prompt/action/camera control로부터 짧은 target 영상을 생성한다. 초기 target 길이는 약 3–10초로 유지할 수 있다.

긴 영상의 정보를 고정 개수의 학습된 메모리 토큰으로 압축하고, 원본의 세부 시각 정보는 LTX VAE latent 저장소에 보존한다. 생성기는 전역 메모리에 attention하여 전체 문맥을 이용하고, 필요한 경우 원본 증거를 검색해 보충한다.

주평가는 **영상 생성**이다. Retrieval과 VQA는 표현의 특성을 확인하는 보조 평가다. 최종 문제는 scene/object/character 재등장, 지속되는 상태, 과거 사건의 결과, 복수의 장거리 의존성을 포함한다.

**09-08 사용자 재강조:** 과거 프레임의 배경·물체·사람 모두가 유용한 정보일 수 있다. 피사체 추출·배경 제거·참조 시트로 정보를 미리 제한하는 방향은 기본 경로에서 제외한다. 기존 resize/VAE 전처리를 유지한 전체 프레임에서 생성 요청·Local·전역 문맥에 따라 필요한 정보를 활용하는 것이 목표다. 배경 유사성 자체는 실패가 아니며, 현재 요청을 막는 과거 구도·동작·컷의 강제 재현과 구분한다.

**앞선 완료 · 2026-09-08 prompt 비교:** 원본 전체 Past 참조를 유지한 P1/P2/P3 × Local/Image-Past/Video-Past 신규 45회를 모두 첫 시도에 완료했고, 기존 P0 15개와 60개를 비교했다. 정식 누적은 95회다. 로봇·보존 작업자는 과거 외관과 새 구도의 결합이 관찰됐고, 차량 Video/Past는 P2/P3에서 외부 장면으로 전환됐지만 실제 주행 성공은 불확실하다. 학생은 계속 전환에 실패했고 관리자 Video/Past는 P0 성공에서 새 prompt의 노트북 유지로 악화됐다. Prompt 추가의 효과는 사례·형식에 따라 다르며 P3가 P2보다 일관되게 낫지는 않다. [결과·검증·한계](feasibility_long_context/PROMPT_CONTROL_RESULT.md) · [실제 입력·60개 비교](feasibility_long_context/reports/five_case_prompt/seed42/index.html). P0 text embedding 5개 재인코딩과 P0 DINO 전체/1초 이후 30개 값이 기존과 정확히 일치했다. 전체 60개에서 참조·좌표·초기/7회 noise·고정 latent·18,780프레임 decode를 검증했다. Attention 계측·adapter·메모리 학습은 실행하지 않았다.

## 09-08 최신 완료: 마지막 Stage 1 긴 입력과 선택 chunk 25조건

사용자는 작은 시간 offset 추가 실험을 생략하고, 30초 이상 전체 과거와 필요한 chunk만 넣는 방식의 정보 활용·시간·메모리 비교를 요청했다. 설계 후 “진행해”로 실행을 승인했고 **5사례 × 5조건의 신규 25회를 완료**했다. 정식 누적 **120회**다. [최신 결과·통제·한계](feasibility_long_context/LONG_INPUT_RESULT.md) · [실제 입력·영상](feasibility_long_context/reports/long_input/index.html).

같은 연속 과거 32초(H 30초 + Local 2초)에서 Target 3초를 생성했다. L은 Local-only, N은 연속 32초 VAE prefix, F는 전체 H bank + 독립 Local, O/U는 F의 9 latent frame 부분집합 + 독립 Local이다. 원래 H 시간 좌표를 유지하고 Target에 겹치도록 참조를 옮기지 않았다. O는 사람이 고른 3초 chunk, U는 고정 중앙 index 41–49다. N/O는 방식 비교, F/O는 동일 bank 내 선택 효과다.

생성 전 동결한 `configs/long_input_cases.json` SHA256은 `bdba61857111a43b2576f725d2be1dc262ee88480e40f30a49f712df5060d75f`다. 기존 Oracle 4개가 32초 밖이라 관리자 원본은 다른 직원의 재등장 T=109.8430667, 로봇은 T=260으로 변경했다. 학생·차량·보존 작업자의 T는 유지하고 Oracle을 그 32초 안에서 다시 골랐다. 학생 O/U는 9개 중 8개 index가 겹친다. 로봇 원본 후속은 요청한 display의 GT가 아니라는 사실을 생성 전에 동결하고 GT DINO 순위를 제외했다. 모두 단일 chunk 외관 진단이며 복수 증거·상태·사건 과제는 아니다. 기존 결과와 직접적인 단일 변수 비교로 취급하지 않는다.

관찰: O는 직원·로봇·차량의 필요한 외관을 N/F/L/U보다 명확히 드러냈다. 로봇은 각진 helmet/금색 앞면을 손 없는 새 display 구도와 결합했다. 직원·차량은 과거 구도도 상당히 재현했고 차량 주행은 성공하지 않았다. 학생은 모든 조건에서 교사 앞면/학생 뒷면을 유지했다. 보존 작업자 O는 회색 머리/안경 일부가 상단에서 잘리며 자막을 재현했고 N/F는 지속적인 겹침, L/U는 더 깨끗한 측면이지만 다른 머리/안경 외관이다. O의 증거 축은 N/F 각각에 명확한 개선 3, 부분 개선 1, 공동 실패 1이다. Assistant가 조건명 확인 전 7시점 비교를 기록하고 이후 25개 전체 72프레임 sheet를 검토했다. 실시간 재생을 관찰한 독립 사람 평가는 아니며 전체 연구 성공률로 일반화하지 않는다.

측정: 25조건은 같은 GPU 0에서 조건별 새 프로세스·분리 decoder로 순차 실행했다. median denoising N/F/O = 18.035/18.181/3.868초, 사례별 speedup median 4.663×/4.703×다. 전체 peak allocated N/F/O = 39.016/39.049/36.276 GiB (약 7% 감소), 상주 baseline 대비 증가분 3.624/3.656/0.887 GiB (약 76% 감소)다. 로딩/검사/decoder 포함 실행 본체는 약 1.65× 빠르다. 별도 VAE/text 준비까지 더한 구성요소 합은 1.35×/1.37×이며 단일 cold 요청 실측이 아니다. O도 전체 H bank 구축 비용을 지불했다. 자동 검색·memory 구축 비용은 미포함이다.

검증: 입력 RGB/PTS·GT 분리, 실제 Target 초기 state/7회 step noise·audio·좌표, F와 Sparse의 정확한 부분집합, clean token 고정 오차 0, 출력 75개 MP4의 7,825프레임 decode(새 Target 1,800프레임)가 통과했다. 25조건 denoising/decoder 실패나 OOM은 없었다. 첫 preflight의 keyword API 오류는 denoising 이전 중단으로 보존했으며 집계하지 않는다. CPU 좌표 이론 재계산에만 CUDA division과 1 ULP 차이를 허용하고 실제 GPU 조건 간 좌표는 bit 단위 일치다. [감사](feasibility_long_context/reports/long_input/artifact_verification.json), [프레임 검토](feasibility_long_context/reports/long_input/review.json), [비용](feasibility_long_context/reports/long_input/cost_analysis.json)을 확인한다.

Stage 1의 승인된 마지막 비교를 완료했다. 선택 증거의 입력 효용과 계산 절감은 부분적으로 확인됐으며, 전역 메모리의 직접 생성 조건 + 원본 증거 선택 두 기여는 미검증이다. 다음은 이를 분리할 Stage 2 최소 설계를 정하는 후보이고 아직 구현·학습을 시작하지 않았다. 이전 offset/attention/추가 seed/60초 확대를 자동 실행하지 않는다. 사전 설계 MD의 “미실행/95회”는 당시 기록이며 현재 상태는 이 절과 최종 결과를 따른다.

## 09-08 앞선 논의: 참조 시간 거리와 생성 시점에 묶이지 않는 이미지 조건

사용자는 prompt 결과를 직접 확인하고, 보존 작업자가 과거 장면을 그대로 재현하지 않고 새 장면을 구성한 점을 **기존 모델에도 참조 활용 능력이 있다는 긍정적 증거**로 해석했다. 같은 prompt의 Local-only에서는 다른 외관의 사람이 나왔고 Oracle 조건에서는 과거 외관과 새 측면 구도가 결합했다는 비교가 이 해석을 뒷받침한다. 범용 identity 정확도나 상태·사건 활용까지 검증한 것으로 확대하지 않는다.

추가 질문은 현재 참조 좌표가 너무 먼지, 시간 좌표가 필수인지, 이미지를 생성 첫 프레임으로 고정하지 않고 “이 사람이 특정 행동을 하는 영상”을 만들 수 있는지다. 이번에는 코드·저장 좌표·공식 자료를 확인했으며 신규 생성은 하지 않았다. 누적 95회 유지.

- 현재 모든 5개 사례/P0–P3는 원본 시간 간격 대신 같은 모델 좌표 배치를 쓴다. Image/Past `[0, 1/24)`초, Video/Past `[0, 73/24)`초, Local `[97/24, 146/24)`초, Target `[146/24, 218/24)`초다. 보존 작업자 P1 두 형식의 실제 `video_positions.pt`를 CPU에서 다시 읽어 확인했다. 이 범위는 token 구간 경계이며 개별 attention의 상대 위치 한 개를 뜻하지 않는다. 예를 들어 보존 작업자의 원본 참조 이미지는 47초, target 시작은 약 110.47초지만 모델에 약 63.47초 간격으로 주입하지 않는다.
- `VideoConditionByKeyframeIndex(frame_idx=0)`은 별도 clean reference token을 sequence 뒤에 추가하고 그 참조 좌표를 0부터 설정한다. 실제 생성 첫 프레임을 해당 이미지로 덮어쓰지 않는다. 실제 고정 prefix는 별도의 `VideoConditionByLatentIndex`로 넣은 Local이다. Target 좌표 실험도 별도 reference token의 좌표 이동이었으며 target latent의 직접 고정은 아니었다.
- 현재 LTX 입력 경로는 visual token 위치로 RoPE를 만든다. 좌표 0은 위치 제거가 아니고, `VideoConditionByReferenceLatent`도 좌표를 내부에서 만든다. 참조에만 시간 회전을 생략해도 시간 회전된 생성 query와의 내적에는 query 시간 영향이 남으므로 “시간과 독립된 참조 attention”과 같지 않다. 그러한 cross-reference 경로 변경은 별도 구현·출력 검증이 필요하다. 영상 내부 순서와 전역 메모리의 원본 시간/사건 정보까지 없애는 방향으로 해석하지 않는다.
- Assistant의 당시 미실행 제안, 이후 사용자 판단으로 진행하지 않음: 거리만 진단하려면 Image/Past의 동일 latent·token 수·prompt·noise·Local/Target 좌표를 고정하고 참조 시작을 0/2/4초로 옮긴다. 4초 이미지의 끝은 Local 시작과 맞닿고 Target과 겹치지 않는다. 이는 우선 이미지의 거리 효과를 분리하는 제안이며 영상으로 자동 일반화하지 않는다. Video/Past는 약 3.04초 길이이므로 같은 +4초 이동을 쓰면 Local/Target과 겹친다. 영상은 별도의 간격 설계가 필요하다.
- 장기적으로 원본 전체 이미지/영상 특징을 생성 timeline과 분리된 조건 attention으로 읽는 adapter가 가능하다. IP-Adapter는 별도 image/text cross-attention의 선행 예시이지 LTX용으로 즉시 장착할 가중치가 아니다. Ingredients는 first-frame conditioning 없이 참조를 사용하는 공개 예시지만 reference sheet 과제로 학습됐고 위치 인코딩이 없는 모델은 아니다. 배경 제거·시트를 기본으로 쓰지 않는 사용자 의도를 유지한다. 현재 모델에서도 Local을 빼고 전체 Target을 noise로 두며 별도 참조를 추가하는 구성은 구현 가능하지만 그 조건의 성능은 미검증이다.

## 사용자가 명확히 한 핵심: 메모리의 두 역할

사용자는 생성 시 압축 메모리에 attention하면 검색할 정보를 찾는 데 도움이 될 뿐 아니라, **전체 메모리로부터 생성에 필요한 추가 정보를 직접 얻을 수 있다**는 점을 강조했다.

따라서 메모리의 역할은 다음 두 가지 모두다.

1. **직접적인 전역 생성 조건:** 긴 문맥의 관계, 사건 흐름, 누적 상태 등 전체 정보를 생성에 전달한다.
2. **원본 위치 선택:** 필요한 원본 구간을 찾고 그 구간의 세부 시각 정보를 회수한다.

```text
Long source video
  ├─ Feature encoding / learned fusion → Global memory M
  │                                      ├─ Attention → Global generation condition ──┐
  │                                      └─ Attention-guided source selection ──┐     │
  └─ LTX VAE → Source latent bank ─────────────── Retrieve selected evidence ◀──┘     │
                                                       │                             │
                                                       └───────────┬─────────────────┘
Local context + prompt/control ──────────────────────────────────── LTX → Target
```

해석할 때 유지할 사항:

- 직접 특징 검색의 성능만으로 압축 메모리가 불필요하다고 결론 내리지 않는다.
- 같은 검색 증거를 제공해도, 전역 메모리를 직접 조건으로 추가하면 생성이 개선되는지 검증한다.
- 이는 학습으로 획득하려는 기능이다. Attention을 연결하면 자동으로 성립한다는 확인된 사실이 아니다.
- 의미 범주별로 메모리를 수작업 분할하는 것을 필수로 삼지 않는다.

## 제안된 전체 구조

- LTX VAE, V-JEPA2, VLM/semantic video encoder의 상호 보완적인 특징을 이용한다.
- Projection과 학습 가능한 fusion으로 특징을 결합하고, 경량 memory transformer로 고정 개수의 메모리 토큰을 만든다.
- 메모리와 원본의 대응 `A_memory<-source`를 유지한다.
- 생성 query가 메모리에 attention하여 얻은 `A_generation<-memory`와 원본 대응을 합성해 후보 구간을 고른다.
- 선택한 원본 LTX VAE latent와 전역 메모리 조건을 LTX에 전달한다.
- 학습 목적은 `L_generation + lambda * L_retrieval`을 기본안으로 삼는다.

이는 연구 구상이며 구현된 구조가 아니다. Encoder의 구체적인 선택, 융합 방법, 메모리 연결 위치, 검색 시점, 학습 범위는 미정이다.

## 분리해서 검증할 가설

| 검증할 사항 | 비교 |
|---|---|
| 관련 과거 증거는 생성에 유용한가 | Local / Local+Random / Local+Oracle |
| 메모리는 생성에 직접 도움이 되는가 | **같은 검색 증거를 고정**하고 전역 메모리 조건 유무 비교 |
| 메모리는 증거 선택에 도움이 되는가 | 전역 메모리의 직접 조건은 공통으로 두고 검색 방법 비교 |
| 전역 문맥과 세부 증거는 상호 보완적인가 | Local만 / 메모리만 추가 / 증거만 추가 / 둘 다 추가 |
| 생성 목적의 학습은 도움이 되는가 | 검색 목적만 사용 / 생성+검색 목적 사용 |
| 압축과 검색은 긴 문맥에서도 유효한가 | 원본 길이, 의존 거리, 방해 구간 수, 메모리 수, 증거량에 따른 품질과 비용 |

이는 후속 검증 계획이며, 모두 Stage 1에서 구현해야 하는 요건은 아니다.

## Stage 1: 당면한 feasibility test

첫 질문은 "사람이 유용한 먼 과거 구간을 골라 주면, 기존 LTX는 그 증거를 이용해 생성을 개선할 수 있는가"이다.
전체 연구 중 **원본 증거를 가져와 이용하는 경로**를 검증한다.

원문 기반 초기 진행 순서(최신 범위 축소 논의는 아래 현재 작업 상태를 우선):

1. 테스트 소재를 확인하고, local 1–2초 정도를 조건으로 그다음 3초 정도를 생성한다. Local-only의 연결이 정상인지 확인한다.
2. Local에는 보이지 않는 명확한 속성을 포함한 과거 구간을 추가하고, 생성 부분에 그 속성이 반영되는지 확인한다.
3. 대표 사례에서 참조 속성을 바꾸고 공통 local/prompt/target 초기 noise로 출력 변화를 확인한다. 진단은 2–3개 사례에서 시작한다.
4. 입력 경로를 확인하면 3–5개 사례의 Local/Random/Oracle 비교를 끝까지 실행한다. 공통 seed를 여러 개 사용하는 안이 있다.
5. 설정과 평가를 고정하고 약 20개 사례부터 확대한다.

평가와 통제에서 유지할 사항:

- 명확한 먼 과거 의존 속성의 재현을 주로 보고, GT 전체의 DINO/CLIP 유사도는 보조로 사용한다.
- Prompt에 생성 방향을 쓰더라도 검증 대상의 정답 속성을 적어 oracle 정보를 대체하지 않는다.
- Random에도 정답 정보가 포함되는지 확인하고, Oracle과 길이 및 전처리를 맞춘다.
- 새로 생성한 target만 평가하며 참조 복사, 정지 출력, local과의 부자연스러운 연결도 확인한다.
- 원본의 의존 거리와 모델에 입력하는 위치 좌표 및 시간 간격을 구분한다.
- Hard negative와 oracle 대표 프레임 대 영상 비교는 필요한 소수 사례에 추가할 후보이다.

Oracle이 효과가 없어도 곧바로 장기 기억이 불필요하다고 결론 내리지 않는다. 입력 형식, 참조 활용 능력, 데이터의 의존성을 진단한다. Oracle이 효과가 있어도 전역 메모리의 직접 생성 효과나 검색 성능까지 증명된 것은 아니다.

## 데이터 선택: FineVideo 우선 검토

2026-09-06 대화에서 사용자가 FineVideo를 사용하려던 것으로 기억한다고 밝혔다. 따라서 다른 데이터셋으로 임의 변경하지 않고 **`HuggingFaceFV/finevideo`**를 우선 데이터 소스로 검토한다. 두 원문 txt에는 특정 데이터셋 이름이 없었다.

[공식 데이터 카드](https://huggingface.co/datasets/HuggingFaceFV/finevideo)에서 확인한 사항:

- 평균 영상 길이가 4.7분이고, 장면·인물·활동·물체의 시간 정보가 있어 먼 과거 증거의 후보를 찾는 데 활용할 수 있다.
- 영상과 JSON 메타데이터를 제공하며, 전체 다운로드 외에 streaming 로딩을 안내한다. 소수 샘플만 저장하는 방식으로 시작할 수 있지만, 필터링하면서 실제로 읽는 데이터량도 관리해야 한다.
- 시간별 메타데이터는 모델로 생성되었다. 이를 oracle 정답으로 바로 취급하지 않고 실제 영상으로 유용성과 타임스탬프를 검증한다.
- 파일 접근에는 Hugging Face의 접근 조건 수락이 필요하다. 처음에는 HTTP 403이었으나, 2026-09-06 사용자가 접근 승인을 받았다고 알린 뒤 로컬 인증 재검사와 실제 다운로드가 성공했다. 최신 결과는 [접근 검사 로그](feasibility_long_context/reports/finevideo_access.json)에 있다.

데이터 수집용 [스크립트](feasibility_long_context/download_finevideo.py)를 실행해 첫 Parquet shard 한 개(493,919,884 bytes, 약 471 MiB)에서 60–600초 조건을 만족하는 첫 후보 영상 5개를 추출했다. Revision은 `84c74091e1c6ee7a5dffabfafb5c9033e4718883`이다. 추출 MP4는 합계 약 87.81 MiB다. 기본 shard 크기 예산은 700 MiB이며 전체 데이터셋을 순회하지 않았다. 실제 `mp4`/`json` 구조와 추출 경로를 확인했다. 실행 명령은 [README](feasibility_long_context/README.md)에 있다.

전체 영상의 설명이나 Q&A는 후보 선정에 참고할 수 있지만, 미래/target 정보를 포함한 텍스트를 생성 prompt 또는 memory 입력에 그대로 넣지 않는다.

[데이터 검토 결과](feasibility_long_context/DATA_REVIEW.md)와 [클립 검토 페이지](feasibility_long_context/reports/pilot/index.html)에 다음 초기 입력을 준비했다.

- `pilot_000_local_cooking`: 요리 영상 local 246–248초, target 248–251초. 연속 동작의 local-only 생성 입력 확인용이다.
- `pilot_001_interview_return`: 공사 차량 local 뒤 인터뷰가 재등장한다. Oracle 90–93초, target 시작 158.825333초. 원본 간격은 약 65.825초다.
- `pilot_002_interview_return`: 안전모를 쓴 작업자 local 뒤 다른 인터뷰가 재등장한다. Oracle 60–63초, target 시작 177.635789초. 원본 간격은 약 114.636초다.

두 인터뷰 진단은 같은 원본에서 나왔으며, 과거 인터뷰로 전환한다는 prompt를 준다. 장면 전환을 자연스럽게 예측하는 장거리 평가가 아닌 **참조 외관 활용 진단**이다. Prompt에 정답 의상·안경 등은 넣지 않았다. Random은 같은 원본 44–47초 풍경을 수동 선택한 관련 없는 대조군이다. 두 번째 local의 안전조끼에도 주황색이 있으므로 주황색만 재현하는 것은 성공 기준이 아니다. 안경·수염·셔츠 무늬 등을 본다. 진단 입력을 독립적인 장거리 벤치마크 사례로 집계하지 않는다.

설정은 [pilot_examples.json](feasibility_long_context/configs/pilot_examples.json)에 있고 `prepare_clips.py`가 총 10개 클립과 각 실험 `metadata.json`을 생성한다. 모두 24 FPS, local 48프레임, target/참조 72프레임이며 원본 해상도를 보존했다. 전체 파생 클립 디코딩과 원본 시간 범위를 검사했고 local/GT 프레임이 섞이지 않았다. 프레임 미리보기는 agent가 확인했으며 사람의 검수나 원본 전체 프레임 검사 완료는 아니다. LTX 입력 규격에 맞추는 공간/시간 전처리는 다음 추론 구현에서 정한다.

## 검토 중인 기술 과제

다음은 설계 검토에서 제기된 논점이며, 해결법이 확정된 사양은 아니다.

- **Attention 합성:** 행렬의 곱을 위치 선택 분포로 쓸 수 있지만, 생성에 유용한 원본 위치를 자동으로 나타내는 보장은 없다. 대응 단위, head/layer 처리, 검색 감독을 정의해야 한다.
- **검색 학습:** Hard top-k의 인덱스 선택은 일반적인 역전파로 미분할 수 없다. 생성 loss와 검색 score를 연결할 방법, 검색 정답 및 복수의 유용한 구간을 정의해야 한다.
- **LTX 연결:** 원본 VAE latent와 학습한 메모리 token은 다른 입력이다. 직접 조건의 adapter, 학습 대상, backbone 고정 범위를 결정해야 한다.
- **Query:** 초기 noise 의존이나 중간 생성 오류를 강화하는 검색을 피할 설계를 검토한다. Local+prompt로 한 번 검색하는 것은 초기 후보이며 확정 사양은 아니다.
- **비용:** 메모리 수 K가 고정이어도 밀집 원본 대응 행렬과 latent bank는 원본 길이에 의존한다. 전처리, 저장, 검색, 생성 비용을 나눠 측정한다.
- **특징 대응:** Encoder 사이의 시간 해상도와 원본 주소를 대응시킨다. 세 가지 encoder와 복잡한 fusion의 필요성은 비교 실험으로 확인한다.
- **Task 구분:** Future generation에서는 미래/GT target을 memory에 넣지 않는다. Aligned editing에서 허용되는 현재 source clip과 혼동하지 않는다.
- **연구 비교:** 직접 특징 검색, 압축만 사용, 검색만 사용과 비교하고 학습 조건과 입력 예산을 통제해야 한다. 독창성과 성능 우위는 미검증 상태다.
- **VQA:** 후속의 선택적 표현 평가이다. 생성 feasibility 진행의 선행 조건으로 삼지 않는다.

## 현재 작업 상태

2026-09-06 기준 수행한 일:

- 두 원문 txt를 읽고 연구 목표와 실험 설계를 논의했다.
- 사용자가 메모리의 직접 생성 조건과 검색이라는 두 역할을 명확히 했다.
- 부모 LTX 저장소의 조건 입력 코드와 로컬 모델 파일을 읽어서 확인했다.
- 대화에서 논의한 내용을 이어가기 위한 `AGENTS.md`와 이 문서를 작성했다.
- 사용자의 FineVideo 선택 의도를 기록하고, 공식 데이터 카드의 구조·streaming 방식·접근 조건을 확인했다.
- 처음에는 데이터 접근이 HTTP 403으로 거절됐으나 사용자가 승인받은 뒤 로컬 인증과 실제 데이터 다운로드가 성공했다.
- `download_finevideo.py`로 첫 shard에서 후보 5개를 추출하고 MP4, 자동 메타데이터, SHA256과 provenance를 저장했다. 다운로드·추출 경로를 실제 데이터로 검증했다.
- `pyarrow==21.0.0`을 `feasibility_long_context/.deps/`에 설치했다. 기존 `huggingface_hub`, `av`, `PIL` 등을 재사용하며 부모 가상환경 패키지는 변경하지 않았다.
- `preview_candidates.py`로 후보 5개의 전체 미리보기와 특정 구간 미리보기를 만들고 확인했다.
- `configs/pilot_examples.json`에 초기 입력 3개를 기록하고 `prepare_clips.py`로 클립 10개와 HTML 보고서를 만들었다. 원본 SHA256/revision, 구간 범위, 참조 길이 일치, 출력 프레임 수·PTS·길이·전체 클립 디코딩 및 local/GT 원본 프레임 비중첩을 확인했다.
- 검토 결과·실행 명령·한계는 `feasibility_long_context/DATA_REVIEW.md`, `README.md`, `reports/pilot/preparation.json`에 기록했다.
- 사용자가 GPU 0–2번 사용을 허용하고 `uv run` 실행을 제안했다. 기존 환경을 사용하는 `uv run --no-sync --project ..`로 실제 실행했다. CUDA는 샌드박스에서 접근되지 않아 GPU 접근이 허용된 실행으로 진행했다.
- `SETUP_NOTES.md`에 현재 API, checkpoint, VAE의 시간·공간 제약을 기록하고 `run_generation.py`를 작성했다. 현재 CLI는 local 모드만 지원한다.
- `pilot_000_local_cooking`을 GPU 0, seed 42, 512×288, 24 FPS, 8-step distilled 첫 단계로 생성했다. 2초 local의 처음 프레임을 앞에 한 번 복제해 49프레임/7 latent frame을 조건으로 고정하고, target 72프레임/3초를 생성했다. GT 영상은 생성 완료 후 보고서 단계에서만 읽었다.
- 실행 시간은 약 35.87초, PyTorch 최대 할당 GPU 메모리는 39.18 GiB였다. 모든 8개 denoising step 및 최종 상태에서 local latent 최대 절대 오차는 0이었다. 생성 target의 전체 디코딩, 72프레임과 PTS를 확인했다.
- 생성 프레임에서 냄비·배경과 젓는 동작이 이어졌다. 정지 출력은 아니지만 손·도구의 흐려짐과 형태 불안정이 있다. 한 seed의 초기 입력 진단이며 최종 품질 검증은 아니다. [결과 설명](feasibility_long_context/LOCAL_SMOKE_RESULT.md), [비교 페이지](feasibility_long_context/reports/local_smoke/index.html), [수치 기록](feasibility_long_context/reports/local_smoke/summary.json)에 보존했다.

- `run_reference_comparison.py`로 두 인터뷰의 Local/Random/Oracle `past` 비교 6회를 GPU 0–2에서 완료했다. 첫 사례에서는 Oracle도 인터뷰 외형을 복원하지 못했고, 두 번째는 셔츠 어깨 무늬 일부가 반영됐으나 local의 안전모·인물이 남았다. DINOv2 Oracle−Local은 각각 −0.2322, +0.0364였다.
- 실패 원인을 분리하기 위한 첫 사례의 `target_guide` 비교 3회도 완료했다. 과거 대표 이미지를 생성 시작 위치에 추가 keyframe으로 주면 보라색 셔츠·인터뷰 배경이 재현됐다. DINOv2는 Local 0.2713 / Random 0.2271 / Oracle 0.8596이었다. 시간 위치와 참조량·영상/이미지가 함께 달라졌으므로 위치만의 효과는 아니다.
- 같은 prompt/local/초기 및 7회 ancestral noise/공통 위치/설정을 확인했고, 모든 step과 최종 고정 latent 오차는 0이었다. GT는 생성 이후 평가에서만 읽었다. `test_reference_controls.py`의 noise·위치·target 비덮어쓰기 검사 3개가 통과했다. `evaluate_reference.py`는 기존 로컬 DINOv2를 사용하고 `make_reference_report.py`는 외형 검토 기록과 통합 비교 페이지를 만든다.
- 첫 연속 실행 시 diffusion VAE 오류가 발생해 `--all-modes`를 조건별 독립 프로세스로 변경하고 추가 진단을 다시 완료했다. 중단 시도와 기본 실험의 원본 코드 snapshot을 보존했다. 모델/부모 가상환경은 변경하지 않았다.
- 사용자가 정성 결과에서 실제 참조와 주입 방법을 확인할 수 있도록 문서 보완을 요청했다. `REFERENCE_PROTOCOL.md`에 원본 구간·클립 링크·실제 입력 RGB, 영상과 대표 이미지의 차이, 독립 VAE 인코딩, token 배열·self-attention·denoise mask·모델 시간 좌표와 코드 대응을 정리했다. 통합 비교 페이지에도 조건별 실제 입력을 결과 앞에 표시하고, `reports/reference/inputs/`에 입력 미리보기와 hash·timestamp를 보존했다. 생성 설정·결과는 변경하지 않았다.
- 브라우저에서 MD 원문 링크가 읽기 어렵다는 사용자 피드백에 따라 `render_reference_docs.py`로 UTF-8 HTML 문서를 생성하고 보고서 링크를 HTML로 바꿨다. `report.html#pilot-one-difference`에는 001의 과거 영상 참조와 생성 시점 이미지 guidance를 나란히 설명했다. 두 방식 모두 과거 RGB를 쓰며 프레임 수와 시간 위치가 함께 달라진다는 점을 명시했다. 이후 MD를 수정하면 `make_reference_report.py`로 브라우저용 문서도 갱신한다.
- 두 conditioning 클래스의 차이를 확인하며, 실제 001/002의 Oracle/Random cache를 CPU에서 비교했다. 이번 `past`의 `KeyframeIndex(frame_idx=0, num_pixel_frames=73)`는 `ReferenceLatent(downscale_factor=1, temporal_scale_factor=1)`와 token·clean latent·mask·좌표가 모두 동일했다. 두 클래스의 차이는 주로 위치 좌표 구성 규칙이며, `ReferenceLatent`가 IC-LoRA를 자동 로드하는 것은 아니다. 이번 실행에는 일반 distilled만 사용했다. 상세 내용은 `REFERENCE_PROTOCOL.md`에 기록했고 신규 생성은 실행하지 않았다.

이 초기 기록 이후 시간 위치·참조 형식·반복수 진단과 서로 다른 원본 5개 비교까지 완료했다. 최신 5개 전체 2×2 결과와 총 50회 집계는 아래 마지막 완료 절을 확인한다. [참조 실험 결과](feasibility_long_context/REFERENCE_RESULT.md), [통합 비교 영상](feasibility_long_context/report.html), [초기 결론](feasibility_long_context/CONCLUSION.md), [수치](feasibility_long_context/results.csv)에 초기 실험을 기록했다. `outputs/<example>/reference_<layout>_seed42/<mode>/`에 초기 설정·로그·영상·noise·latent를 보존했다. 초기 `results.csv`에는 완료된 9회만 집계하며 중단 시도는 제외한다. 초기 인터뷰 결과는 같은 원본·seed 42의 장면 전환 지시 진단이다. DINO는 전체 프레임 보조 유사도이며 신원 정확도가 아니다. 후속 시간 위치 2×2 비교는 seed 42·43·44로 반복했다. 자연스러운 장거리 의존성, hard negative, 학습된 메모리는 아직 검증하지 않았다.

이전 확인에서 얻은 환경 정보 (실행 전 재확인):

- 부모 LTX 저장소 commit: `a95ab85`.
- `../models/ltx-2.5/`에 dev/distilled transformer, video/audio VAE, Gemma text encoder, spatial upscaler 파일이 있었다.
- `../packages/ltx-core/src/ltx_core/conditioning/types/latent_cond.py`: 지정한 latent 위치를 조건으로 설정하는 구현.
- `../packages/ltx-core/src/ltx_core/conditioning/types/reference_video_cond.py`: IC-LoRA용 원본 latent 추가 구현.
- API의 존재와 현재 checkpoint가 시간적으로 정렬되지 않은 먼 과거 RGB 참조를 효과적으로 활용하는 능력은 별도로 확인해야 한다.

**앞선 완료 결과:** 사용자의 temporal RoPE 가설을 점검하기 위해 파일럿 001에서 이미지/영상 × 과거/생성 시간 위치 2×2 비교를 seed 42·43·44로 완료했다. 기존 seed 42의 영상/과거와 이미지/생성은 실제 입력·좌표·noise·원본 코드 hash를 확인해 재사용했고, 나머지 10회를 새로 생성했다. GPU 0·1에서 생성, GPU 2에서 기존 DINOv2 평가를 수행했다. `run_temporal_position.py`, `run_temporal_seed.py`, `temporal_controls.py`에 구현했고 기존 runner와 upstream은 변경하지 않았다.

같은 형식의 참조 latent·token 수를 고정하고 추가 참조의 시간 좌표만 +146/24초 이동했다. GPU에서 기존 두 조건 좌표를 정확히 재현했으며 CPU/GPU 검사 5개가 통과했다. 12조건의 실제 초기 및 7회 step noise, 공통 설정·base AV 좌표, cache hash, 모든 step과 최종 고정 latent를 검증했다. 전역 메모리·IC-LoRA·새 학습은 사용하지 않았다.

DINO 평균은 이미지/과거 **0.7399**, 이미지/생성 **0.8523**, 영상/과거 **0.0430**, 영상/생성 **0.8812**다. 영상은 세 seed 모두 과거 위치에서 공사 장면이 이어지고 생성 위치에서 인터뷰 외형이 재현됐다. 이미지는 과거 위치에서도 외형을 전달하지만 전환이 더 느렸다. 1초 이후 기존 샘플만 본 사후 진단에서는 이미지 양쪽 점수가 거의 같았다. **시간 위치의 영향은 특히 영상에서 크지만 참조 형식과 상호작용한다.** 단순한 거리 감쇠나 모든 변수 중 최대 영향이라고 일반화하지 않는다. 생성 위치의 영상 출력은 원본 참조의 구도·동작에 가까워 새로운 상태·사건 생성 검증은 아니다.

[실험 설계](feasibility_long_context/TEMPORAL_POSITION_ABLATION.md), [실제 결과·해석·재현 명령](feasibility_long_context/TEMPORAL_POSITION_RESULT.md), [입력과 동기화 비교 영상](feasibility_long_context/reports/temporal_position/index.html)에 기록했다. 신규 산출물은 `outputs/pilot_001_interview_return/temporal_position_seed{42,43,44}/`에 있고 `reports/temporal_position/`에 수치 CSV·summary·provenance 감사·샘플 프레임 검토 기록이 있다. 기존 root `results.csv`는 초기 Local/Random/Oracle 결과를 보존한다. 신규 생성 회당 15.38–19.40초, 최대 GPU 할당 39.145 GiB였다.

**앞선 A–E 결과 (2026-09-07):** 사용자가 영상 past와 이미지 past의 차이 원인을 먼저 파악하자는 방향을 제시했고, 앞선 seed별 정성 경향이 같았으므로 새 실험은 seed 42 하나로 줄이자는 의견을 주었다. 이에 B·C·D만 신규 3회 생성하고 기존 A·E를 재사용해 5조건을 비교했다. B는 이미지 latent 10회 복제/모두 같은 시점, C는 같은 복제 latent/영상의 여러 시점 grid, D는 기존 영상 latent/모두 같은 시점이다. GPU 0·1·2에 각각 B·C·D를 배치했으며 기존 입력 cache를 사용하고 IC-LoRA·새 학습은 추가하지 않았다.

실제 cache 반복 순서, B=C 내용·D=E 내용, B=D 좌표·C=E 좌표, base AV 좌표, 원본 설정·코드 hash, 같은 seed의 실제 초기 및 7회 step noise를 검사했다. 모든 8개 step과 최종 고정 latent 오차는 0이었다. Target 360프레임의 전체 디코딩과 PTS도 확인했고 기존 A·E의 DINO 재평가는 이전 점수와 정확히 같았다. 첫 실행은 conditioning keyword 인자 이름 불일치로 denoising 전에 멈춰 수정했으며, 실제 파이프라인 호출 경로로 검사한 CPU/GPU 테스트 2개가 통과한 뒤 재실행을 완료했다. 중단 시도와 당시 코드는 `outputs/pilot_001_interview_return/reference_format_seed42_attempt1/`에 보존하고 결과에서 제외했다.

DINO 전체 구간은 A **0.7726**, B **0.0345**, C **0.0382**, D **0.0374**, E **0.0392**다. A만 인터뷰로 전환했고 B·C·D·E는 공사 장면을 계속 생성했다. 1초 이후 점수도 A 0.9208, B·C·D·E 0.0256–0.0360으로 단순 전환 지연만으로 설명되지 않는다. **같은 이미지·같은 시간 좌표의 참조 반복도/token 수를 늘리는 것만으로 현재 과거 위치의 실패가 재현됐다.** 영상 temporal encoding과 시간 분산이 실패에 반드시 필요한 것은 아니다. 다만 네 조건이 모두 실패한 결과로 이 요소들이 일반적으로 무관하다고 결론 내리지 않는다. 이전 영상/생성 위치는 동일 1,440 token으로 성공했으므로 참조량과 시간 위치의 상호작용도 유지해서 봐야 한다. Attention 내부 변화는 아직 측정하지 않았다.

[실험 설계](feasibility_long_context/REFERENCE_FORMAT_DIAGNOSIS.md), [A–E 결과·재현 명령](feasibility_long_context/REFERENCE_FORMAT_RESULT.md), [입력과 동기화 영상](feasibility_long_context/reports/reference_format/seed42/index.html)에 기록했다. `run_reference_format.py`, `format_controls.py`, `format_artifacts.py`, `evaluate_reference_format.py`, `make_reference_format_report.py`로 구현했다. 신규 산출물은 `outputs/pilot_001_interview_return/reference_format_seed42/`에 있고 수치·검증·정성 기록은 `reports/reference_format/seed42/`에 있다. 이전 runner·입력·생성 결과는 유지했다. 신규 생성 16.48–19.44초, 최대 GPU 할당 약 39.145 GiB다.

**사용자 요청과 단계 점검:** 사용자가 A–E 결과를 확인했고 반복수·attention 후속 진단 제안이 타당하다고 평가했으나, 먼저 전체 feasibility 진행 상태와 남은 일을 점검하자고 요청했다. [Stage 1 진행 점검](feasibility_long_context/FEASIBILITY_STATUS.md)에 원문·현재 config·CSV·기존 감사 기록을 대조했다. 점검 당시 정식 생성은 23회였고 아래 반복수 진단 후 25회가 됐다. 당시 참조 비교는 같은 원본의 인터뷰 2개였고 독립 원본 비교는 미완료였다. 이후 아래 5개 비교를 완료했다.

**사례 수·Random에 대한 사용자 범위 합의:** 사용자는 신규 Random 비교가 꼭 필요하지 않으며, 20개 대신 5개까지 확대하면 충분하지 않겠느냐는 의견을 제시했다. 이에 **서로 다른 원본 중심의 5개 사례에서 Local-only / Local+Oracle 비교**를 Stage 1의 핵심으로 삼는 축소안을 권장했고 사용자가 다음 단계 진행을 요청했다. 이는 선택한 과거 증거를 추가하는 실익을 확인하는 범위이며 새 사례의 Random 대비 우위나 광범위한 일반화까지 검증하는 것은 아니다. 기존 Random 결과는 보존하고 신규 Random·20개 확대를 필수 잔여 작업으로 취급하지 않는다.

**앞선 완료 결과 · 반복수 1·2·4·10 (2026-09-07):** seed 42에서 같은 이미지 latent의 2회·4회 복제를 GPU 0·1에서 신규 생성했다. N1은 기존 이미지/past(A), N10은 기존 B를 재사용했다. 참조 내용·모든 복사본의 시간 구간 `[0,1/24)`·공간 좌표·base AV 좌표·실제 초기 및 7회 step noise·모델·prompt·생성 설정을 통제했다. 전체 DINO는 N1 **0.7726**, N2 **0.7404**, N4 **0.6726**, N10 **0.0345**이며 1초 이후는 각각 **0.9208/0.9238/0.9201/0.0256**이다.

1·2·4회는 인터뷰 외형을 전달했다. 4회는 0.83초 샘플에도 공사 장면과 인터뷰가 겹치지만 1.17초 샘플부터 인터뷰가 뚜렷하다. 10회는 3초 동안 공사 장면을 지속한다. 측정한 지점에서 4회까지 전달되고 10회에서 실패하지만 5–9회, 정확한 임계점, 단조성, attention 내부 기전은 미검증이다. 전체 점수의 1→2→4 감소는 주로 초반 전환 지연·혼합과 관련되며 1초 이후 외형 유사도는 비슷하다.

실제 파이프라인 조건 입력과 가변 token 수의 noise 검사가 CPU/GPU에서 각각 두 개 통과했다. 네 조건의 38개 공통·paired 설정, 실제 참조 복제, 좌표, 고정 latent, 원본 코드·기존 anchor 감사 기록과 영상 SHA256을 검사했다. 모든 8개 step 및 최종 고정 오차는 0, Target 288프레임의 전체 디코딩·24 FPS PTS도 통과했다. N1/N10의 DINO 재평가는 기존과 정확히 같다. 신규 실행은 첫 시도에 성공했고 2회 18.24초, 4회 15.99초, 최대 GPU 할당 약 39.145 GiB였다.

[사전 설계](feasibility_long_context/REFERENCE_REPETITION_DIAGNOSIS.md), [결과·해석·재현 명령](feasibility_long_context/REFERENCE_REPETITION_RESULT.md), [실제 입력과 동기화 비교](feasibility_long_context/reports/reference_repetition/seed42/index.html)에 기록했다. 신규 산출물은 `outputs/pilot_001_interview_return/reference_repetition_seed42/repeat_2/`와 `repeat_4/`, 보고서·수치·감사는 `reports/reference_repetition/seed42/`다. 기존 runner를 수정하지 않고 반복수 전용 runner·controls·감사·평가·보고서를 추가했으며 생성 시 코드 snapshot도 보존했다.

**앞선 완료 · 서로 다른 FineVideo 원본 5개 (2026-09-07):** 사용자가 사례 선정·입력 형식 고정·10회 생성/평가를 모두 요청했고, GPU 0–2와 실행 권한을 사전에 허용하며 자리를 비운 동안 마무리하라고 했다. 캐시된 첫 shard 33행에서 추가 원본 6개를 추출했고, 기존 인터뷰와 다른 원본 5개(보육원 관리자·로봇 머리·교실 학생·차량 외관·보존 작업자)를 선정했다. 추가 네트워크 다운로드는 없었다. Local 2초/Target 3초, 과거 3초 선택 구간의 36번 이미지 한 장, past 144 token, seed 42, 512×288/24 FPS/8 step을 출력 확인 전에 고정했다. 신규 Random·추가 seed·학습은 하지 않았다.

Local→Oracle DINO는 관리자 **0.2008→0.3915**, 로봇 **0.8736→0.8678**, 학생 **0.3772→0.3570**, 차량 **0.2498→0.2422**, 보존 작업자 **0.3856→0.2921**이다. 정성적으로 관리자와 보존 작업자는 과거 인물의 외관을 전달하지만 참조의 구도·배경을 강하게 따른다. 보존 작업자는 외관이 개선돼도 전환 지연과 넓은 구도 때문에 DINO가 낮다. 나머지 3개는 Local의 시점을 유지해 평가할 머리/얼굴/외부 차체가 드러나지 않는다. 따라서 2개의 외관 기여 관찰을 일반화 성공률로 바꾸지 않으며, image/past의 안정적인 범용 활용은 확인하지 못했다. 모두 prompt로 전환을 지시한 외관 사례이고 상태·사건·복수 증거 검증은 아니다.

최초 3개 Oracle은 denoising을 마쳤으나 VAE 디코더 CUDA 오류로 중단됐다. 디코더를 별도 프로세스로 분리한 뒤 10조건 전체를 같은 방식으로 재실행했다. 같은 Local의 재디코딩 MP4 hash와 최초 6조건의 재실행 latent가 정확히 일치했다. 중단 시도·예비 Local 3개·당시 코드는 `image_past_seed42_attempt1/`, `outputs/five_case_batch_attempt1/`에 보존하고 정식 비교에서 제외했다. 당시 신규 정식 10회를 더한 누적 생성은 **35회**였다. 신규 회당 19.76–23.20초, 부모 allocator peak 약 39.144 GiB이며 별도 decoder peak는 config에 따로 기록했다.

52개 공통 설정·실제 단일 참조 token·N1과 같은 base/참조 좌표·동일 초기 및 7회 target noise·seed 재현·고정 latent 8 step/최종 오차 0을 검사했다. Target 720프레임, 전체 출력 3,130프레임의 디코딩/PTS/hash가 통과했다. 정성 평가는 assistant의 샘플 프레임 검토이며 사람의 정답 검수·blind 평가가 아니다. [사전 설계](feasibility_long_context/FIVE_CASE_PROTOCOL.md), [결과·해석](feasibility_long_context/FIVE_CASE_RESULT.md), [실제 입력·동기화 영상](feasibility_long_context/reports/five_cases/seed42/index.html), [감사](feasibility_long_context/reports/five_cases/seed42/artifact_verification.json)에 기록했다. 생성은 `outputs/five_*/image_past_seed42/`, 별도 수치는 `reports/five_cases/seed42/results.csv`에 있다. 초기 CSV와 이전 runner는 보존했다.

**최신 사용자 방향 수정 및 완료 · 5개 전체 2×2 (2026-09-07):** 사용자는 실패한 학생·차량만의 시간 이동 대신 5개 모두에서 **이미지/영상 × past/생성 시작 위치**를 먼저 비교하고, 이후 attention과 prompt 제어를 살펴보자고 수정했다. seed 42에서 기존 Image/Past 5개와 Local 기준 5개를 재사용하고 신규 Image/Target·Video/Past·Video/Target 15회를 완료했다. 신규 생성은 모두 첫 시도에 성공했다. 정식 누적 생성은 **50회**다.

기존 이미지·Local·prompt cache와 source/구간/평가 속성은 유지하고 같은 과거 3초 영상을 독립 VAE encode한 1,440 token cache만 추가했다. 이미지 144 token / 영상 1,440 token 각각에서 시간 좌표만 +146/24초 이동했다. Base AV 좌표, 실제 초기 및 7회 step noise, Local, prompt, 모델·8 step·분리 decoder를 고정했다. 신규 Random·추가 seed·prompt 변경·attention 계측·학습은 하지 않았다.

전체 DINO 순서 Image/Past, Image/Target, Video/Past, Video/Target은 관리자 **0.3915/0.4547/0.4193/0.5150**, 로봇 **0.8678/0.8251/0.8770/0.7724**, 학생 **0.3570/0.6916/0.3951/0.6496**, 차량 **0.2422/0.6468/0.2434/0.6377**, 보존 작업자 **0.2921/0.3716/0.3065/0.2291**이다. 재사용 10개의 DINO 전체/1초 이후 20개 재평가 값은 이전과 정확히 같다.

로봇·학생·차량은 두 Past에서 막혔지만 두 Target에서는 필요한 머리·얼굴·외부 차체가 보였다. 로봇은 DINO가 내려가도 머리가 드러난다. 관리자·보존 작업자는 **Video/Past도 작동**하므로 영상 과거 조건이나 1,440 token 자체를 일반적인 실패 요인으로 단정하지 않는다. 다만 Target 조건들은 과거 구도·동작을 강하게 따르고 차량 Image/Target은 일부 Local 잔상/합성 경계를 남긴다. 보존 작업자 Video/Target은 과거 영상의 손 근접→작업대 컷과 자막까지 재현한다. 따라서 참조 활용 가능성은 강화됐으나 새로운 view/동작에 맞는 활용과 과거 장면 재현을 분리해야 한다. GT DINO 증감은 외관 정확도가 아니다.

기존 causal grid/시간 이동 테스트 2개, 재사용 10개 기존 감사의 동일성, 신규 15개와 기준 사이 **49개 공통 설정**·실제 참조 content·순수 시간 평행 이동·동일 AV 좌표/noise·모든 8 step/최종 고정 오차 0을 확인했다. Target 1,800프레임/전체 출력 7,825프레임의 decode·PTS·hash가 통과했다. 신규 회당 20.92–24.22초, 부모 allocator peak 약 39.144 GiB, 별도 decoder peak 약 3.308 GiB였다.

[사전 설계](feasibility_long_context/FIVE_CASE_GRID_PROTOCOL.md), [결과·해석·재현](feasibility_long_context/FIVE_CASE_GRID_RESULT.md), [실제 입력·2×2 비교](feasibility_long_context/reports/five_case_grid/seed42/index.html), [감사](feasibility_long_context/reports/five_case_grid/seed42/artifact_verification.json)에 기록했다. 신규 생성은 `outputs/five_*/reference_grid_seed42/`, 별도 영상 cache는 `five_case_video_inputs_512x288/`, 수치·정성·비교 영상은 `reports/five_case_grid/seed42/`다. 원래 runner·입력·출력·CSV는 유지했다.

**당시 사용자 방향 · 선택적 속성 전달 검토 (2026-09-07):** 사용자는 Target 시간 좌표가 attribute보다 scene을 고정하는 경향을 확인하고, 이 경로를 기본으로 쓰지 않으며 identity/attribute만 전달할 방법과 IC-LoRA 적합성을 검토해 달라고 요청했다. 이전 Target 위치의 prompt 강화 우선 제안은 대체한다. 현재 frozen keyframe 입력이 과거 구도·동작을 함께 전달한다는 해석과, 모든 reference adapter의 시간 좌표가 본질적으로 문제라는 주장은 구분한다.

**09-07 당시 Assistant 제안 · 미실행, 최신 원본 유지 방향으로 대체됨:** 보존 작업자·로봇·차량 3개에서 Image/Past를 유지하고 같은 프레임의 피사체 외 영역만 가린 참조를 기존 전체 이미지와 먼저 비교한다. 필요 시 별도 source-token attention mask 개입을 추가하되 background의 VAE/hidden-state 간접 전달과 backend 변경을 통제한다. 이 작은 진단 뒤에는 task-specific Ingredients IC-LoRA를 우선 기존 adapter 후보로 검토한다. 공식 문서는 2.5 목록에 포함하지만 모델 카드·공식 distilled 예제는 2.3 기반이므로 현재 2.5/8-step/Local prefix 실제 호환성은 미검증이다. 시트는 관측된 과거 RGB만 사용하고 정답 외관을 prompt로 대체하지 않는다. Adapter on/off 및 Local 결합을 별도 비교한다. ID-LoRA 공개 구현은 시각 first-frame conditioning을 사용하므로 현재 비정렬 참조의 직접 해법으로 우선하지 않는다. 장기적으로 cross-shot reference 학습 또는 별도 feature-to-K/V adapter를 검토하되 이는 후속 단계다. 자세한 근거·공식 출처·평가·순서는 [NEXT_STAGE.md](feasibility_long_context/NEXT_STAGE.md)에 기록했다.

이번 턴은 로컬 코드·공식 문서·연구 자료 검토와 계획 문서 갱신만 수행했다. 신규 생성·crop/mask 생성·attention 계측·prompt 비교·adapter 다운로드/로딩·새 학습은 하지 않았으며 정식 누적 생성은 **50회**로 유지한다. 위 제안의 실행 범위는 사용자 확정 사양이 아니다. 상태·사건·복수 증거 과제와 메모리의 직접 생성/검색 두 역할도 미검증 상태로 유지한다.

**09-08 공식 목록 재검토 · 실행 없음:** 사용자가 피사체 외 영역을 가린 참조의 주입 방법을 물으며 공식 All LTX-2.5 IC-LoRAs 링크를 제공했다. 목록 15개 모델 카드 링크와 Ingredients 파일 목록을 열어 확인했다. Ingredients는 공식 안내상 2.5 적용 후보이고, 실제 연결된 파일은 `ltx-2.3-22b-ic-lora-ingredients-0.9.safetensors`(표시 약 1.31 GB)다. 저장소/파일의 2.3 표기를 2.5 미지원으로 해석하지 않는다. Dub-It/Relight는 목록에서 2.5 개발 중, HDR도 표 위에서 개발 중으로 표시된다. 우리 Local/8-step 조합의 효과는 아직 실행 전이다.

RGB 가리기는 피사체 밖을 일정한 색으로 채운 전체 이미지를 독립 VAE encode해 같은 Past에 추가하는 방식이며, 별도 mask 채널/투명 영역/token 삭제가 아니다. 회색 배경도 모델이 읽고 재현할 수 있는 내용이다. Attention mask는 별도 개입이다. Assistant는 배경 가리기를 필수 선행 실험으로 두기보다 **Ingredients 적용 검증을 먼저** 하고 가리기 진단은 선택 사항으로 남기도록 우선순위를 보완했다. 이 당시 우선순위는 미실행이며, 이후 원본 배경·물체·사람을 모두 활용해야 한다는 사용자 의견에 따라 현재 계획에서 내렸다. [15개 카드·입력 방식 검토](feasibility_long_context/IC_LORA_CATALOG_REVIEW.md)와 [최신 제안](feasibility_long_context/NEXT_STAGE.md)에 기록했다. 모델 다운로드·로딩·mask 생성·신규 영상 생성·학습은 없으며 정식 누적 50회를 유지한다.

사용자가 강조한 전역 메모리의 직접 생성 기여와 검색 역할은 모두 유지한다. 현재 결과로 메모리가 불필요하다고 결론 내리거나 전체 메모리 학습을 자동 시작하지 않는다. FineVideo 접근·GPU 0–2와 기존 환경 실행 권한은 이미 허용되어 반복 요청할 필요가 없다.

후속 작업에서는 이 절에 실제 변경, 검증 결과, 실행 명령 및 로그 위치, 미해결 사항을 기록하고 갱신한다.

2026-09-07 브라우저 접속 복구: 보고서와 생성 영상은 유지되어 있었지만 127.0.0.1:8765 웹 서버가 종료되어 연결이 거절됐다. 서버를 지속 실행 세션에서 재시작하고 시간 위치 비교 HTML·MP4의 HTTP 200 응답을 확인했다. `feasibility_long_context/README.md`에 서버 재시작과 원격 VS Code 포트 전달 방법을 기록했다. 실험 결과는 변경하지 않았다.

같은 날 A–E 비교 페이지 서버도 다시 종료되어, 웹 서버를 별도 tmux 서버 `ltx-longcond-report`의 `report` 세션으로 옮겼다. 127.0.0.1:8765에 바인딩했고 최신 A–E HTML·MP4의 HTTP 200 및 tmux의 실행 중 Python 프로세스를 확인했다. 로그는 `feasibility_long_context/outputs/report_server.log`, 상태 확인과 재시작 명령은 README에 있다. 채팅 실행 세션과 분리했으며 원격 브라우저 접속에는 기존 8765 포트 전달을 사용한다.

tmux 전환 후 사용자가 여전히 접속되지 않는다고 알려 재확인했다. tmux의 동일 Python 프로세스는 유지됐고, HTML·MP4 HEAD 200 및 HTML GET 200(24,690 bytes), UTF-8 본문·영상 링크를 확인했다. 이후 사용자가 Ports의 브라우저 열기까지 수행했으나 무한 로딩이라고 설명했다. 호스트에서 루트 `/` GET도 HTTP 200(3,931 bytes, 약 2ms)이었고, `ss` 확인 시 8765는 LISTEN 상태이며 연결 중인 소켓은 없었다. 당시 서버 로그에도 진단 요청 외의 브라우저 GET은 없었다. 기존 포트 전달 해제 후 재등록을 안내했고 서버는 재시작하지 않았다. 이후 사용자가 결과를 확인했다고 밝혀 현재는 접속 문제를 진행 중인 장애로 취급하지 않는다. 사용자가 실제로 어떤 연결 조치로 해결했는지는 확인하지 않았다.

2026-09-07 앞선 5개 Local/Oracle 전달 검증: 기존 tmux 웹 서버를 유지한 상태에서 당시 보고서·문서·asset 171개의 HTTP 200, HTML 19개·로컬 링크 446개·MD 원문으로 이동하는 일반 링크 0개를 확인했다. Firefox에서 한글·실제 Oracle 이미지·동기화 영상 5초 표시를 확인했고 `reports/five_cases/seed42/browser_verification.json`에 기록했다. 그 비교의 브라우저 경로는 `http://localhost:8765/reports/five_cases/seed42/index.html`이다. 모든 GPU 작업이 끝나 GPU 0–2가 기준 14 MiB/사용률 0%로 돌아왔다.

2026-09-07 최신 5개 전체 2×2 전달 검증: 기존 tmux 서버를 유지했다. HTML 21개·로컬 링크 496개·연결 파일 189개의 HTTP 200, 주요 HTML 4개의 GET 내용과 파일 일치, MD 원문으로 이동하는 일반 링크 0개를 확인했다. 처음 전달 검사에서는 모든 문서에 `Oracle`이라는 단어가 있어야 한다는 부적절한 assert가 결과 문서에서 실패해, 실제 HTML 파일과 응답 본문을 비교하도록 고쳤고 전체 검증이 통과했다. 생성·평가 결과 변경은 없었다. Firefox에서 실제 Local/이미지/영상 참조·2×2 배치·5초 영상 길이·연결된 한글 결과 문서 표시를 확인했다. `reports/five_case_grid/seed42/delivery_verification.json`과 `browser_verification.json`에 기록했다. 최신 접속 주소는 **http://localhost:8765/reports/five_case_grid/seed42/index.html**이다. 사용자 PC에서의 재생 확인과는 구분한다. GPU 0–2는 각 14 MiB/사용률 0%로 복귀했다.

**09-08 Ingredients 전처리 자동화 확인:** 사용자는 피사체 추출·시트 제작이 자동인지 질문했다. 공식 distilled workflow의 `LoadImage(ingredients_input.jpg)` → 크기 조절 → `RepeatImageBatch` → `LTXAddVideoICLoRAGuide` 연결을 확인했다. 준비된 시트 이후의 처리만 자동이며 이 예제에는 원본 피사체 추출/배경 제거/시트 생성 노드가 없다. 카드가 언급한 별도 시트 생성기를 모델의 내장 기능으로 해석하지 않는다. 현재 연구 코드에도 자동 시트 전처리는 없고 신규 생성/다운로드/학습은 하지 않았다. 이 시트 경로를 사용할 경우 관측된 과거 RGB를 추출·합성하는 처리는 별도로 필요하다는 확인이다. 이후 사용자는 그러한 전처리로 정보를 제한하는 방향을 재검토하도록 했으므로 현재 구현할 전처리로 취급하지 않는다. `IC_LORA_CATALOG_REVIEW.md`에 확인 사실을 보존했다.

**09-08 원본 유지 제안 · 당시 P1 단독안, 아래 3종 추가로 확대:** 배경·물체·사람 중 무엇이든 과거 증거에서 활용해야 하므로 원본 의미 영역을 제거하는 전처리를 기본으로 삼지 않는다. 기존 전체 Past 이미지/영상을 유지한 채 시점·동작·컷을 명확히 하는 P1 초안 5개를 작성했다. 동일 P1의 Local/Image-Past/Video-Past에서 증거 기여를 보고, 기존 P0 결과를 재사용해 prompt 자체의 효과와 구분하는 신규 15회 제안이다. `feasibility_long_context/configs/five_case_prompt_proposal.json`은 미고정 초안이며 기존 config/cache/출력은 유지했다. 현재 runner는 CFG/STG/negative branch가 없는 SimpleDenoiser여서 우선 positive prompt만 비교한다. 새 실험·text embedding·attention 계측·다운로드·adapter 로딩·학습은 하지 않았고 정식 누적은 50회다. [최신 순서](feasibility_long_context/NEXT_STAGE.md)와 [실제 prompt·평가 설계](feasibility_long_context/PROMPT_CONTROL_PROPOSAL.md)를 따른다.

이번 계획 문서 갱신 검증: `uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python -c 'from feasibility_long_context.render_reference_docs import render_documents; print(len(render_documents()))'`로 문서 HTML 21개를 갱신했다. 같은 실행 기준에서 `python feasibility_long_context/verify_five_case_grid_delivery.py`가 전체 HTML 23개·로컬 링크 536개·MD 원문으로 이동하는 일반 링크 0개를 확인했다. `reports/five_case_grid/seed42/document_verification.json`에 기록했으며 이번에는 HTTP/브라우저 재검증을 하지 않았다. 신규 proposal의 기존 cohort SHA256, 5개 P0의 기존 prompt 일치, 5개 P1의 문서/JSON 일치를 확인했다. 기존 생성·평가·감사 코드는 변경하지 않았다.

**09-08 최신 추가 요청 · 대안 prompt 3종 작성:** 사용자의 “프롬프트는 3개 추가해줘”를 기존 P0에 대안 3종을 추가하는 범위로 반영했다. 각 사례의 앞서 작성한 P1은 유지하고 P2=P1+연속성 문장 1개, P3=P2+과거 정보와 새 구도·동작의 역할 문장 2개로 구성했다. 5사례 × 3대안으로 전체 prompt 15개를 JSON/MD/HTML에 작성했다. 모든 버전에서 정답 외관의 구체적 값은 적지 않고 원본 전체 Past 참조를 유지한다. 실제 비교를 실행하면 5사례 × 3조건 × 3대안=신규 45회, 기존 P0의 15개와 총 60개다. 기존 P1 단독 15회 제안과 선택적 P2 후속안은 이 구성으로 대체했다. 이번에는 문서/설정 초안만 수정했고 text encoding·영상 생성·attention 계측·다운로드·학습은 하지 않았다. 누적 정식 생성은 50회이며 신규 45회는 실행 전이다.

3종 prompt 갱신 검증: 기존 cohort SHA256/P0 prompt 일치, P2가 P1 전체를 유지하고 P3가 P2 전체를 유지함, 15개 전체 prompt의 JSON/MD 일치, 신규 45+재사용 15=60 산술을 확인했다. 기존 renderer와 `verify_five_case_grid_delivery.py`를 `uv run --no-sync`로 실행해 HTML 23개·로컬 링크 537개·일반 MD 원문 이동 0개 검증이 통과했다. `reports/five_case_grid/seed42/document_verification.json`에 기록했으며 HTTP/브라우저 검증은 추가하지 않았다.

**09-08 prompt 비교 실행 착수:** 사용자가 실행을 요청해 `configs/five_case_prompt.json`과 `outputs/five_case_prompt_batch/source_snapshot/`을 고정했다. 기존 grid 실물 감사 전체가 이전 기록과 동일했고, batch-size 1의 P0 text embedding 5개도 기존 hash와 정확히 일치했다. 15개 새 text cache를 별도로 생성했다. 첫 3개(P1 관리자 Local/Image-Past/Video-Past)를 생성한 뒤 45개 공통 설정·실제 초기/7회 step noise·참조 latent·좌표·고정 Local·영상 decode 검증이 통과했다. 새 auditor의 빈 Local reference hash 처리만 수정했으며 생성 결과/기존 공통 코드는 변경하지 않았다. 나머지 42회 실행 중이고 신규 생성 실패/재시도는 현재 없다. 명령: `uv --cache-dir /tmp/ltx-longcond-uv-cache run --no-sync --project .. python feasibility_long_context/run_five_case_prompt_batch.py --phase preflight`, `--phase prepare`, `--phase generate --max-jobs 3`, `--phase generate`. 실제 GPU 실행은 샌드박스 밖에서 허용된 0–2로 제한했다. 기존 8765 서버는 유지 중이며 신규 페이지 `reports/five_case_prompt/seed42/index.html`의 HTTP 200을 확인했다.

**09-08 prompt 비교 전체 완료:** 원본 전체 Past 참조를 유지한 P1/P2/P3 × Local/Image-Past/Video-Past 신규 45회를 모두 첫 시도에 완료했고, 기존 P0 15개와 60개를 비교했다. 정식 누적은 95회다. 로봇·보존 작업자는 과거 외관과 새 구도의 결합이 관찰됐고, 차량 Video/Past는 P2/P3에서 외부 장면으로 전환됐지만 실제 주행 성공은 불확실하다. 학생은 계속 전환에 실패했고 관리자 Video/Past는 P0 성공에서 새 prompt의 노트북 유지로 악화됐다. Prompt 추가의 효과는 사례·형식에 따라 다르며 P3가 P2보다 일관되게 낫지는 않다. 새 text cache는 `outputs/five_*/prompt_text_inputs_512x288/`, 신규 영상은 `outputs/five_*/prompt_control_seed42/`, 실행 기록은 `outputs/five_case_prompt_batch/`, 평가/비교/정성 기록은 `reports/five_case_prompt/seed42/`다. 첫 3개+나머지 42개로 생성했으며 각 조건·decoder를 새 프로세스로 실행했다. 45개 공통 설정, 실제 text cache, 실제 원본 참조·좌표·초기/7회 step noise, 8 step/최종 고정 오차 0, Target 4,320/모든 출력 18,780프레임의 decode·PTS·hash를 검증했다. 재사용 P0 평가 30개 값 차이는 0이다. 새 auditor의 빈 Local reference hash 처리만 수정했고 생성 실패/재시도는 없었다. 정성 관찰은 assistant의 7개 시점 sample-frame 검토이며 blind 평가나 사용자 확인이 아니다. 다음 후보는 관리자 Video/Past P0↔P1과 차량 Video/Past P1↔P2처럼 동일 참조에서 prompt만으로 경로가 달라진 두 쌍의 진단이며 아직 실행하지 않았다. 압축 전역 메모리의 직접 생성/검색 두 역할과 상태·사건·복수 증거 범위는 미검증이다.

**09-08 prompt 보고서 전달 검증 완료:** 기존 tmux 8765 서버를 유지하고 HTML 25개·로컬 링크 866개·연결 파일 436개의 HTTP 200, 주요 HTML 응답과 실제 파일 일치, 일반 MD 원문 이동 0개를 확인했다. Firefox headless 1600×3000 화면에서 한글·실제 Local/Oracle/GT·P0–P3/세 조건 배치·완료 수·prompt 펼침/재생 버튼 표시를 확인했다. 정적 화면 검토이므로 동기 재생 버튼의 상호작용이나 사용자 PC의 재생을 검증한 것으로 표현하지 않는다. 결과는 `reports/five_case_prompt/seed42/delivery_verification.json`, `browser_verification.json`, screenshot은 `outputs/browser_check/prompt_report.png`다. GPU 0–2는 모두 메모리 14 MiB·사용률 0%로 복귀했다. 새 회당 20.18–24.85초, 부모 allocator peak 최대 39.144 GiB, decoder peak 3.308 GiB였다. 최종 접속 주소: http://localhost:8765/reports/five_case_prompt/seed42/index.html . 실행·평가·정성 기록·문서·전달 검증을 완료했으며 추가 attention/학습은 미실행이다.

**09-08 긴 입력 비교 전달:** 25조건의 실제 입력/생성 비교와 정성 기록·DINO·비용 CSV·최종 문서를 완성했다. 기존 8765 서버를 유지하고 Firefox에서 한글·실제 입력 미리보기·A–E 결과·선택 timeline의 표시를 확인했다. 이는 정적 화면 검사이며 동기 재생 상호작용/사용자 PC 포트 전달 검증은 아니다. 검증은 `reports/long_input/browser_verification.json`, `delivery_verification.json`(모두 feasibility 하위)에 기록한다. 최종 주소는 http://localhost:8765/reports/long_input/index.html 이다. GPU 0–4는 사용률 0%, 상주 메모리 14–15 MiB의 유휴 상태로 확인했다. 앞으로 허용 GPU는 0–4이며 추가 생성·attention·학습은 시작하지 않았다.
